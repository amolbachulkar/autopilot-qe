"""QMetry integration configuration, mappings and durable outbox."""
from alembic import op
import sqlalchemy as sa
revision = "0006_qmetry_integration"
down_revision = "0005_auth_quality_analytics"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("qmetry_integrations",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("edition", sa.String(24), nullable=False, server_default="enterprise"),
        sa.Column("base_url", sa.String(500), nullable=False, server_default=""),
        sa.Column("project_key", sa.String(160), nullable=False, server_default=""),
        sa.Column("project_id", sa.String(80), nullable=False, server_default=""),
        sa.Column("test_case_folder_id", sa.String(80), nullable=False, server_default=""),
        sa.Column("scope", sa.String(24), nullable=False, server_default="project"),
        sa.Column("sync_test_cases", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("sync_executions", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("api_key_encrypted", sa.Text(), nullable=False, server_default=""),
        sa.Column("user_token_encrypted", sa.Text(), nullable=False, server_default=""),
        sa.Column("org_code", sa.String(160), nullable=False, server_default=""),
        sa.Column("jira_auth_type", sa.String(16), nullable=False, server_default="bearer"),
        sa.Column("jira_username", sa.String(240), nullable=False, server_default=""),
        sa.Column("jira_token_encrypted", sa.Text(), nullable=False, server_default=""),
        sa.Column("test_case_folder_path", sa.String(500), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_test_at", sa.DateTime(timezone=True)),
        sa.Column("last_sync_at", sa.DateTime(timezone=True)),
        sa.Column("last_status", sa.String(24), nullable=False, server_default="not_configured"),
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""))
    op.create_table("qmetry_test_mappings",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("test_case_id", sa.String(64), sa.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False),
        sa.Column("external_id", sa.String(120), nullable=False, server_default=""),
        sa.Column("external_key", sa.String(120), nullable=False, server_default=""),
        sa.Column("external_version_id", sa.String(120), nullable=False, server_default=""),
        sa.Column("last_synced_at", sa.DateTime(timezone=True)),
        sa.Column("last_hash", sa.String(64), nullable=False, server_default=""))
    op.create_index("ix_qmetry_test_mappings_test_case_id", "qmetry_test_mappings", ["test_case_id"], unique=True)
    op.create_table("qmetry_sync_jobs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("idempotency_key", sa.String(240), nullable=False),
        sa.Column("entity_type", sa.String(32), nullable=False),
        sa.Column("entity_id", sa.String(64), nullable=False),
        sa.Column("operation", sa.String(32), nullable=False, server_default="upsert"),
        sa.Column("status", sa.String(24), nullable=False, server_default="pending"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="8"),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""),
        sa.Column("external_ref", sa.String(160), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True)))
    op.create_index("ix_qmetry_sync_jobs_idempotency_key", "qmetry_sync_jobs", ["idempotency_key"], unique=True)
    op.create_index("ix_qmetry_sync_jobs_entity_type", "qmetry_sync_jobs", ["entity_type"])
    op.create_index("ix_qmetry_sync_jobs_entity_id", "qmetry_sync_jobs", ["entity_id"])
    op.create_index("ix_qmetry_sync_jobs_status", "qmetry_sync_jobs", ["status"])
    op.create_index("ix_qmetry_sync_jobs_next_attempt_at", "qmetry_sync_jobs", ["next_attempt_at"])

def downgrade():
    op.drop_index("ix_qmetry_sync_jobs_next_attempt_at", table_name="qmetry_sync_jobs")
    op.drop_index("ix_qmetry_sync_jobs_status", table_name="qmetry_sync_jobs")
    op.drop_index("ix_qmetry_sync_jobs_entity_id", table_name="qmetry_sync_jobs")
    op.drop_index("ix_qmetry_sync_jobs_entity_type", table_name="qmetry_sync_jobs")
    op.drop_index("ix_qmetry_sync_jobs_idempotency_key", table_name="qmetry_sync_jobs")
    op.drop_table("qmetry_sync_jobs")
    op.drop_index("ix_qmetry_test_mappings_test_case_id", table_name="qmetry_test_mappings")
    op.drop_table("qmetry_test_mappings")
    op.drop_table("qmetry_integrations")
