"""Unified project workspace: requirements, defects, members and release decisions."""
from alembic import op
import sqlalchemy as sa
revision = "0007_project_collaboration"
down_revision = "0006_qmetry_integration"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("projects", sa.Column("id",sa.String(64),primary_key=True), sa.Column("key",sa.String(32),nullable=False), sa.Column("name",sa.String(180),nullable=False), sa.Column("description",sa.Text(),nullable=False,server_default=""), sa.Column("product",sa.String(180),nullable=False,server_default=""), sa.Column("status",sa.String(24),nullable=False,server_default="active"), sa.Column("owner_user_id",sa.String(64),sa.ForeignKey("users.id"),nullable=True), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False), sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False))
    op.create_index("ix_projects_key","projects",["key"],unique=True); op.create_index("ix_projects_status","projects",["status"]); op.create_index("ix_projects_owner_user_id","projects",["owner_user_id"])
    op.create_table("project_members", sa.Column("id",sa.String(64),primary_key=True), sa.Column("project_id",sa.String(64),sa.ForeignKey("projects.id",ondelete="CASCADE"),nullable=False), sa.Column("user_id",sa.String(64),sa.ForeignKey("users.id",ondelete="CASCADE"),nullable=False), sa.Column("project_role",sa.String(24),nullable=False,server_default="contributor"), sa.Column("added_by",sa.String(64),sa.ForeignKey("users.id"),nullable=False), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False), sa.UniqueConstraint("project_id","user_id",name="uq_project_member"))
    op.create_index("ix_project_members_project_id","project_members",["project_id"]); op.create_index("ix_project_members_user_id","project_members",["user_id"])
    op.create_table("requirements", sa.Column("id",sa.String(64),primary_key=True), sa.Column("project_id",sa.String(64),sa.ForeignKey("projects.id",ondelete="CASCADE"),nullable=False), sa.Column("key",sa.String(40),nullable=False), sa.Column("title",sa.String(240),nullable=False), sa.Column("description",sa.Text(),nullable=False,server_default=""), sa.Column("acceptance_criteria",sa.JSON(),nullable=False), sa.Column("priority",sa.String(16),nullable=False,server_default="medium"), sa.Column("status",sa.String(24),nullable=False,server_default="draft"), sa.Column("owner_user_id",sa.String(64),sa.ForeignKey("users.id")), sa.Column("external_ref",sa.String(160),nullable=False,server_default=""), sa.Column("created_by",sa.String(64),sa.ForeignKey("users.id"),nullable=False), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False), sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False))
    op.create_index("ix_requirements_project_id","requirements",["project_id"]); op.create_index("ix_requirements_key","requirements",["key"]); op.create_index("ix_requirements_status","requirements",["status"])
    op.create_table("requirement_test_links", sa.Column("id",sa.String(64),primary_key=True), sa.Column("requirement_id",sa.String(64),sa.ForeignKey("requirements.id",ondelete="CASCADE"),nullable=False), sa.Column("test_case_id",sa.String(64),sa.ForeignKey("test_cases.id",ondelete="CASCADE"),nullable=False), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False), sa.UniqueConstraint("requirement_id","test_case_id",name="uq_requirement_test_link"))
    op.create_index("ix_requirement_test_links_requirement_id","requirement_test_links",["requirement_id"]); op.create_index("ix_requirement_test_links_test_case_id","requirement_test_links",["test_case_id"])
    op.create_table("defects", sa.Column("id",sa.String(64),primary_key=True), sa.Column("project_id",sa.String(64),sa.ForeignKey("projects.id",ondelete="CASCADE"),nullable=False), sa.Column("key",sa.String(40),nullable=False), sa.Column("title",sa.String(240),nullable=False), sa.Column("description",sa.Text(),nullable=False,server_default=""), sa.Column("severity",sa.String(16),nullable=False,server_default="major"), sa.Column("priority",sa.String(16),nullable=False,server_default="medium"), sa.Column("status",sa.String(24),nullable=False,server_default="open"), sa.Column("platform",sa.String(24),nullable=False,server_default="unknown"), sa.Column("build_id",sa.String(64),sa.ForeignKey("application_builds.id")), sa.Column("test_case_id",sa.String(64),sa.ForeignKey("test_cases.id")), sa.Column("execution_id",sa.String(64),sa.ForeignKey("executions.id")), sa.Column("assignee_user_id",sa.String(64),sa.ForeignKey("users.id")), sa.Column("external_ref",sa.String(160),nullable=False,server_default=""), sa.Column("created_by",sa.String(64),sa.ForeignKey("users.id"),nullable=False), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False), sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False), sa.Column("resolved_at",sa.DateTime(timezone=True)))
    for col in ["project_id","severity","status","build_id","test_case_id","execution_id"]: op.create_index(f"ix_defects_{col}","defects",[col])
    op.create_table("release_decisions", sa.Column("id",sa.String(64),primary_key=True), sa.Column("project_id",sa.String(64),sa.ForeignKey("projects.id",ondelete="CASCADE"),nullable=False), sa.Column("build_id",sa.String(64),sa.ForeignKey("application_builds.id")), sa.Column("version_label",sa.String(100),nullable=False,server_default=""), sa.Column("decision",sa.String(16),nullable=False), sa.Column("rationale",sa.Text(),nullable=False,server_default=""), sa.Column("conditions",sa.JSON(),nullable=False), sa.Column("metrics_snapshot",sa.JSON(),nullable=False), sa.Column("decided_by",sa.String(64),sa.ForeignKey("users.id"),nullable=False), sa.Column("created_at",sa.DateTime(timezone=True),nullable=False))
    op.create_index("ix_release_decisions_project_id","release_decisions",["project_id"]); op.create_index("ix_release_decisions_build_id","release_decisions",["build_id"]); op.create_index("ix_release_decisions_decision","release_decisions",["decision"])

    # Preserve legacy project groupings already stored as strings on test cases/builds.
    from datetime import datetime, timezone
    from uuid import uuid4
    import re
    conn = op.get_bind()
    owner = conn.execute(sa.text("SELECT id FROM users WHERE role='admin' ORDER BY created_at LIMIT 1")).scalar()
    if owner is None:
        owner = conn.execute(sa.text("SELECT id FROM users ORDER BY created_at LIMIT 1")).scalar()
    legacy_names = set()
    legacy_names.update(x[0] for x in conn.execute(sa.text("SELECT DISTINCT project FROM test_cases WHERE project IS NOT NULL AND TRIM(project) <> ''")).all())
    legacy_names.update(x[0] for x in conn.execute(sa.text("SELECT DISTINCT project FROM application_builds WHERE project IS NOT NULL AND TRIM(project) <> ''")).all())
    used_keys = set()
    stamp = datetime.now(timezone.utc)
    for legacy_name in sorted(legacy_names):
        base = re.sub(r"[^A-Z0-9]+", "-", str(legacy_name).upper()).strip("-")[:24] or "LEGACY"
        key = base; suffix = 1
        while key in used_keys:
            suffix += 1; key = f"{base[:27]}-{suffix}"
        used_keys.add(key); project_id = str(uuid4())
        conn.execute(sa.text("INSERT INTO projects (id,key,name,description,product,status,owner_user_id,created_at,updated_at) VALUES (:id,:key,:name,:description,:product,:status,:owner,:created,:updated)"), {"id":project_id,"key":key,"name":str(legacy_name)[:180],"description":"Migrated from existing AutoPilotQE project grouping.","product":"","status":"active","owner":owner,"created":stamp,"updated":stamp})
        if owner:
            conn.execute(sa.text("INSERT INTO project_members (id,project_id,user_id,project_role,added_by,created_at) VALUES (:id,:project,:user,'owner',:added,:created)"), {"id":str(uuid4()),"project":project_id,"user":owner,"added":owner,"created":stamp})
        conn.execute(sa.text("UPDATE test_cases SET project=:key WHERE project=:name"), {"key":key,"name":legacy_name})
        conn.execute(sa.text("UPDATE application_builds SET project=:key WHERE project=:name"), {"key":key,"name":legacy_name})

def downgrade():
    for table, cols in [("release_decisions",["decision","build_id","project_id"]),("defects",["execution_id","test_case_id","build_id","status","severity","project_id"]),("requirement_test_links",["test_case_id","requirement_id"]),("requirements",["status","key","project_id"]),("project_members",["user_id","project_id"]),("projects",["owner_user_id","status","key"])]:
        for col in cols: op.drop_index(f"ix_{table}_{col}",table_name=table)
        op.drop_table(table)
