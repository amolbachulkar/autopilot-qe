"""Add project grouping to reusable test cases."""
from alembic import op
import sqlalchemy as sa

revision = "0003_test_case_projects"
down_revision = "0002_visual_checkpoints"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("test_cases", sa.Column("project", sa.String(160), nullable=False, server_default=""))


def downgrade():
    op.drop_column("test_cases", "project")
