"""Build-aware test versions and audited self-healing proposals."""
from alembic import op
import sqlalchemy as sa

revision = "0004_build_aware_self_healing"
down_revision = "0003_test_case_projects"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("test_cases", sa.Column("active_version", sa.Integer(), nullable=False, server_default="1"))
    op.create_table(
        "application_builds",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("project", sa.String(length=160), nullable=False, server_default=""),
        sa.Column("app_id", sa.String(length=240), nullable=False, server_default=""),
        sa.Column("platform", sa.String(length=24), nullable=False),
        sa.Column("version_name", sa.String(length=80), nullable=False, server_default="unknown"),
        sa.Column("build_number", sa.String(length=80), nullable=False, server_default="unknown"),
        sa.Column("fingerprint", sa.String(length=64), nullable=False),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("fingerprint", name="uq_application_build_fingerprint"),
    )
    op.create_index("ix_application_builds_project", "application_builds", ["project"])
    op.create_index("ix_application_builds_app_id", "application_builds", ["app_id"])
    op.create_index("ix_application_builds_platform", "application_builds", ["platform"])
    op.create_index("ix_application_builds_fingerprint", "application_builds", ["fingerprint"])
    op.create_table(
        "test_case_versions",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("test_case_id", sa.String(length=64), sa.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False),
        sa.Column("version_number", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="draft"),
        sa.Column("definition", sa.JSON(), nullable=False),
        sa.Column("change_summary", sa.Text(), nullable=False, server_default=""),
        sa.Column("parent_version_id", sa.String(length=64), sa.ForeignKey("test_case_versions.id"), nullable=True),
        sa.Column("build_id", sa.String(length=64), sa.ForeignKey("application_builds.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("approved_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("test_case_id", "version_number", name="uq_test_case_version_number"),
    )
    op.create_index("ix_test_case_versions_test_case_id", "test_case_versions", ["test_case_id"])
    op.create_index("ix_test_case_versions_status", "test_case_versions", ["status"])
    op.create_index("ix_test_case_versions_build_id", "test_case_versions", ["build_id"])
    with op.batch_alter_table("executions") as batch_op:
        batch_op.add_column(sa.Column("build_id", sa.String(length=64), nullable=True))
        batch_op.add_column(sa.Column("test_case_version_id", sa.String(length=64), nullable=True))
        batch_op.create_foreign_key("fk_executions_build_id_application_builds", "application_builds", ["build_id"], ["id"])
        batch_op.create_foreign_key("fk_executions_test_case_version_id_test_case_versions", "test_case_versions", ["test_case_version_id"], ["id"])
    op.create_table(
        "healing_proposals",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("execution_id", sa.String(length=64), sa.ForeignKey("executions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("test_case_id", sa.String(length=64), sa.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False),
        sa.Column("test_case_version_id", sa.String(length=64), sa.ForeignKey("test_case_versions.id"), nullable=True),
        sa.Column("build_id", sa.String(length=64), sa.ForeignKey("application_builds.id"), nullable=True),
        sa.Column("step_index", sa.Integer(), nullable=False),
        sa.Column("original_locator", sa.JSON(), nullable=False),
        sa.Column("candidate_locator", sa.JSON(), nullable=False),
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column("evidence", sa.JSON(), nullable=False),
        sa.Column("status", sa.String(length=24), nullable=False, server_default="pending"),
        sa.Column("reviewed_by", sa.String(length=160), nullable=False, server_default=""),
        sa.Column("review_note", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("reviewed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_healing_proposals_execution_id", "healing_proposals", ["execution_id"])
    op.create_index("ix_healing_proposals_test_case_id", "healing_proposals", ["test_case_id"])
    op.create_index("ix_healing_proposals_status", "healing_proposals", ["status"])


def downgrade():
    op.drop_index("ix_healing_proposals_status", table_name="healing_proposals")
    op.drop_index("ix_healing_proposals_test_case_id", table_name="healing_proposals")
    op.drop_index("ix_healing_proposals_execution_id", table_name="healing_proposals")
    op.drop_table("healing_proposals")
    with op.batch_alter_table("executions") as batch_op:
        batch_op.drop_constraint("fk_executions_test_case_version_id_test_case_versions", type_="foreignkey")
        batch_op.drop_constraint("fk_executions_build_id_application_builds", type_="foreignkey")
        batch_op.drop_column("test_case_version_id")
        batch_op.drop_column("build_id")
    op.drop_index("ix_test_case_versions_build_id", table_name="test_case_versions")
    op.drop_index("ix_test_case_versions_status", table_name="test_case_versions")
    op.drop_index("ix_test_case_versions_test_case_id", table_name="test_case_versions")
    op.drop_table("test_case_versions")
    op.drop_index("ix_application_builds_fingerprint", table_name="application_builds")
    op.drop_index("ix_application_builds_platform", table_name="application_builds")
    op.drop_index("ix_application_builds_app_id", table_name="application_builds")
    op.drop_index("ix_application_builds_project", table_name="application_builds")
    op.drop_table("application_builds")
    op.drop_column("test_cases", "active_version")
