"""Add Applitools visual checkpoint definitions."""
from alembic import op
import sqlalchemy as sa

revision = "0002_visual_checkpoints"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("visual_checkpoints",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("test_case_id", sa.String(64), sa.ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(180), nullable=False),
        sa.Column("scope", sa.String(24), nullable=False, server_default="full_page"),
        sa.Column("selector", sa.Text(), nullable=False, server_default=""),
        sa.Column("selector_type", sa.String(24), nullable=False, server_default="css"),
        sa.Column("match_level", sa.String(24), nullable=False, server_default="Dynamic"),
        sa.Column("after_step", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("ignore_selectors", sa.JSON(), nullable=False),
        sa.Column("layout_selectors", sa.JSON(), nullable=False),
        sa.Column("mask_selectors", sa.JSON(), nullable=False),
        sa.Column("wait_for_selector", sa.Text(), nullable=False, server_default=""),
        sa.Column("full_page", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("disable_animations", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("hide_caret", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False))
    op.create_index("ix_visual_checkpoints_test_case_id", "visual_checkpoints", ["test_case_id"])

def downgrade():
    op.drop_index("ix_visual_checkpoints_test_case_id", table_name="visual_checkpoints")
    op.drop_table("visual_checkpoints")
