"""Initial AutoPilotQE schema."""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("devices",
        sa.Column("id", sa.String(64), primary_key=True), sa.Column("name", sa.String(160), nullable=False),
        sa.Column("platform", sa.String(20), nullable=False), sa.Column("os_version", sa.String(40), nullable=False),
        sa.Column("device_type", sa.String(30), nullable=False), sa.Column("provider", sa.String(30), nullable=False),
        sa.Column("status", sa.String(30), nullable=False), sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False))
    op.create_table("test_cases",
        sa.Column("id", sa.String(64), primary_key=True), sa.Column("title", sa.String(240), nullable=False),
        sa.Column("description", sa.Text(), nullable=False), sa.Column("platform", sa.String(20), nullable=False),
        sa.Column("app_id", sa.String(240), nullable=False), sa.Column("prerequisites", sa.Text(), nullable=False),
        sa.Column("test_data", sa.JSON(), nullable=False), sa.Column("steps", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False), sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False))
    op.create_table("recording_sessions",
        sa.Column("id", sa.String(64), primary_key=True), sa.Column("title", sa.String(240), nullable=False),
        sa.Column("device_id", sa.String(64), nullable=False), sa.Column("app_id", sa.String(240), nullable=False),
        sa.Column("status", sa.String(30), nullable=False), sa.Column("prerequisites", sa.Text(), nullable=False),
        sa.Column("test_data", sa.JSON(), nullable=False), sa.Column("steps", sa.JSON(), nullable=False),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False), sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True))
    op.create_table("executions",
        sa.Column("id", sa.String(64), primary_key=True), sa.Column("test_case_id", sa.String(64), sa.ForeignKey("test_cases.id"), nullable=False),
        sa.Column("device_id", sa.String(64), nullable=False), sa.Column("status", sa.String(30), nullable=False),
        sa.Column("result", sa.JSON(), nullable=False), sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index("ix_executions_started_at", "executions", ["started_at"])
    op.create_index("ix_recordings_started_at", "recording_sessions", ["started_at"])

def downgrade():
    op.drop_index("ix_recordings_started_at", table_name="recording_sessions")
    op.drop_index("ix_executions_started_at", table_name="executions")
    op.drop_table("executions"); op.drop_table("recording_sessions"); op.drop_table("test_cases"); op.drop_table("devices")
