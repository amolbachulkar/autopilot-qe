import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.main import app
from app.core.database import Base, get_db

@pytest.fixture()
def client():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    TestingSession = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(bind=engine)
    def override_db():
        db = TestingSession()
        try: yield db
        finally: db.close()
    app.dependency_overrides[get_db] = override_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=engine)
    engine.dispose()

def test_health(client):
    response = client.get('/api/v1/health')
    assert response.status_code == 200
    assert response.json()['status'] == 'ok'

def test_readiness(client):
    response = client.get('/api/v1/ready')
    assert response.status_code == 200
    assert response.json()['database'] == 'connected'

def test_create_and_read_test_case(client):
    response = client.post('/api/v1/tests', json={"title":"API-created test","steps":[{"action":"tap","target":{"accessibility_id":"continue"}}]})
    assert response.status_code == 200
    test_id = response.json()['id']
    fetched = client.get(f'/api/v1/tests/{test_id}')
    assert fetched.status_code == 200
    assert fetched.json()['steps'][0]['action'] == 'tap'

def test_invalid_platform_rejected(client):
    response = client.post('/api/v1/devices', json={"id":"x","name":"Bad","platform":"windows"})
    assert response.status_code == 422

def test_recording_lifecycle(client):
    created = client.post('/api/v1/recordings', json={"title":"Login flow","test_data":{"user":"qa"}})
    session_id = created.json()['id']
    step = client.post(f'/api/v1/recordings/{session_id}/steps', json={"action":"tap","target":{"accessibility_id":"login"}})
    assert step.status_code == 200 and step.json()['step_number'] == 1
    stopped = client.post(f'/api/v1/recordings/{session_id}/stop')
    assert stopped.json()['status'] == 'completed'
    saved = client.post(f'/api/v1/recordings/{session_id}/save-as-test')
    assert saved.status_code == 200 and saved.json()['steps'] == 1

def test_execution_claim_and_completion(client):
    device = client.post('/api/v1/devices', json={"id":"emulator-5554","name":"Pixel API 35","platform":"android","device_type":"emulator"})
    assert device.status_code == 200
    test = client.post('/api/v1/tests', json={"title":"Queued journey","steps":[{"action":"wait","value":"1"}]})
    test_id = test.json()['id']
    queued = client.post(f'/api/v1/tests/{test_id}/execute', json={"device_id":"emulator-5554"})
    assert queued.status_code == 200
    claimed = client.post('/api/v1/agent/executions/claim', json={"device_id":"emulator-5554"})
    execution = claimed.json()['execution']
    assert execution['test_case_id'] == test_id
    completed = client.post(f"/api/v1/executions/{queued.json()['execution_id']}/complete", json={"status":"passed","result":{"steps":[{"status":"passed"}]}})
    assert completed.status_code == 200
    assert completed.json()['status'] == 'passed'

def test_cannot_save_active_recording(client):
    created = client.post('/api/v1/recordings', json={"title":"Still recording"})
    response = client.post(f"/api/v1/recordings/{created.json()['id']}/save-as-test")
    assert response.status_code == 409

def test_api_key_required_when_configured(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', 'a' * 40)
    assert client.get('/api/v1/tests').status_code == 401
    assert client.get('/api/v1/tests', headers={'X-API-Key': 'a' * 40}).status_code == 403
    assert client.post('/api/v1/agent/executions/claim', headers={'X-API-Key': 'a' * 40}, json={'device_id':'no-device'}).status_code == 200
    monkeypatch.setattr(settings, 'api_key', '')


def test_provider_status_and_web_profiles(client):
    providers = client.get('/api/v1/providers')
    assert providers.status_code == 200
    assert set(providers.json()) == {'local', 'sauce', 'headspin', 'applitools', 'playstation'}
    browsers = client.get('/api/v1/web/browsers')
    assert browsers.status_code == 200
    assert any(x['id'] == 'local-chromium' for x in browsers.json()['browsers'])

def test_register_web_browser_and_create_web_test(client):
    registered = client.post('/api/v1/web/browsers/register', json={
        'id': 'local-chromium', 'name': 'Chromium local', 'browser': 'chromium',
        'provider': 'local', 'base_url': 'https://example.com'
    })
    assert registered.status_code == 200
    assert registered.json()['platform'] == 'web'
    test = client.post('/api/v1/tests', json={
        'title': 'Website smoke', 'platform': 'web', 'app_id': 'https://example.com',
        'steps': [{'action': 'navigate', 'value': 'https://example.com'},
                  {'action': 'assert_text', 'value': 'Example Domain'}]
    })
    assert test.status_code == 200
    queued = client.post(f"/api/v1/tests/{test.json()['id']}/execute", json={'device_id': 'local-chromium'})
    assert queued.status_code == 200 and queued.json()['status'] == 'queued'


def test_headspin_discovery_registers_safe_device_metadata(client, monkeypatch):
    from app.api import routes
    monkeypatch.setattr(routes, 'fetch_device_configs', lambda: {
        'device-123': {
            'host': 'proxy.example.headspin.io',
            'driver_url': 'https://proxy.example.headspin.io/v0/SECRET/wd/hub',
            'capabilities': {'platformName': 'Android', 'deviceName': 'Pixel QA', 'udid': 'device-123', 'platformVersion': '15', 'automationName': 'UiAutomator2'}
        }
    })
    response = client.post('/api/v1/providers/headspin/discover')
    assert response.status_code == 200
    assert response.json()['discovered'] == 1
    assert 'SECRET' not in response.text
    devices = client.get('/api/v1/devices').json()
    headspin_device = next(d for d in devices if d['id'] == 'device-123')
    assert headspin_device['provider'] == 'headspin'
    assert 'driver_url' not in str(headspin_device['metadata'])


def test_recording_saved_with_device_platform(client):
    client.post('/api/v1/devices', json={"id":"browser-local-chromium","name":"Chromium","platform":"web","device_type":"browser"})
    session = client.post('/api/v1/recordings', json={"title":"Captured web flow","device_id":"browser-local-chromium","app_id":"https://example.com"}).json()
    client.post(f"/api/v1/recordings/{session['id']}/steps", json={"action":"navigate","value":"https://example.com"})
    client.post(f"/api/v1/recordings/{session['id']}/stop")
    saved = client.post(f"/api/v1/recordings/{session['id']}/save-as-test").json()
    fetched = client.get(f"/api/v1/tests/{saved['id']}").json()
    assert fetched['platform'] == 'web'

def test_export_web_test_to_playwright_and_selenium(client):
    test = client.post('/api/v1/tests', json={
        "title":"Web login", "platform":"web", "test_data":{"EMAIL":"qa@example.com"},
        "steps":[{"action":"navigate","value":"https://example.com"},
                 {"action":"fill","target":{"css":"#email"},"value":"${EMAIL}"},
                 {"action":"click","target":{"test_id":"login"}},
                 {"action":"assert_text","value":"Welcome"}]
    }).json()
    for target in ('playwright','selenium'):
        response = client.get(f"/api/v1/tests/{test['id']}/export?target={target}")
        assert response.status_code == 200
        assert 'def test_autopilotqe_generated' in response.json()['content'] if target == 'playwright' else 'webdriver.Chrome' in response.json()['content']
        compile(response.json()['content'], response.json()['filename'], 'exec')

def test_export_mobile_test_to_appium(client):
    test = client.post('/api/v1/tests', json={"title":"Android login","platform":"android","app_id":"com.example","steps":[{"action":"tap","target":{"accessibility_id":"login"}}]}).json()
    response = client.get(f"/api/v1/tests/{test['id']}/export?target=appium")
    assert response.status_code == 200
    compile(response.json()['content'], response.json()['filename'], 'exec')
    assert 'AppiumBy.ACCESSIBILITY_ID' in response.json()['content']

def test_reject_browser_export_for_native_test(client):
    test = client.post('/api/v1/tests', json={"title":"Android test","platform":"android"}).json()
    assert client.get(f"/api/v1/tests/{test['id']}/export?target=playwright").status_code == 422


def test_recording_discovers_variables_and_test_data_can_be_updated(client):
    session = client.post('/api/v1/recordings', json={"title":"Form journey"}).json()
    client.post(f"/api/v1/recordings/{session['id']}/steps", json={"action":"fill","value":"${EMAIL}"})
    client.post(f"/api/v1/recordings/{session['id']}/stop")
    saved = client.post(f"/api/v1/recordings/{session['id']}/save-as-test").json()
    fetched = client.get(f"/api/v1/tests/{saved['id']}").json()
    assert fetched['test_data']['EMAIL'] == ''
    updated = client.patch(f"/api/v1/tests/{saved['id']}/test-data", json={"test_data":{"EMAIL":"qa@example.com"}})
    assert updated.status_code == 200
    assert updated.json()['test_data']['EMAIL'] == 'qa@example.com'

def test_execution_rejects_wrong_platform_device(client):
    device = client.post('/api/v1/devices', json={"id":"android-1","name":"Android","platform":"android"})
    test = client.post('/api/v1/tests', json={"title":"Web test","platform":"web"}).json()
    response = client.post(f"/api/v1/tests/{test['id']}/execute", json={"device_id":"android-1"})
    assert response.status_code == 422


def test_get_recording_returns_live_step_timeline(client):
    session = client.post('/api/v1/recordings', json={"title":"Live timeline"}).json()
    client.post(f"/api/v1/recordings/{session['id']}/steps", json={"action":"click","target":{"css":"#submit"}})
    result = client.get(f"/api/v1/recordings/{session['id']}")
    assert result.status_code == 200
    assert result.json()['steps'][0]['target']['css'] == '#submit'


def test_ios_appium_script_defaults_to_ios_and_uses_bundle_id(client):
    test = client.post('/api/v1/tests', json={"title":"iOS test","platform":"ios","app_id":"com.example.ios","steps":[{"action":"launch"}]}).json()
    response = client.get(f"/api/v1/tests/{test['id']}/export?target=appium")
    assert response.status_code == 200
    script = response.json()['content']
    assert "os.getenv('MOBILE_PLATFORM', 'ios')" in script
    assert "os.getenv('APP_ID', 'com.example.ios')" in script
    compile(script, 'ios_generated.py', 'exec')

def test_visual_checkpoint_crud_and_visual_script(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'applitools_api_key', 'test-api-key')
    test = client.post('/api/v1/tests', json={
        'title': 'Visual dashboard', 'platform': 'web', 'app_id': 'https://example.com',
        'steps': [{'action': 'navigate', 'value': 'https://example.com'}, {'action': 'assert_title', 'value': 'Example Domain'}]
    }).json()
    checkpoint = client.post(f"/api/v1/tests/{test['id']}/visual-checkpoints", json={
        'name': 'Dashboard main panel', 'scope': 'element', 'selector': '.dashboard',
        'match_level': 'Dynamic', 'after_step': 2,
        'ignore_selectors': ['.ad-slot'], 'layout_selectors': ['.balance-card'],
        'mask_selectors': ['[data-private]']
    })
    assert checkpoint.status_code == 200, checkpoint.text
    assert checkpoint.json()['after_step'] == 2
    assert checkpoint.json()['mask_selectors'] == ['[data-private]']
    listed = client.get(f"/api/v1/tests/{test['id']}/visual-checkpoints")
    assert len(listed.json()) == 1
    for target in ('playwright', 'selenium'):
        script = client.get(f"/api/v1/tests/{test['id']}/visual-script?target={target}")
        assert script.status_code == 200, script.text
        compile(script.json()['content'], script.json()['filename'], 'exec')
    deleted = client.delete(f"/api/v1/visual-checkpoints/{checkpoint.json()['id']}")
    assert deleted.status_code == 200
    assert client.get(f"/api/v1/tests/{test['id']}/visual-checkpoints").json() == []


def test_visual_element_requires_selector(client):
    test = client.post('/api/v1/tests', json={'title': 'Visual test', 'platform': 'web'}).json()
    response = client.post(f"/api/v1/tests/{test['id']}/visual-checkpoints", json={
        'name': 'Empty selector', 'scope': 'element'
    })
    assert response.status_code == 422


def test_execution_claim_includes_visual_checkpoints(client):
    client.post('/api/v1/devices', json={'id': 'visual-browser', 'name': 'Visual browser', 'platform': 'web', 'device_type': 'browser'})
    test = client.post('/api/v1/tests', json={'title': 'Visual run', 'platform': 'web', 'steps': [{'action': 'wait', 'value': '0.1'}]}).json()
    cp = client.post(f"/api/v1/tests/{test['id']}/visual-checkpoints", json={'name': 'Before', 'scope': 'viewport', 'after_step': 0}).json()
    queued = client.post(f"/api/v1/tests/{test['id']}/execute", json={'device_id': 'visual-browser'}).json()
    claimed = client.post('/api/v1/agent/executions/claim', json={'device_id': 'visual-browser'}).json()['execution']
    assert claimed['visual_checkpoints'][0]['id'] == cp['id']


def test_visual_status_does_not_expose_api_key(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'applitools_api_key', 'sensitive-eyes-key')
    response = client.get('/api/v1/visual/status')
    assert response.status_code == 200
    assert response.json()['configured'] is True
    assert 'sensitive-eyes-key' not in response.text

def test_visual_script_target_must_match_platform(client):
    test = client.post('/api/v1/tests', json={'title': 'Native test', 'platform': 'android'}).json()
    client.post(f"/api/v1/tests/{test['id']}/visual-checkpoints", json={'name': 'Native home'})
    assert client.get(f"/api/v1/tests/{test['id']}/visual-script?target=playwright").status_code == 422

def test_native_visual_script_export_supports_appium_accessibility_id(client):
    test = client.post('/api/v1/tests', json={
        'title': 'iOS visual flow', 'platform': 'ios', 'app_id': 'com.example.ios',
        'steps': [{'action': 'launch'}, {'action': 'tap', 'target': {'accessibility_id': 'continue'}}]
    }).json()
    cp = client.post(f"/api/v1/tests/{test['id']}/visual-checkpoints", json={
        'name': 'Welcome screen', 'scope': 'element', 'selector_type': 'accessibility_id',
        'selector': 'welcome_header', 'after_step': 1
    })
    assert cp.status_code == 200
    response = client.get(f"/api/v1/tests/{test['id']}/visual-script?target=appium")
    assert response.status_code == 200
    assert 'AppiumBy.ACCESSIBILITY_ID' in response.json()['content']
    compile(response.json()['content'], response.json()['filename'], 'exec')

def test_cross_platform_scenario_can_run_on_mobile_appium_device(client):
    device = client.post('/api/v1/devices', json={"id":"ps-app-android","name":"PlayStation App QA phone","platform":"android"})
    assert device.status_code == 200
    test = client.post('/api/v1/tests', json={
        "title":"PS5 game appears in PlayStation App", "project":"PlayStation QA", "platform":"cross_platform",
        "app_id":"com.scee.psxandroid", "test_data":{"GAME_TITLE":"ASTRO BOT"},
        "steps":[{"action":"launch","metadata":{"app_id":"com.scee.psxandroid"}},
                 {"action":"wait_for_text","value":"ASTRO BOT","timeout":45}]
    })
    assert test.status_code == 200
    assert client.get(f"/api/v1/tests/{test.json()['id']}").json()['project'] == 'PlayStation QA'
    queued = client.post(f"/api/v1/tests/{test.json()['id']}/execute", json={"device_id":"ps-app-android"})
    assert queued.status_code == 200
    claimed = client.post('/api/v1/agent/executions/claim', json={"device_id":"ps-app-android"}).json()['execution']
    assert claimed['steps'][1]['action'] == 'wait_for_text'

def test_cross_platform_scenario_rejects_web_worker_device(client):
    client.post('/api/v1/devices', json={"id":"browser-for-cross","name":"Browser","platform":"web","device_type":"browser"})
    test = client.post('/api/v1/tests', json={"title":"Cross platform", "platform":"cross_platform"}).json()
    response = client.post(f"/api/v1/tests/{test['id']}/execute", json={"device_id":"browser-for-cross"})
    assert response.status_code == 422

def test_build_aware_versions_healing_approval_and_rollback(client):
    test = client.post('/api/v1/tests', json={
        'title': 'Login test', 'project': 'Mobile QA', 'platform': 'android',
        'steps': [{'action': 'tap', 'target': {'accessibility_id': 'login_button', 'text': 'Sign in'}}]
    }).json()
    versions = client.get(f"/api/v1/tests/{test['id']}/versions").json()
    assert len(versions) == 1 and versions[0]['status'] == 'approved'
    initial_version = versions[0]

    build = client.post('/api/v1/builds', json={
        'project': 'Mobile QA', 'app_id': 'com.example.app', 'platform': 'android',
        'version_name': '2.0.0', 'build_number': '200'
    }).json()
    assert build['created'] is True and len(build['fingerprint']) == 64
    duplicate = client.post('/api/v1/builds', json={
        'project': 'Mobile QA', 'app_id': 'com.example.app', 'platform': 'android',
        'version_name': '2.0.0', 'build_number': '200'
    }).json()
    assert duplicate['created'] is False and duplicate['id'] == build['id']

    client.post('/api/v1/devices', json={'id': 'qa-android', 'name': 'QA Android', 'platform': 'android'})
    queued = client.post(f"/api/v1/tests/{test['id']}/execute", json={
        'device_id': 'qa-android', 'build_id': build['id']
    }).json()
    claimed = client.post('/api/v1/agent/executions/claim', json={'device_id': 'qa-android'}).json()['execution']
    assert claimed['build']['id'] == build['id']
    assert claimed['test_case_version_id'] == initial_version['id']

    completed = client.post(f"/api/v1/executions/{queued['execution_id']}/complete", json={
        'status': 'passed', 'result': {'status': 'passed', 'healing_events': [{
            'step_index': 0, 'original_locator': {'accessibility_id': 'login_button', 'text': 'Sign in'},
            'candidate_locator': {'accessibility_id': 'signin_button'}, 'confidence': 0.985,
            'evidence': {'matched_by': ['exact_semantic_text']}
        }]}
    })
    assert completed.status_code == 200
    proposals = client.get('/api/v1/healing-proposals?status=pending').json()
    assert len(proposals) == 1 and proposals[0]['build_id'] == build['id']

    accepted = client.post(f"/api/v1/healing-proposals/{proposals[0]['id']}/accept", json={
        'reviewed_by': 'qa', 'review_note': 'Verified replacement in build 200'
    }).json()
    draft = accepted['draft_version']
    assert draft['status'] == 'draft'
    assert draft['definition']['steps'][0]['target'] == {'accessibility_id': 'signin_button'}

    approved = client.post(f"/api/v1/versions/{draft['id']}/approve", json={
        'reviewed_by': 'qa', 'review_note': 'Regression passed'
    })
    assert approved.status_code == 200 and approved.json()['status'] == 'approved'
    current = client.get(f"/api/v1/tests/{test['id']}").json()
    # Build-scoped locator updates do not overwrite the global baseline.
    assert current['steps'][0]['target'] == {'accessibility_id': 'login_button', 'text': 'Sign in'}
    rerun = client.post(f"/api/v1/tests/{test['id']}/execute", json={'device_id': 'qa-android', 'build_id': build['id']}).json()
    rerun_claim = client.post('/api/v1/agent/executions/claim', json={'device_id': 'qa-android'}).json()['execution']
    assert rerun_claim['steps'][0]['target'] == {'accessibility_id': 'signin_button'}
    exported = client.get(f"/api/v1/tests/{test['id']}/export?target=appium&build_id={build['id']}")
    assert exported.status_code == 200 and 'signin_button' in exported.json()['content']

    rollback = client.post(f"/api/v1/tests/{test['id']}/rollback/{initial_version['id']}", json={
        'reviewed_by': 'release-manager', 'review_note': 'Restore known-good locator'
    })
    assert rollback.status_code == 200
    assert rollback.json()['version_number'] == 3
    assert rollback.json()['definition']['steps'][0]['target']['accessibility_id'] == 'login_button'

    impact = client.get(f"/api/v1/builds/{build['id']}/impact")
    assert impact.status_code == 200 and impact.json()['compatible_tests'] == 1
    assert impact.json()['tests'][0]['build_specific_version'] == 2


def test_low_confidence_healing_cannot_be_accepted(client):
    test = client.post('/api/v1/tests', json={'title': 'Low confidence', 'steps': [{'action': 'tap'}]}).json()
    client.post('/api/v1/devices', json={'id': 'qa-android-2', 'name': 'QA Android 2', 'platform': 'android'})
    queued = client.post(f"/api/v1/tests/{test['id']}/execute", json={'device_id': 'qa-android-2'}).json()
    client.post('/api/v1/agent/executions/claim', json={'device_id': 'qa-android-2'})
    client.post(f"/api/v1/executions/{queued['execution_id']}/complete", json={'status': 'failed', 'result': {
        'healing_events': [{'step_index': 0, 'original_locator': {'id': 'old'}, 'candidate_locator': {'id': 'new'}, 'confidence': 0.6}]
    }})
    proposal = client.get('/api/v1/healing-proposals').json()[0]
    response = client.post(f"/api/v1/healing-proposals/{proposal['id']}/accept", json={'reviewed_by': 'qa'})
    assert response.status_code == 409

def test_ps5_build_can_be_associated_with_cross_platform_mobile_execution(client):
    test = client.post('/api/v1/tests', json={
        'title': 'Launch PS5 game and verify PlayStation App activity',
        'project': 'PlayStation QA', 'platform': 'cross_platform', 'app_id': 'com.scee.psxandroid',
        'steps': [{'action': 'ps5_launch', 'target': {'title_id': 'PPSA00000'}},
                  {'action': 'wait_for_text', 'expected': {'text': 'Playing'}}]
    }).json()
    device = client.post('/api/v1/devices', json={'id': 'ps-app-android', 'name': 'PlayStation App Android', 'platform': 'android'})
    assert device.status_code == 200
    build = client.post('/api/v1/builds', json={
        'project': 'PlayStation QA', 'app_id': 'PPSA00000', 'platform': 'ps5',
        'version_name': '1.2.0', 'build_number': '120'
    }).json()
    queued = client.post(f"/api/v1/tests/{test['id']}/execute", json={
        'device_id': 'ps-app-android', 'build_id': build['id']
    })
    assert queued.status_code == 200
    claimed = client.post('/api/v1/agent/executions/claim', json={'device_id': 'ps-app-android'}).json()['execution']
    assert claimed['build']['platform'] == 'ps5'
    assert claimed['steps'][0]['action'] == 'ps5_launch'

def test_websocket_auth_accepts_server_side_proxy_header(monkeypatch):
    from app.main import valid_ws_key
    from app.core.config import settings
    class FakeWebSocket:
        headers = {'x-api-key': 'p' * 40}
        query_params = {}
    monkeypatch.setattr(settings, 'api_key', 'p' * 40)
    assert valid_ws_key(FakeWebSocket(), allow_service_key=True) is True
    monkeypatch.setattr(settings, 'api_key', '')


def test_signup_login_and_revocable_session(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    signup = client.post('/api/v1/auth/signup', json={
        'email': 'tester@example.com', 'full_name': 'QA Tester', 'password': 'LongSecurePass123!', 'role': 'tester'
    })
    assert signup.status_code == 200
    token = signup.json()['access_token']
    assert signup.json()['user']['role'] == 'tester'
    assert client.get('/api/v1/auth/me', headers={'Authorization': f'Bearer {token}'}).status_code == 200
    login = client.post('/api/v1/auth/login', json={'email':'tester@example.com','password':'LongSecurePass123!'})
    assert login.status_code == 200 and login.json()['user']['role'] == 'tester'
    assert client.get('/api/v1/tests').status_code == 401
    assert client.post('/api/v1/auth/logout', headers={'Authorization': f'Bearer {token}'}).status_code == 200
    assert client.get('/api/v1/auth/me', headers={'Authorization': f'Bearer {token}'}).status_code == 401


def test_role_invites_and_qe_lead_analytics_access(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    monkeypatch.setattr(settings, 'role_invite_codes', '{"qe_lead":"invite-qa-lead-2026"}')
    denied = client.post('/api/v1/auth/signup', json={
        'email': 'lead-no-code@example.com', 'full_name': 'Lead', 'password': 'LongSecurePass123!', 'role': 'qe_lead'
    })
    assert denied.status_code == 403
    created = client.post('/api/v1/auth/signup', json={
        'email': 'lead@example.com', 'full_name': 'QE Lead', 'password': 'LongSecurePass123!',
        'role': 'qe_lead', 'invite_code': 'invite-qa-lead-2026'
    })
    token = created.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    assert client.get('/api/v1/analytics/summary?days=7', headers=headers).status_code == 200
    assert client.get('/api/v1/auth/users', headers=headers).status_code == 403
    assert client.post('/api/v1/builds', headers=headers, json={
        'project':'Analytics QA','platform':'android','version_name':'1.0','build_number':'1'
    }).status_code == 200


def test_tester_cannot_access_qe_analytics_or_admin_user_management(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    signup = client.post('/api/v1/auth/signup', json={
        'email':'tester2@example.com','full_name':'Tester','password':'LongSecurePass123!','role':'tester'
    })
    headers = {'Authorization': f"Bearer {signup.json()['access_token']}"}
    assert client.get('/api/v1/analytics/summary', headers=headers).status_code == 403
    assert client.get('/api/v1/auth/users', headers=headers).status_code == 403
    assert client.post('/api/v1/agent/executions/claim', headers=headers, json={'device_id':'tester-device'}).status_code == 403
    created_test = client.post('/api/v1/tests', headers=headers, json={'title':'Tester-created case'}).json()
    assert created_test['id']
    assert client.post(f"/api/v1/tests/{created_test['id']}/visual-checkpoints", headers=headers,
                       json={'name':'Restricted checkpoint','scope':'viewport'}).status_code == 403
    assert client.post('/api/v1/auth/signup', json={'email':'admin-self@example.com','full_name':'No Admin','password':'LongSecurePass123!','role':'admin'}).status_code == 422


def test_build_analytics_comparison_uses_exact_build_execution_tags(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', False)
    test = client.post('/api/v1/tests', json={'title':'Build compare test','project':'Compare QA','platform':'android'}).json()
    client.post('/api/v1/devices', json={'id':'compare-device','name':'Android QA','platform':'android'})
    builds=[]
    for version, number, status in [('1.0','100','failed'),('1.1','110','passed')]:
        build=client.post('/api/v1/builds',json={'project':'Compare QA','platform':'android','version_name':version,'build_number':number}).json()
        builds.append(build)
        queued=client.post(f"/api/v1/tests/{test['id']}/execute",json={'device_id':'compare-device','build_id':build['id']}).json()
        client.post('/api/v1/agent/executions/claim',json={'device_id':'compare-device'})
        client.post(f"/api/v1/executions/{queued['execution_id']}/complete",json={'status':status,'result':{'failure_analysis':{'category':'assertion_mismatch'}} if status=='failed' else {}})
    compared=client.get(f"/api/v1/analytics/compare?build_a={builds[0]['id']}&build_b={builds[1]['id']}")
    assert compared.status_code == 200
    result=compared.json()
    assert result['build_a']['metrics']['failed'] == 1
    assert result['build_b']['metrics']['passed'] == 1
    assert result['delta']['pass_rate_pp'] == 100.0


def test_bootstrap_admin_is_provisioned_idempotently(client, monkeypatch):
    from app.core.config import settings
    from app.services.auth import seed_admin
    from app.core.database import get_db
    monkeypatch.setattr(settings, 'bootstrap_admin_email', 'root@example.com')
    monkeypatch.setattr(settings, 'bootstrap_admin_password', 'BootstrapAdmin2026!')
    monkeypatch.setattr(settings, 'bootstrap_admin_name', 'Root Admin')
    generator = app.dependency_overrides[get_db]()
    db = next(generator)
    try:
        seed_admin(db)
        seed_admin(db)
        from app.models.entities import User
        rows = db.query(User).filter_by(email='root@example.com').all()
        assert len(rows) == 1 and rows[0].role == 'admin' and rows[0].full_name == 'Root Admin'
    finally:
        try: next(generator)
        except StopIteration: pass

def test_qmetry_config_is_encrypted_and_toggleable(client):
    response = client.put('/api/v1/integrations/qmetry', json={
        'enabled': True, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com',
        'project_key': 'MOB', 'test_case_folder_id': '123', 'org_code': 'ORG',
        'user_token': 'private-user-token', 'api_key': 'private-automation-key',
        'sync_test_cases': True, 'sync_executions': True
    })
    assert response.status_code == 200, response.text
    data = response.json()
    assert data['enabled'] is True and data['has_user_token'] and data['has_api_key']
    assert 'private-user-token' not in response.text and 'private-automation-key' not in response.text
    disabled = client.put('/api/v1/integrations/qmetry', json={
        'enabled': False, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com',
        'project_key': 'MOB', 'test_case_folder_id': '123', 'org_code': 'ORG',
        'sync_test_cases': True, 'sync_executions': True
    })
    assert disabled.status_code == 200 and disabled.json()['enabled'] is False
    assert disabled.json()['has_user_token'] is True


def test_qmetry_local_first_outbox_queues_test_case(client):
    enabled = client.put('/api/v1/integrations/qmetry', json={
        'enabled': True, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com',
        'project_key': 'MOB', 'test_case_folder_id': '123', 'org_code': 'ORG',
        'user_token': 'user-token', 'api_key': 'automation-key',
        'sync_test_cases': True, 'sync_executions': True
    })
    assert enabled.status_code == 200
    created = client.post('/api/v1/tests', json={'title':'QMetry queued test','project':'MOB','steps':[{'action':'tap','target':{'accessibility_id':'go'}}]})
    assert created.status_code == 200
    jobs = client.get('/api/v1/integrations/qmetry/jobs').json()
    assert jobs['counts'].get('pending') == 1
    assert jobs['jobs'][0]['entity_type'] == 'test_case'


def test_qmetry_connection_test_reports_missing_credentials(client):
    client.put('/api/v1/integrations/qmetry', json={
        'enabled': False, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com'
    })
    response = client.post('/api/v1/integrations/qmetry/test-connection')
    assert response.status_code == 502
    assert 'user token' in response.json()['detail'].lower()


def test_qmetry_job_retry_only_for_failed_or_deferred(client):
    from app.models.entities import QMetrySyncJob
    from datetime import datetime, timezone
    from app.core.database import get_db
    db_gen = app.dependency_overrides[get_db]()
    db = next(db_gen)
    job = QMetrySyncJob(id='job-1', idempotency_key='test:retry:1', entity_type='execution', entity_id='missing',
        status='failed', next_attempt_at=datetime.now(timezone.utc), attempts=8)
    db.add(job); db.commit(); db.close()
    try: next(db_gen)
    except StopIteration: pass
    response = client.post('/api/v1/integrations/qmetry/jobs/job-1/retry')
    assert response.status_code == 200 and response.json()['status'] == 'pending'

def test_qmetry_enterprise_outbox_worker_syncs_case_with_mapping(client, monkeypatch):
    from datetime import datetime, timezone
    from app.models.entities import QMetrySyncJob, QMetryTestMapping
    from app.core.database import get_db
    from app.services.qmetry import process_one
    import app.services.qmetry as qmetry_service

    client.put('/api/v1/integrations/qmetry', json={
        'enabled': True, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com',
        'project_key': 'MOB', 'test_case_folder_id': '123', 'org_code': 'ORG',
        'user_token': 'user-token', 'api_key': 'automation-key',
        'sync_test_cases': True, 'sync_executions': True
    })
    test = client.post('/api/v1/tests', json={'title':'Case to QMetry','project':'MOB','steps':[{'action':'tap','target':{'accessibility_id':'continue'}}]}).json()

    class FakeResponse:
        status_code=200
        text='ok'
        def json(self): return {'data': {'tcID': 1234, 'tcVersionID': 5678, 'entityKey': 'MOB-TC-1'}}
    monkeypatch.setattr(qmetry_service.httpx, 'post', lambda *a, **kw: FakeResponse())
    gen=app.dependency_overrides[get_db](); db=next(gen)
    try:
        assert process_one(db) is True
        job=db.query(QMetrySyncJob).filter_by(entity_id=test['id']).one()
        mapping=db.query(QMetryTestMapping).filter_by(test_case_id=test['id']).one()
        assert job.status == 'succeeded'
        assert mapping.external_id == '1234' and mapping.external_key == 'MOB-TC-1'
    finally:
        db.close()
        try: next(gen)
        except StopIteration: pass


def test_qmetry_qtm4j_defers_standalone_case_sync_but_accepts_result_sync(client):
    response=client.put('/api/v1/integrations/qmetry', json={
        'enabled': True, 'edition': 'qtm4j', 'base_url': 'https://example.atlassian.net',
        'project_key': 'MOB', 'api_key': 'qmetry-open-api-key',
        'jira_auth_type': 'bearer', 'jira_token': 'jira-pat',
        'sync_test_cases': True, 'sync_executions': True
    })
    assert response.status_code == 200
    test=client.post('/api/v1/tests', json={'title':'QTM4J local test'}).json()
    jobs=client.get('/api/v1/integrations/qmetry/jobs').json()
    assert not any(j['entity_type']=='test_case' and j['entity_id']==test['id'] for j in jobs['jobs'])

def test_qmetry_enterprise_pull_imports_steps_into_internal_db(client, monkeypatch):
    import app.services.qmetry as qmetry_service
    from app.core.database import get_db
    client.put('/api/v1/integrations/qmetry', json={
        'enabled': True, 'edition': 'enterprise', 'base_url': 'https://qmetry.example.com',
        'project_key': 'MOB', 'test_case_folder_id': '123', 'org_code': 'ORG', 'user_token': 'user-token'
    })
    class FakeResponse:
        status_code=200
        def __init__(self,payload): self.payload=payload
        def json(self): return self.payload
    def fake_post(url, **kwargs):
        if url.endswith('/rest/testcases/list') and kwargs.get('json',{}).get('tcFolderID'):
            return FakeResponse({'data':[{'tcID': 321, 'name':'Imported from QMetry', 'description':'Imported case', 'version':1, 'entityKey':'MOB-TC-321'}]})
        return FakeResponse({'data':{'tcID':321,'tcVersionID':654,'steps':[{'description':'Tap Continue','inputData':'','expectedOutcome':'Home appears'}]}})
    monkeypatch.setattr(qmetry_service.httpx,'post',fake_post)
    response=client.post('/api/v1/integrations/qmetry/pull-test-cases')
    assert response.status_code==200, response.text
    gen=app.dependency_overrides[get_db](); db=next(gen)
    try:
        from app.models.entities import TestCase, QMetryTestMapping
        test=db.query(TestCase).filter_by(title='Imported from QMetry').one()
        assert test.steps[0]['value']=='Tap Continue'
        mapping=db.query(QMetryTestMapping).filter_by(test_case_id=test.id).one()
        assert mapping.external_id=='321' and mapping.external_version_id=='654'
    finally:
        db.close()
        try: next(gen)
        except StopIteration: pass


def test_qmetry_imported_manual_steps_cannot_be_executed_until_mapped(client, monkeypatch):
    import app.services.qmetry as qmetry_service
    class FakeResponse:
        status_code=200
        def __init__(self,payload): self.payload=payload
        def json(self): return self.payload
    def fake_post(url, **kwargs):
        if kwargs.get("json",{}).get("tcFolderID"):
            return FakeResponse({"data":[{"tcID":777,"name":"Manual imported case","version":1}]})
        return FakeResponse({"data":{"tcID":777,"tcVersionID":888,"steps":[{"description":"Tap button","expectedOutcome":"Next screen"}]}})
    monkeypatch.setattr(qmetry_service.httpx,'post',fake_post)
    client.put('/api/v1/integrations/qmetry',json={'enabled':True,'edition':'enterprise','base_url':'https://qmetry.example.com','project_key':'MOB','test_case_folder_id':'123','org_code':'ORG','user_token':'user-token','sync_test_cases':True})
    assert client.post('/api/v1/integrations/qmetry/pull-test-cases').status_code==200
    from app.core.database import get_db
    gen=app.dependency_overrides[get_db](); db=next(gen)
    try:
        from app.models.entities import TestCase
        test=db.query(TestCase).filter_by(title='Manual imported case').one()
        test_id=test.id
    finally:
        db.close()
        try: next(gen)
        except StopIteration: pass
    client.post('/api/v1/devices',json={'id':'qmetry-device','name':'Android QA','platform':'android'})
    blocked=client.post(f'/api/v1/tests/{test_id}/execute',json={'device_id':'qmetry-device'})
    assert blocked.status_code==409 and 'manual QMetry steps' in blocked.json()['detail']

def test_product_owner_signup_is_invite_gated_and_read_only(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'role_invite_codes', '{"product_owner":"po-invite"}')
    denied = client.post('/api/v1/auth/signup', json={
        'email':'po-denied@example.com','full_name':'PO Denied','password':'StrongPass!1234',
        'role':'product_owner','invite_code':'wrong'
    })
    assert denied.status_code == 403
    signed = client.post('/api/v1/auth/signup', json={
        'email':'po@example.com','full_name':'Product Owner','password':'StrongPass!1234',
        'role':'product_owner','invite_code':'po-invite'
    })
    assert signed.status_code == 200
    token = signed.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    assert client.get('/api/v1/tests', headers=headers).status_code == 200
    assert client.get('/api/v1/analytics/summary?days=7', headers=headers).status_code == 200
    assert client.post('/api/v1/tests', headers=headers, json={'title':'Not allowed'}).status_code == 403
    assert client.post('/api/v1/auth/logout', headers=headers).status_code == 200


def test_project_workspace_links_requirements_tests_defects_and_release_decisions(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    signup=client.post('/api/v1/auth/signup',json={'email':'project-owner@example.com','full_name':'Project Owner','password':'LongSecurePass123!','role':'tester'})
    headers={'Authorization':f"Bearer {signup.json()['access_token']}"}
    project=client.post('/api/v1/projects',headers=headers,json={'name':'Mobile Experience','key':'MOBX','product':'Mobile App','description':'Shared project'} )
    assert project.status_code==200,project.text
    pid=project.json()['id']
    test=client.post('/api/v1/tests',headers=headers,json={'title':'Login smoke','platform':'android','steps':[{'action':'tap'}]}).json()
    linked=client.post(f'/api/v1/projects/{pid}/test-cases/{test["id"]}/link',headers=headers)
    assert linked.status_code==200
    req=client.post(f'/api/v1/projects/{pid}/requirements',headers=headers,json={'title':'User can sign in','acceptance_criteria':['Valid credentials are accepted'],'test_case_ids':[test['id']]})
    assert req.status_code==200,req.text
    assert req.json()['key'].startswith('MOBX-REQ-') and req.json()['test_case_ids']==[test['id']]
    bug=client.post(f'/api/v1/projects/{pid}/defects',headers=headers,json={'title':'Login button not responding','severity':'major','platform':'android','test_case_id':test['id']})
    assert bug.status_code==200,bug.text
    monkeypatch.setattr(settings, 'role_invite_codes', '{\"qe_lead\":\"invite-project-lead\"}')
    lead=client.post('/api/v1/auth/signup',json={'email':'project-qe@example.com','full_name':'Project QE Lead','password':'LongSecurePass123!','role':'qe_lead','invite_code':'invite-project-lead'}).json()
    lead_headers={'Authorization':f"Bearer {lead['access_token']}"}
    assert client.post(f'/api/v1/projects/{pid}/members',headers=headers,json={'user_id':lead['user']['id']}).status_code==200
    decision=client.post(f'/api/v1/projects/{pid}/release-decisions',headers=lead_headers,json={'decision':'conditional','version_label':'1.0.0','rationale':'One major issue accepted for pilot','conditions':['Fix before public rollout']})
    assert decision.status_code==200,decision.text
    workspace=client.get(f'/api/v1/projects/{pid}/workspace',headers=headers)
    assert workspace.status_code==200,workspace.text
    body=workspace.json()
    assert body['summary']['requirements']==1 and body['summary']['open_defects']==1
    assert len(body['test_cases'])==1 and len(body['release_decisions'])==1

def test_project_membership_scoping_and_owner_can_add_members(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    a=client.post('/api/v1/auth/signup',json={'email':'owner2@example.com','full_name':'Owner','password':'LongSecurePass123!','role':'tester'}).json()
    b=client.post('/api/v1/auth/signup',json={'email':'member2@example.com','full_name':'Member','password':'LongSecurePass123!','role':'tester'}).json()
    ha={'Authorization':f"Bearer {a['access_token']}"}; hb={'Authorization':f"Bearer {b['access_token']}"}
    p=client.post('/api/v1/projects',headers=ha,json={'name':'Scoped Project','key':'SCOPE'}).json()
    assert client.get('/api/v1/projects',headers=hb).json()==[]
    added=client.post(f"/api/v1/projects/{p['id']}/members",headers=ha,json={'user_id':b['user']['id']})
    assert added.status_code==200,added.text
    assert len(client.get('/api/v1/projects',headers=hb).json())==1

def test_critical_defect_blocks_plain_go_release_decision(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    monkeypatch.setattr(settings, 'role_invite_codes', '{\"qe_lead\":\"invite-qa-lead-2026\"}')
    signup=client.post('/api/v1/auth/signup',json={'email':'qe-lead2@example.com','full_name':'QE Lead','password':'LongSecurePass123!','role':'qe_lead','invite_code':'invite-qa-lead-2026'})
    headers={'Authorization':f"Bearer {signup.json()['access_token']}"}
    p=client.post('/api/v1/projects',headers=headers,json={'name':'Release Gate','key':'GATE'}).json()
    client.post(f"/api/v1/projects/{p['id']}/defects",headers=headers,json={'title':'Crash on launch','severity':'critical'})
    blocked=client.post(f"/api/v1/projects/{p['id']}/release-decisions",headers=headers,json={'decision':'go','rationale':'Ship it'})
    assert blocked.status_code==409
    conditional=client.post(f"/api/v1/projects/{p['id']}/release-decisions",headers=headers,json={'decision':'conditional','rationale':'Hold rollout until fixed','conditions':['Fix critical defect before release']})
    assert conditional.status_code==200


def test_product_owner_can_author_requirements_but_cannot_log_defects(client, monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, 'api_key', '')
    monkeypatch.setattr(settings, 'auth_required', True)
    monkeypatch.setattr(settings, 'role_invite_codes', '{\"product_owner\":\"invite-product-owner\"}')
    owner=client.post('/api/v1/auth/signup',json={'email':'po-workspace@example.com','full_name':'Product Owner','password':'LongSecurePass123!','role':'product_owner','invite_code':'invite-product-owner'}).json()
    headers={'Authorization':f"Bearer {owner['access_token']}"}
    project=client.post('/api/v1/projects',headers=headers,json={'name':'PO Project','key':'POW'}).json()
    requirement=client.post(f"/api/v1/projects/{project['id']}/requirements",headers=headers,json={'title':'Checkout must be accessible','acceptance_criteria':['Keyboard users can complete checkout']})
    assert requirement.status_code==200,requirement.text
    defect=client.post(f"/api/v1/projects/{project['id']}/defects",headers=headers,json={'title':'Observed defect'})
    assert defect.status_code==403
    assert client.post(f"/api/v1/projects/{project['id']}/release-decisions",headers=headers,json={'decision':'conditional','rationale':'PO records product release recommendation','conditions':['Complete acceptance review']}).status_code==200
