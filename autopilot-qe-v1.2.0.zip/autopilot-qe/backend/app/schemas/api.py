from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import Any, Literal

class StrictInput(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

class DeviceIn(StrictInput):
    id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    platform: Literal["android", "ios", "web"]
    os_version: str = Field(default="unknown", max_length=40)
    device_type: Literal["emulator", "simulator", "physical", "browser"] = "emulator"
    provider: Literal["local", "sauce", "headspin"] = "local"
    status: Literal["available", "busy", "offline", "unknown"] = "available"
    metadata_json: dict[str, Any] = Field(default_factory=dict)

class RecordingStart(StrictInput):
    title: str = Field(min_length=1, max_length=240)
    device_id: str = Field(default="", max_length=64)
    app_id: str = Field(default="", max_length=240)
    prerequisites: str = Field(default="", max_length=10_000)
    test_data: dict[str, Any] = Field(default_factory=dict)

class StepIn(StrictInput):
    action: str = Field(min_length=1, max_length=60)
    target: dict[str, Any] = Field(default_factory=dict)
    value: str | None = Field(default=None, max_length=10_000)
    expected: dict[str, Any] = Field(default_factory=dict)
    screenshot: str | None = Field(default=None, max_length=500)
    timestamp: str | None = Field(default=None, max_length=64)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("action")
    @classmethod
    def normalize_action(cls, value: str) -> str:
        return value.lower().replace(" ", "_")

class TestCaseIn(StrictInput):
    title: str = Field(min_length=1, max_length=240)
    project: str = Field(default="", max_length=160)
    description: str = Field(default="", max_length=10_000)
    platform: Literal["android", "ios", "web", "both", "cross_platform"] = "both"
    app_id: str = Field(default="", max_length=240)
    prerequisites: str = Field(default="", max_length=10_000)
    test_data: dict[str, Any] = Field(default_factory=dict)
    steps: list[dict[str, Any]] = Field(default_factory=list, max_length=500)

class ExecuteIn(StrictInput):
    device_id: str = Field(default="", max_length=64)
    build_id: str | None = Field(default=None, max_length=64)
    test_case_version_id: str | None = Field(default=None, max_length=64)
    dry_run: bool = False

class ExecutionComplete(StrictInput):
    status: Literal["passed", "failed", "error"]
    result: dict[str, Any] = Field(default_factory=dict)

class TestDataUpdate(StrictInput):
    test_data: dict[str, Any] = Field(default_factory=dict)


class VisualCheckpointIn(StrictInput):
    name: str = Field(min_length=1, max_length=180)
    scope: Literal["full_page", "viewport", "element"] = "full_page"
    selector: str = Field(default="", max_length=1000)
    selector_type: Literal["css", "xpath", "accessibility_id"] = "css"
    match_level: Literal["Strict", "Dynamic", "Layout", "IgnoreColors"] = "Dynamic"
    after_step: int = Field(default=0, ge=0, le=500)
    ignore_selectors: list[str] = Field(default_factory=list, max_length=30)
    layout_selectors: list[str] = Field(default_factory=list, max_length=30)
    mask_selectors: list[str] = Field(default_factory=list, max_length=30)
    wait_for_selector: str = Field(default="", max_length=1000)
    full_page: bool = True
    disable_animations: bool = True
    hide_caret: bool = True
    enabled: bool = True

    @field_validator("selector", "wait_for_selector")
    @classmethod
    def validate_selector_length(cls, value: str) -> str:
        return value.strip()

    @field_validator("ignore_selectors", "layout_selectors", "mask_selectors")
    @classmethod
    def validate_region_selectors(cls, values: list[str]) -> list[str]:
        cleaned = [v.strip() for v in values if v and v.strip()]
        if any(len(v) > 500 for v in cleaned):
            raise ValueError("Region selectors must be at most 500 characters")
        return cleaned

class ApplicationBuildIn(StrictInput):
    project: str = Field(default="", max_length=160)
    app_id: str = Field(default="", max_length=240)
    platform: Literal["android", "ios", "web", "ps5"]
    version_name: str = Field(default="unknown", max_length=80)
    build_number: str = Field(default="unknown", max_length=80)
    fingerprint: str = Field(default="", max_length=64)
    metadata_json: dict[str, Any] = Field(default_factory=dict)

class TestVersionIn(StrictInput):
    definition: dict[str, Any] | None = None
    build_id: str | None = Field(default=None, max_length=64)
    change_summary: str = Field(min_length=1, max_length=2000)

class VersionReviewIn(StrictInput):
    reviewed_by: str = Field(min_length=1, max_length=160)
    review_note: str = Field(default="", max_length=2000)

class HealingProposalIn(StrictInput):
    step_index: int = Field(ge=0, le=500)
    original_locator: dict[str, Any] = Field(default_factory=dict)
    candidate_locator: dict[str, Any] = Field(default_factory=dict)
    confidence: float = Field(ge=0.0, le=1.0)
    evidence: dict[str, Any] = Field(default_factory=dict)
