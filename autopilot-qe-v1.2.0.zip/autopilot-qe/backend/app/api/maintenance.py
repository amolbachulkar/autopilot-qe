from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from app.core.database import get_db
from app.models.entities import ApplicationBuild, TestCase, TestCaseVersion, HealingProposal, Execution
from app.schemas.api import ApplicationBuildIn, TestVersionIn, VersionReviewIn
from app.services.test_maintenance import definition_from_test, ensure_initial_version, create_version, utcnow, validate_definition

router = APIRouter(prefix="/api/v1")


def _version_out(v: TestCaseVersion):
    return {"id": v.id, "test_case_id": v.test_case_id, "version_number": v.version_number,
            "status": v.status, "definition": v.definition, "change_summary": v.change_summary,
            "parent_version_id": v.parent_version_id, "build_id": v.build_id, "created_at": v.created_at,
            "approved_at": v.approved_at}


def _build_out(b: ApplicationBuild):
    return {"id": b.id, "project": b.project, "app_id": b.app_id, "platform": b.platform,
            "version_name": b.version_name, "build_number": b.build_number,
            "fingerprint": b.fingerprint, "metadata": b.metadata_json, "created_at": b.created_at}


def _proposal_out(p: HealingProposal):
    return {"id": p.id, "execution_id": p.execution_id, "test_case_id": p.test_case_id,
            "test_case_version_id": p.test_case_version_id, "build_id": p.build_id,
            "step_index": p.step_index, "original_locator": p.original_locator,
            "candidate_locator": p.candidate_locator, "confidence": p.confidence,
            "evidence": p.evidence, "status": p.status, "reviewed_by": p.reviewed_by,
            "review_note": p.review_note, "created_at": p.created_at, "reviewed_at": p.reviewed_at}


@router.post("/builds")
def register_build(payload: ApplicationBuildIn, db: Session = Depends(get_db)):
    metadata = payload.metadata_json or {}
    if len(json.dumps(metadata, default=str)) > 50000:
        raise HTTPException(413, "Build metadata exceeds 50 KB")
    canonical = json.dumps({"project": payload.project, "app_id": payload.app_id, "platform": payload.platform,
                            "version_name": payload.version_name, "build_number": payload.build_number,
                            "metadata": metadata}, sort_keys=True, separators=(",", ":"), default=str)
    fingerprint = payload.fingerprint or sha256(canonical.encode("utf-8")).hexdigest()
    if len(fingerprint) != 64 or any(c not in "0123456789abcdefABCDEF" for c in fingerprint):
        raise HTTPException(422, "fingerprint must be a 64-character SHA-256 hex digest")
    existing = db.query(ApplicationBuild).filter_by(fingerprint=fingerprint).first()
    if existing:
        return {**_build_out(existing), "created": False}
    row = ApplicationBuild(id=str(uuid4()), project=payload.project, app_id=payload.app_id,
                           platform=payload.platform, version_name=payload.version_name,
                           build_number=payload.build_number, fingerprint=fingerprint.lower(), metadata_json=metadata)
    db.add(row)
    try:
        db.commit(); db.refresh(row)
        return {**_build_out(row), "created": True}
    except IntegrityError:
        db.rollback()
        existing = db.query(ApplicationBuild).filter_by(fingerprint=fingerprint.lower()).first()
        if existing: return {**_build_out(existing), "created": False}
        raise HTTPException(409, "Build registration conflicted with another write")


@router.get("/builds")
def list_builds(project: str = "", platform: str = "", db: Session = Depends(get_db)):
    query = db.query(ApplicationBuild)
    if project: query = query.filter(ApplicationBuild.project == project)
    if platform: query = query.filter(ApplicationBuild.platform == platform)
    return [_build_out(b) for b in query.order_by(ApplicationBuild.created_at.desc()).limit(500).all()]


@router.get("/builds/{build_id}/impact")
def build_impact(build_id: str, db: Session = Depends(get_db)):
    build = db.get(ApplicationBuild, build_id)
    if not build: raise HTTPException(404, "Application build not found")
    tests = db.query(TestCase).filter(TestCase.project == build.project).order_by(TestCase.title).all()
    compatible = [t for t in tests if t.platform in {build.platform, "both", "cross_platform"} or (build.platform == "ps5" and t.platform == "cross_platform")]
    impact_rows = []
    for t in compatible:
        build_version = db.query(TestCaseVersion).filter_by(test_case_id=t.id, build_id=build_id, status="approved").order_by(TestCaseVersion.version_number.desc()).first()
        last_execution = db.query(Execution).filter_by(test_case_id=t.id, build_id=build_id).order_by(Execution.started_at.desc()).first()
        impact_rows.append({"id": t.id, "title": t.title, "platform": t.platform, "active_version": t.active_version,
                            "build_specific_version": build_version.version_number if build_version else None,
                            "effective_version": build_version.version_number if build_version else t.active_version,
                            "last_execution": last_execution.status if last_execution else "not_run"})
    return {"build": _build_out(build), "total_project_tests": len(tests), "compatible_tests": len(compatible), "tests": impact_rows}


@router.get("/tests/{test_id}/versions")
def list_test_versions(test_id: str, db: Session = Depends(get_db)):
    test = db.get(TestCase, test_id)
    if not test: raise HTTPException(404, "Test case not found")
    ensure_initial_version(db, test); db.commit()
    versions = db.query(TestCaseVersion).filter_by(test_case_id=test_id).order_by(TestCaseVersion.version_number.desc()).all()
    return [_version_out(v) for v in versions]


@router.post("/tests/{test_id}/versions")
def create_test_version(test_id: str, payload: TestVersionIn, db: Session = Depends(get_db)):
    test = db.get(TestCase, test_id)
    if not test: raise HTTPException(404, "Test case not found")
    active = ensure_initial_version(db, test)
    if payload.build_id:
        target_build = db.get(ApplicationBuild, payload.build_id)
        if not target_build:
            raise HTTPException(422, "Application build not found")
        if test.project and target_build.project and test.project != target_build.project:
            raise HTTPException(422, "Application build belongs to a different project")
        if test.platform in {"android", "ios", "web"} and target_build.platform != test.platform:
            raise HTTPException(422, "Application build platform is incompatible with test case")
        active = db.query(TestCaseVersion).filter_by(test_case_id=test_id, build_id=payload.build_id, status="approved").order_by(TestCaseVersion.version_number.desc()).first() or active
    definition = deepcopy(payload.definition if payload.definition is not None else active.definition)
    try: validate_definition(definition)
    except ValueError as exc: raise HTTPException(422, str(exc)) from exc
    version = create_version(db, test, definition, payload.change_summary, active.id, "draft", payload.build_id)
    db.commit(); db.refresh(version)
    return _version_out(version)


@router.post("/tests/{test_id}/rollback/{version_id}")
def rollback_test_version(test_id: str, version_id: str, payload: VersionReviewIn, db: Session = Depends(get_db)):
    test = db.get(TestCase, test_id)
    source = db.get(TestCaseVersion, version_id)
    if not test or not source or source.test_case_id != test_id:
        raise HTTPException(404, "Test case or source version not found")
    ensure_initial_version(db, test)
    version = create_version(db, test, source.definition, f"Rollback to v{source.version_number}: {payload.review_note}".strip(), source.id, "approved", source.build_id)
    db.commit(); db.refresh(version)
    return _version_out(version)


@router.post("/versions/{version_id}/approve")
def approve_test_version(version_id: str, payload: VersionReviewIn, db: Session = Depends(get_db)):
    version = db.execute(select(TestCaseVersion).where(TestCaseVersion.id == version_id).with_for_update()).scalars().first()
    if not version: raise HTTPException(404, "Test version not found")
    if version.status != "draft": raise HTTPException(409, "Only draft versions can be approved")
    test = db.get(TestCase, version.test_case_id)
    if not test: raise HTTPException(404, "Test case not found")
    version.status = "approved"; version.approved_at = utcnow()
    version.change_summary = f"{version.change_summary} | Approved by {payload.reviewed_by}"[:2000]
    if version.build_id is None:
        test.active_version = version.version_number
        for field in ("title", "project", "description", "platform", "app_id", "prerequisites", "test_data", "steps"):
            if field in version.definition: setattr(test, field, deepcopy(version.definition[field]))
    db.commit(); db.refresh(version)
    return _version_out(version)


@router.get("/healing-proposals")
def list_healing_proposals(test_case_id: str = "", status: str = "", db: Session = Depends(get_db)):
    query = db.query(HealingProposal)
    if test_case_id: query = query.filter(HealingProposal.test_case_id == test_case_id)
    if status: query = query.filter(HealingProposal.status == status)
    return [_proposal_out(p) for p in query.order_by(HealingProposal.created_at.desc()).limit(500).all()]


@router.post("/healing-proposals/{proposal_id}/accept")
def accept_healing_proposal(proposal_id: str, payload: VersionReviewIn, db: Session = Depends(get_db)):
    proposal = db.execute(select(HealingProposal).where(HealingProposal.id == proposal_id).with_for_update()).scalars().first()
    if not proposal: raise HTTPException(404, "Healing proposal not found")
    if proposal.status != "pending": raise HTTPException(409, "Proposal is no longer pending")
    if proposal.confidence < 0.80: raise HTTPException(409, "Proposal confidence is below the reviewable threshold")
    test = db.get(TestCase, proposal.test_case_id)
    if not test: raise HTTPException(404, "Test case not found")
    base = db.get(TestCaseVersion, proposal.test_case_version_id) if proposal.test_case_version_id else ensure_initial_version(db, test)
    if not base: base = ensure_initial_version(db, test)
    definition = deepcopy(base.definition)
    steps = definition.get("steps", [])
    if proposal.step_index < 0 or proposal.step_index >= len(steps): raise HTTPException(409, "Proposal step no longer exists in its source version")
    steps[proposal.step_index]["target"] = deepcopy(proposal.candidate_locator)
    version = create_version(db, test, definition, f"Self-healing proposal {proposal.id} accepted for review: {payload.review_note}".strip(), base.id, "draft", proposal.build_id)
    proposal.status = "accepted_to_draft"; proposal.reviewed_by = payload.reviewed_by
    proposal.review_note = payload.review_note; proposal.reviewed_at = utcnow()
    db.commit(); db.refresh(version)
    return {"proposal": _proposal_out(proposal), "draft_version": _version_out(version),
            "message": "A draft was created. Approve it separately to make it active."}


@router.post("/healing-proposals/{proposal_id}/reject")
def reject_healing_proposal(proposal_id: str, payload: VersionReviewIn, db: Session = Depends(get_db)):
    proposal = db.execute(select(HealingProposal).where(HealingProposal.id == proposal_id).with_for_update()).scalars().first()
    if not proposal: raise HTTPException(404, "Healing proposal not found")
    if proposal.status != "pending": raise HTTPException(409, "Proposal is no longer pending")
    proposal.status = "rejected"; proposal.reviewed_by = payload.reviewed_by
    proposal.review_note = payload.review_note; proposal.reviewed_at = utcnow()
    db.commit()
    return _proposal_out(proposal)
