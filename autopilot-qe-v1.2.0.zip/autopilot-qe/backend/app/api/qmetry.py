from datetime import datetime, timezone
from uuid import uuid4
from pydantic import BaseModel, Field, ConfigDict
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from app.core.database import get_db
from app.models.entities import QMetrySyncJob, TestCase, Execution
from app.services.qmetry import get_config, safe_config, encrypt_secret, _safe_base_url, test_connection, enqueue_test_case, enqueue_execution, pull_enterprise_test_cases

router = APIRouter(prefix="/api/v1/integrations/qmetry", tags=["QMetry"])

class QMetryConfigIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    enabled: bool = False
    edition: str = Field(default="enterprise", pattern="^(enterprise|qtm4j)$")
    base_url: str = Field(default="", max_length=500)
    project_key: str = Field(default="", max_length=160)
    project_id: str = Field(default="", max_length=80)
    test_case_folder_id: str = Field(default="", max_length=80)
    scope: str = Field(default="project", pattern="^(project|release|cycle)$")
    sync_test_cases: bool = True
    sync_executions: bool = True
    api_key: str = Field(default="", max_length=4000)
    user_token: str = Field(default="", max_length=4000)
    org_code: str = Field(default="", max_length=160)
    jira_auth_type: str = Field(default="bearer", pattern="^(basic|bearer)$")
    jira_username: str = Field(default="", max_length=240)
    jira_token: str = Field(default="", max_length=4000)
    clear_api_key: bool = False
    clear_user_token: bool = False
    clear_jira_token: bool = False

@router.get("")
def read_config(db: Session = Depends(get_db)):
    return safe_config(get_config(db))

@router.put("")
def write_config(payload: QMetryConfigIn, db: Session = Depends(get_db)):
    row = get_config(db)
    try:
        row.base_url = _safe_base_url(payload.base_url) if payload.base_url else ""
    except ValueError as exc: raise HTTPException(422, str(exc))
    row.enabled=payload.enabled; row.edition=payload.edition; row.project_key=payload.project_key
    row.project_id=payload.project_id; row.test_case_folder_id=payload.test_case_folder_id; row.scope=payload.scope
    row.sync_test_cases=payload.sync_test_cases; row.sync_executions=payload.sync_executions
    row.org_code=payload.org_code; row.jira_auth_type=payload.jira_auth_type; row.jira_username=payload.jira_username
    if payload.api_key: row.api_key_encrypted=encrypt_secret(payload.api_key)
    if payload.user_token: row.user_token_encrypted=encrypt_secret(payload.user_token)
    if payload.jira_token: row.jira_token_encrypted=encrypt_secret(payload.jira_token)
    if payload.clear_api_key: row.api_key_encrypted=""
    if payload.clear_user_token: row.user_token_encrypted=""
    if payload.clear_jira_token: row.jira_token_encrypted=""
    if row.enabled and not row.base_url: raise HTTPException(422, "Configure the QMetry base URL before enabling integration")
    row.last_status = "configured" if row.enabled else "disabled"; row.last_error=""
    db.commit(); db.refresh(row)
    return safe_config(row)

@router.post("/test-connection")
def connection_test(db: Session = Depends(get_db)):
    row=get_config(db)
    try:
        result=test_connection(row)
        row.last_test_at=datetime.now(timezone.utc); row.last_status="connected"; row.last_error=""; db.commit()
        return result | {"status":"connected"}
    except Exception as exc:
        row.last_test_at=datetime.now(timezone.utc); row.last_status="error"; row.last_error=f"{type(exc).__name__}: {str(exc)[:800]}"; db.commit()
        raise HTTPException(502, row.last_error)

@router.post("/sync/test-cases")
def queue_test_cases(db: Session = Depends(get_db)):
    cfg=get_config(db)
    if not cfg.enabled or not cfg.sync_test_cases: raise HTTPException(409, "Enable QMetry and test-case synchronization first")
    if cfg.edition == "qtm4j": raise HTTPException(409, "QTM4J creates or matches test cases during JUnit execution-result imports; standalone test-case sync is not supported by this connector mode")
    rows=db.query(TestCase).order_by(TestCase.updated_at.asc()).limit(5000).all(); queued=0
    for test in rows:
        if enqueue_test_case(db,test): queued += 1
    return {"queued":queued,"total":len(rows),"message":"Test cases queued in the local outbox; sync worker will deliver them."}

@router.post("/sync/executions")
def queue_executions(db: Session = Depends(get_db)):
    cfg=get_config(db)
    if not cfg.enabled or not cfg.sync_executions: raise HTTPException(409, "Enable QMetry and execution synchronization first")
    rows=db.query(Execution).filter(Execution.status.in_(["passed","failed","error","skipped"])).order_by(Execution.started_at.asc()).limit(5000).all(); queued=0
    for item in rows:
        if enqueue_execution(db,item): queued += 1
    return {"queued":queued,"total":len(rows),"message":"Execution results queued in the local outbox; sync worker will deliver them."}

@router.post("/pull-test-cases")
def pull_test_cases(db: Session = Depends(get_db)):
    cfg=get_config(db)
    if not cfg.enabled or not cfg.sync_test_cases: raise HTTPException(409,"Enable QMetry and test-case synchronization first")
    try: return pull_enterprise_test_cases(db,cfg)
    except Exception as exc: raise HTTPException(502,f"{type(exc).__name__}: {str(exc)[:800]}")

@router.get("/jobs")
def list_jobs(limit: int=100, db: Session=Depends(get_db)):
    limit=max(1,min(limit,500))
    rows=db.query(QMetrySyncJob).order_by(QMetrySyncJob.created_at.desc()).limit(limit).all()
    counts=dict(db.query(QMetrySyncJob.status,func.count(QMetrySyncJob.id)).group_by(QMetrySyncJob.status).all())
    return {"counts":counts,"jobs":[{"id":r.id,"entity_type":r.entity_type,"entity_id":r.entity_id,"status":r.status,"attempts":r.attempts,"last_error":r.last_error,"external_ref":r.external_ref,"created_at":r.created_at,"updated_at":r.updated_at} for r in rows]}

@router.post("/jobs/{job_id}/retry")
def retry_job(job_id: str, db: Session=Depends(get_db)):
    row=db.get(QMetrySyncJob,job_id)
    if not row: raise HTTPException(404,"Sync job not found")
    if row.status not in {"failed","deferred"}: raise HTTPException(409,"Only failed or deferred jobs can be retried")
    row.status="pending"; row.attempts=0; row.next_attempt_at=datetime.now(timezone.utc); row.last_error=""; db.commit()
    return {"id":row.id,"status":row.status}
