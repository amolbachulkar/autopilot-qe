from datetime import datetime, timezone
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.core.database import get_db
from app.models.entities import User, AuthSession, AuditEvent
from app.services.auth import ROLES, normalize_email, hash_password, verify_password, create_session, resolve_session, audit, role_invite_codes, create_ws_ticket, password_is_strong

router = APIRouter(prefix="/api/v1/auth", tags=["authentication"])

class SignupIn(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    email: str = Field(min_length=5, max_length=320)
    full_name: str = Field(min_length=1, max_length=160)
    password: str = Field(min_length=12, max_length=256)
    role: str = "tester"
    invite_code: str = ""
    @field_validator("email")
    @classmethod
    def valid_email(cls, v):
        v = normalize_email(v)
        if "@" not in v or "." not in v.rsplit("@", 1)[-1]: raise ValueError("Enter a valid email address")
        return v
    @field_validator("password")
    @classmethod
    def strong_password(cls, v):
        if not password_is_strong(v): raise ValueError("Password must be at least 12 characters and use at least three character classes")
        return v
    @field_validator("role")
    @classmethod
    def valid_role(cls, v):
        if v not in {"developer", "tester", "qe_lead", "product_owner"}: raise ValueError("Admin accounts can only be created by the bootstrap administrator")
        return v

class LoginIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: str
    password: str

class RoleUpdateIn(BaseModel):
    role: str
    is_active: bool | None = None

class PasswordResetIn(BaseModel):
    new_password: str = Field(min_length=14, max_length=256)
    @field_validator("new_password")
    @classmethod
    def strong_password(cls, v):
        if not password_is_strong(v, 14): raise ValueError("Password must be at least 14 characters and use at least three character classes")
        return v

class UserOut(BaseModel):
    id: str; email: str; full_name: str; role: str; is_active: bool; created_at: datetime; last_login_at: datetime | None = None

def user_out(user: User):
    return {"id": user.id, "email": user.email, "full_name": user.full_name, "role": user.role,
            "is_active": user.is_active, "created_at": user.created_at, "last_login_at": user.last_login_at}

def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    user = getattr(request.state, "user", None)
    if not user: raise HTTPException(401, "Authentication required")
    return user

def require_roles(*roles):
    def dependency(user: User = Depends(current_user)):
        if user.role not in roles and user.role != "admin": raise HTTPException(403, "Insufficient role permissions")
        return user
    return dependency

@router.post("/signup")
def signup(payload: SignupIn, request: Request, db: Session = Depends(get_db)):
    if db.query(User).filter_by(email=payload.email).first(): raise HTTPException(409, "An account with this email already exists")
    if payload.role in {"developer", "qe_lead", "product_owner"}:
        expected = role_invite_codes().get(payload.role)
        if not expected or not payload.invite_code or not __import__("hmac").compare_digest(str(expected), payload.invite_code):
            raise HTTPException(403, f"A valid {payload.role} invitation code is required")
    user = User(id=str(uuid4()), email=payload.email, full_name=payload.full_name,
                password_hash=hash_password(payload.password), role=payload.role, is_active=True)
    db.add(user); audit(db, user.id, "auth.signup", "user", user.id, {"role": user.role})
    try:
        db.commit(); db.refresh(user)
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "An account with this email already exists")
    token, expires = create_session(db, user, request.client.host if request.client else "", request.headers.get("user-agent", ""))
    return {"access_token": token, "token_type": "Bearer", "expires_at": expires, "user": user_out(user)}

@router.post("/login")
def login(payload: LoginIn, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=normalize_email(payload.email)).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    if not user.is_active: raise HTTPException(403, "Account is disabled. Contact an administrator.")
    token, expires = create_session(db, user, request.client.host if request.client else "", request.headers.get("user-agent", ""))
    return {"access_token": token, "token_type": "Bearer", "expires_at": expires, "user": user_out(user)}

@router.get("/me")
def me(user: User = Depends(current_user)): return user_out(user)

@router.post("/ws-ticket")
def websocket_ticket(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return {"ticket": create_ws_ticket(db, user), "expires_in_seconds": 60}

@router.post("/logout")
def logout(request: Request, db: Session = Depends(get_db), user: User = Depends(current_user)):
    token = (request.headers.get("authorization") or "").removeprefix("Bearer ").strip()
    resolved = resolve_session(db, token)
    if resolved:
        _, session = resolved; session.revoked_at = datetime.now(timezone.utc)
        audit(db, user.id, "auth.logout", "session", session.id); db.commit()
    return {"ok": True}

@router.post("/users/{user_id}/password-reset")
def reset_user_password(user_id: str, payload: PasswordResetIn, db: Session = Depends(get_db), actor: User = Depends(require_roles("admin"))):
    user = db.get(User, user_id)
    if not user: raise HTTPException(404, "User not found")
    user.password_hash = hash_password(payload.new_password)
    for session in db.query(AuthSession).filter_by(user_id=user.id, revoked_at=None).all(): session.revoked_at = datetime.now(timezone.utc)
    audit(db, actor.id, "admin.password_reset", "user", user.id)
    db.commit()
    return {"ok": True, "message": "Password updated and existing sessions revoked"}

@router.get("/audit-events")
def audit_events(limit: int = 100, db: Session = Depends(get_db), _: User = Depends(require_roles("admin"))):
    limit = max(1, min(limit, 500))
    rows = db.query(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(limit).all()
    return [{"id":r.id,"actor_user_id":r.actor_user_id,"action":r.action,"resource_type":r.resource_type,
             "resource_id":r.resource_id,"details":r.details,"created_at":r.created_at} for r in rows]

@router.get("/users")
def list_users(db: Session = Depends(get_db), _: User = Depends(require_roles("admin"))):
    return [user_out(u) for u in db.query(User).order_by(User.created_at.desc()).limit(1000).all()]

@router.patch("/users/{user_id}")
def update_user(user_id: str, payload: RoleUpdateIn, db: Session = Depends(get_db), actor: User = Depends(require_roles("admin"))):
    user = db.get(User, user_id)
    if not user: raise HTTPException(404, "User not found")
    if payload.role not in ROLES: raise HTTPException(422, "Invalid role")
    if user.id == actor.id and payload.is_active is False: raise HTTPException(409, "Administrators cannot deactivate their own account")
    removing_admin = user.role == "admin" and (payload.role != "admin" or payload.is_active is False)
    if removing_admin and db.query(User).filter_by(role="admin", is_active=True).count() <= 1:
        raise HTTPException(409, "Cannot remove or deactivate the last active administrator")
    user.role = payload.role
    if payload.is_active is not None: user.is_active = payload.is_active
    if not user.is_active:
        for session in db.query(AuthSession).filter_by(user_id=user.id, revoked_at=None).all(): session.revoked_at = datetime.now(timezone.utc)
    audit(db, actor.id, "admin.user_update", "user", user.id, {"role": user.role, "is_active": user.is_active})
    db.commit(); db.refresh(user)
    return user_out(user)
