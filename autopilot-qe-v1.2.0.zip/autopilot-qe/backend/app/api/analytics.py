from datetime import datetime, timedelta, timezone
from collections import Counter, defaultdict
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Execution, TestCase, ApplicationBuild

router = APIRouter(prefix="/api/v1/analytics", tags=["quality analytics"])

def _aware(value):
    if value is None: return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value

def _category(result):
    if not isinstance(result, dict): return "Unclassified"
    candidates = [result.get("failure_category"), result.get("category")]
    analysis = result.get("failure_analysis")
    if isinstance(analysis, dict): candidates.extend([analysis.get("category"), analysis.get("classification")])
    error = result.get("error")
    if isinstance(error, dict): candidates.extend([error.get("category"), error.get("type")])
    for value in candidates:
        if isinstance(value, str) and value.strip(): return value.strip()[:80]
    return "Unclassified"

def _metrics(rows):
    terminal = [e for e in rows if e.status in {"passed", "failed", "error", "skipped"}]
    passed = sum(e.status == "passed" for e in terminal)
    failed = sum(e.status == "failed" for e in terminal)
    errors = sum(e.status == "error" for e in terminal)
    skipped = sum(e.status == "skipped" for e in terminal)
    durations = []
    categories = Counter()
    for e in terminal:
        start, end = _aware(e.started_at), _aware(e.finished_at)
        if start and end and end >= start: durations.append((end-start).total_seconds())
        if e.status in {"failed", "error"}: categories[_category(e.result or {})] += 1
    total = len(terminal)
    return {"total": total, "passed": passed, "failed": failed, "errors": errors, "skipped": skipped,
            "pass_rate": round(passed / total * 100, 2) if total else 0,
            "failure_rate": round((failed + errors) / total * 100, 2) if total else 0,
            "avg_duration_seconds": round(sum(durations)/len(durations), 2) if durations else 0,
            "failure_categories": [{"name": k, "count": v} for k,v in categories.most_common(10)],
            "unique_test_cases": len({e.test_case_id for e in terminal})}

def _filter_rows(db, since, project="", platform="", build_id=""):
    q = db.query(Execution).join(TestCase, TestCase.id == Execution.test_case_id)
    if since: q = q.filter(Execution.started_at >= since)
    if project: q = q.filter(TestCase.project == project)
    if platform: q = q.filter(TestCase.platform == platform)
    if build_id: q = q.filter(Execution.build_id == build_id)
    return q.order_by(Execution.started_at.asc()).limit(10000).all()

@router.get("/summary")
def summary(days: int = Query(30, ge=1, le=365), project: str = "", platform: str = "", db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc); since = now - timedelta(days=days)
    rows = _filter_rows(db, since, project, platform)
    daily = defaultdict(lambda: {"passed":0,"failed":0,"error":0,"other":0})
    for e in rows:
        key = _aware(e.started_at).date().isoformat()
        bucket = e.status if e.status in {"passed","failed","error"} else "other"
        daily[key][bucket] += 1
    trend = [{"date": (since.date()+timedelta(days=i)).isoformat(), **daily[(since.date()+timedelta(days=i)).isoformat()]} for i in range(days+1)]
    metrics = _metrics(rows)
    test_query = db.query(TestCase)
    build_query = db.query(ApplicationBuild)
    if project:
        test_query = test_query.filter(TestCase.project == project)
        build_query = build_query.filter(ApplicationBuild.project == project)
    tests = test_query.count()
    builds = build_query.count()
    return {"period_days":days,"project":project,"platform":platform,"metrics":metrics,"trend":trend,
            "total_test_cases":tests,"registered_builds":builds,"generated_at":now.isoformat()}

@router.get("/compare")
def compare(build_a: str = Query(..., min_length=1), build_b: str = Query(..., min_length=1), db: Session = Depends(get_db)):
    a, b = db.get(ApplicationBuild, build_a), db.get(ApplicationBuild, build_b)
    if not a or not b: raise HTTPException(404, "Both application builds must exist")
    if a.project != b.project or a.platform != b.platform:
        raise HTTPException(422, "Build comparison requires the same project and platform")
    rows_a = _filter_rows(db, None, "", "", a.id)
    rows_b = _filter_rows(db, None, "", "", b.id)
    ma, mb = _metrics(rows_a), _metrics(rows_b)
    categories = sorted(set(x["name"] for x in ma["failure_categories"] + mb["failure_categories"]))
    ca = {x["name"]:x["count"] for x in ma["failure_categories"]}; cb = {x["name"]:x["count"] for x in mb["failure_categories"]}
    return {"project":a.project,"platform":a.platform,
            "build_a":{"id":a.id,"version_name":a.version_name,"build_number":a.build_number,"created_at":a.created_at,"metrics":ma},
            "build_b":{"id":b.id,"version_name":b.version_name,"build_number":b.build_number,"created_at":b.created_at,"metrics":mb},
            "delta":{"pass_rate_pp":round(mb["pass_rate"]-ma["pass_rate"],2),"failed":mb["failed"]-ma["failed"],
                     "errors":mb["errors"]-ma["errors"],"avg_duration_seconds":round(mb["avg_duration_seconds"]-ma["avg_duration_seconds"],2)},
            "failure_category_comparison":[{"name":name,"build_a":ca.get(name,0),"build_b":cb.get(name,0)} for name in categories]}
