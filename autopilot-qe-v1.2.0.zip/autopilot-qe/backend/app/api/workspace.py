from datetime import datetime, timezone
from uuid import uuid4
import re
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.api.auth import current_user
from app.models.entities import (User, Project, ProjectMember, Requirement, RequirementTestLink,
    Defect, ReleaseDecision, TestCase, Execution, ApplicationBuild, AuditEvent)

router = APIRouter(prefix="/api/v1", tags=["project workspace"])


def _now(): return datetime.now(timezone.utc)
def _role(user, *roles):
    if user.role != "admin" and user.role not in roles:
        raise HTTPException(403, "Your role cannot perform this project action")
def _project(db, project_id, user, write=False):
    p = db.get(Project, project_id)
    if not p: raise HTTPException(404, "Project not found")
    if user.role not in {"admin","qe_lead"}:
        member = db.query(ProjectMember).filter_by(project_id=p.id, user_id=user.id).first()
        member_count = db.query(ProjectMember).filter_by(project_id=p.id).count()
        if member_count and not member and p.owner_user_id != user.id:
            raise HTTPException(404, "Project not found")
        if write and user.role == "product_owner" and not member and p.owner_user_id != user.id:
            raise HTTPException(403, "You are not a member of this project")
    return p

def _project_dict(p):
    return {"id":p.id,"key":p.key,"name":p.name,"description":p.description,"product":p.product,"status":p.status,"owner_user_id":p.owner_user_id,"created_at":p.created_at,"updated_at":p.updated_at}
def _requirement_dict(r, db):
    links=db.query(RequirementTestLink).filter_by(requirement_id=r.id).all()
    return {"id":r.id,"project_id":r.project_id,"key":r.key,"title":r.title,"description":r.description,"acceptance_criteria":r.acceptance_criteria or [],"priority":r.priority,"status":r.status,"owner_user_id":r.owner_user_id,"external_ref":r.external_ref,"test_case_ids":[x.test_case_id for x in links],"created_by":r.created_by,"created_at":r.created_at,"updated_at":r.updated_at}
def _defect_dict(d):
    return {"id":d.id,"project_id":d.project_id,"key":d.key,"title":d.title,"description":d.description,"severity":d.severity,"priority":d.priority,"status":d.status,"platform":d.platform,"build_id":d.build_id,"test_case_id":d.test_case_id,"execution_id":d.execution_id,"assignee_user_id":d.assignee_user_id,"external_ref":d.external_ref,"created_by":d.created_by,"created_at":d.created_at,"updated_at":d.updated_at,"resolved_at":d.resolved_at}
def _decision_dict(d, db):
    u=db.get(User,d.decided_by)
    return {"id":d.id,"project_id":d.project_id,"build_id":d.build_id,"version_label":d.version_label,"decision":d.decision,"rationale":d.rationale,"conditions":d.conditions or [],"metrics_snapshot":d.metrics_snapshot or {},"decided_by":d.decided_by,"decided_by_name":u.full_name if u else "Unknown","created_at":d.created_at}

@router.get("/projects")
def list_projects(db:Session=Depends(get_db), user:User=Depends(current_user)):
    q=db.query(Project)
    if user.role not in {"admin","qe_lead"}:
        ids=[m.project_id for m in db.query(ProjectMember).filter_by(user_id=user.id).all()]
        q=q.filter((Project.owner_user_id==user.id)|(Project.id.in_(ids))|(Project.owner_user_id.is_(None))) if ids else q.filter((Project.owner_user_id==user.id)|(Project.owner_user_id.is_(None)))
    rows=q.order_by(Project.updated_at.desc()).all()
    out=[]
    for p in rows:
        out.append({**_project_dict(p),"requirements_count":db.query(Requirement).filter_by(project_id=p.id).count(),"open_defects":db.query(Defect).filter(Defect.project_id==p.id,Defect.status.notin_(["resolved","closed"])).count(),"test_cases_count":db.query(TestCase).filter(TestCase.project.in_([p.key,p.name])).count()})
    return out

@router.post("/projects")
def create_project(payload:dict, db:Session=Depends(get_db), user:User=Depends(current_user)):
    _role(user,"developer","tester","qe_lead","product_owner")
    name=str(payload.get("name","")).strip(); key=re.sub(r"[^A-Z0-9]+","-",str(payload.get("key") or name).upper()).strip("-")[:32]
    if not name or not key: raise HTTPException(422,"Project name and key are required")
    if db.query(Project).filter(func.upper(Project.key)==key).first(): raise HTTPException(409,"Project key already exists")
    p=Project(id=str(uuid4()),key=key,name=name[:180],description=str(payload.get("description", ""))[:10000],product=str(payload.get("product", ""))[:180],owner_user_id=user.id)
    db.add(p); db.flush(); db.add(ProjectMember(id=str(uuid4()),project_id=p.id,user_id=user.id,project_role="owner",added_by=user.id))
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="project.created",resource_type="project",resource_id=p.id,details={"key":key}))
    db.commit(); db.refresh(p); return _project_dict(p)

@router.get("/projects/{project_id}/workspace")
def project_workspace(project_id:str, db:Session=Depends(get_db), user:User=Depends(current_user)):
    p=_project(db,project_id,user)
    reqs=db.query(Requirement).filter_by(project_id=p.id).order_by(Requirement.updated_at.desc()).all()
    defects=db.query(Defect).filter_by(project_id=p.id).order_by(Defect.updated_at.desc()).all()
    decisions=db.query(ReleaseDecision).filter_by(project_id=p.id).order_by(ReleaseDecision.created_at.desc()).limit(20).all()
    tests=db.query(TestCase).filter(TestCase.project.in_([p.key,p.name])).order_by(TestCase.updated_at.desc()).all()
    all_tests=db.query(TestCase).order_by(TestCase.updated_at.desc()).limit(500).all()
    builds=db.query(ApplicationBuild).filter(ApplicationBuild.project.in_([p.key,p.name])).order_by(ApplicationBuild.created_at.desc()).limit(50).all()
    all_builds=db.query(ApplicationBuild).order_by(ApplicationBuild.created_at.desc()).limit(500).all()
    test_ids=[t.id for t in tests]
    executions=db.query(Execution).filter(Execution.test_case_id.in_(test_ids)).order_by(Execution.started_at.desc()).limit(30).all() if test_ids else []
    members=db.query(ProjectMember,User).join(User,User.id==ProjectMember.user_id).filter(ProjectMember.project_id==p.id).all()
    terminal=[e for e in executions if e.status in {"passed","failed","error","skipped"}]
    passed=sum(e.status=="passed" for e in terminal); failed=sum(e.status in {"failed","error"} for e in terminal)
    return {"project":_project_dict(p),"summary":{"requirements":len(reqs),"covered_requirements":sum(1 for r in reqs if db.query(RequirementTestLink).filter_by(requirement_id=r.id).count()),"open_defects":sum(1 for d in defects if d.status not in {"resolved","closed"}),"critical_defects":sum(1 for d in defects if d.severity in {"critical","blocker"} and d.status not in {"resolved","closed"}),"test_cases":len(tests),"builds":len(builds),"recent_executions":len(terminal),"pass_rate":round(passed/len(terminal)*100,1) if terminal else 0,"failed_runs":failed},"requirements":[_requirement_dict(r,db) for r in reqs],"defects":[_defect_dict(d) for d in defects],"release_decisions":[_decision_dict(d,db) for d in decisions],"test_cases":[{"id":t.id,"title":t.title,"platform":t.platform,"active_version":t.active_version,"description":t.description} for t in tests],"available_test_cases":[{"id":t.id,"title":t.title,"platform":t.platform,"active_version":t.active_version} for t in all_tests if not t.project],"builds":[{"id":b.id,"platform":b.platform,"version_name":b.version_name,"build_number":b.build_number,"created_at":b.created_at} for b in builds],"available_builds":[{"id":b.id,"platform":b.platform,"version_name":b.version_name,"build_number":b.build_number,"created_at":b.created_at} for b in all_builds if not b.project],"executions":[{"id":e.id,"test_case_id":e.test_case_id,"status":e.status,"started_at":e.started_at,"result":e.result or {},"build_id":e.build_id} for e in executions],"members":[{"user_id":m.user_id,"name":u.full_name,"email":u.email,"role":u.role,"project_role":m.project_role} for m,u in members]}

@router.post("/projects/{project_id}/members")
def add_project_member(project_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True)
    if user.role not in {"admin","qe_lead"} and p.owner_user_id!=user.id: raise HTTPException(403,"Only the project owner, QE Leads and administrators can manage membership")
    target=db.get(User,str(payload.get("user_id","")))
    if not target or not target.is_active: raise HTTPException(404,"Active user not found")
    row=db.query(ProjectMember).filter_by(project_id=p.id,user_id=target.id).first()
    if row: row.project_role=str(payload.get("project_role","contributor"))[:24]
    else: db.add(ProjectMember(id=str(uuid4()),project_id=p.id,user_id=target.id,project_role=str(payload.get("project_role","contributor"))[:24],added_by=user.id))
    db.commit(); return {"ok":True,"user_id":target.id}

@router.post("/projects/{project_id}/requirements")
def create_requirement(project_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True); _role(user,"product_owner","developer","tester","qe_lead")
    title=str(payload.get("title","")).strip()
    if not title: raise HTTPException(422,"Requirement title is required")
    rid=str(uuid4())
    r=Requirement(id=rid,project_id=p.id,key=f"{p.key}-REQ-{rid[:6].upper()}",title=title[:240],description=str(payload.get("description",""))[:10000],acceptance_criteria=payload.get("acceptance_criteria",[])[:50],priority=payload.get("priority","medium"),status=payload.get("status","draft"),owner_user_id=payload.get("owner_user_id"),external_ref=str(payload.get("external_ref",""))[:160],created_by=user.id)
    if r.priority not in {"low","medium","high","critical"} or r.status not in {"draft","ready","in_progress","done","rejected"}: raise HTTPException(422,"Invalid requirement priority or status")
    db.add(r); db.flush()
    for tid in payload.get("test_case_ids",[])[:100]:
        linked_test=db.get(TestCase,str(tid))
        if not linked_test: raise HTTPException(422,f"Test case {tid} does not exist")
        if linked_test.project and linked_test.project not in [p.key,p.name]: raise HTTPException(409,f"Test case {tid} already belongs to another project")
        linked_test.project=p.key
        db.add(RequirementTestLink(id=str(uuid4()),requirement_id=r.id,test_case_id=str(tid)))
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="requirement.created",resource_type="requirement",resource_id=r.id,details={"project_id":p.id,"key":r.key}))
    db.commit(); db.refresh(r); return _requirement_dict(r,db)

@router.patch("/requirements/{requirement_id}")
def update_requirement(requirement_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    r=db.get(Requirement,requirement_id)
    if not r: raise HTTPException(404,"Requirement not found")
    _project(db,r.project_id,user,True); _role(user,"product_owner","developer","qe_lead")
    for k in ("title","description","priority","status","external_ref","owner_user_id","acceptance_criteria"):
        if k in payload: setattr(r,k,payload[k])
    if r.priority not in {"low","medium","high","critical"} or r.status not in {"draft","ready","in_progress","done","rejected"}: raise HTTPException(422,"Invalid requirement priority or status")
    if "test_case_ids" in payload:
        db.query(RequirementTestLink).filter_by(requirement_id=r.id).delete()
        for tid in payload["test_case_ids"][:100]:
            linked_test=db.get(TestCase,str(tid))
            if not linked_test: raise HTTPException(422,f"Test case {tid} does not exist")
            project_row=db.get(Project,r.project_id)
            if linked_test.project and project_row and linked_test.project not in [project_row.key,project_row.name]: raise HTTPException(409,f"Test case {tid} already belongs to another project")
            linked_test.project=r.project_id
            linked_test.project=project_row.key if project_row else linked_test.project
            db.add(RequirementTestLink(id=str(uuid4()),requirement_id=r.id,test_case_id=str(tid)))
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="requirement.updated",resource_type="requirement",resource_id=r.id,details={"fields":list(payload.keys())}))
    db.commit(); db.refresh(r); return _requirement_dict(r,db)

@router.post("/projects/{project_id}/defects")
def create_defect(project_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True); _role(user,"developer","tester","qe_lead")
    title=str(payload.get("title","")).strip()
    if not title: raise HTTPException(422,"Defect title is required")
    did=str(uuid4())
    d=Defect(id=did,project_id=p.id,key=f"{p.key}-BUG-{did[:6].upper()}",title=title[:240],description=str(payload.get("description",""))[:10000],severity=payload.get("severity","major"),priority=payload.get("priority","medium"),status="open",platform=payload.get("platform","unknown"),build_id=payload.get("build_id"),test_case_id=payload.get("test_case_id"),execution_id=payload.get("execution_id"),assignee_user_id=payload.get("assignee_user_id"),external_ref=str(payload.get("external_ref",""))[:160],created_by=user.id)
    if d.severity not in {"critical","blocker","major","minor","trivial"} or d.priority not in {"low","medium","high","critical"} or d.platform not in {"android","ios","web","ps5","unknown"}: raise HTTPException(422,"Invalid defect severity, priority or platform")
    if d.test_case_id:
        linked_test=db.get(TestCase,d.test_case_id)
        if not linked_test: raise HTTPException(422,"Linked test case not found")
        if linked_test.project not in [p.key,p.name]: raise HTTPException(422,"Linked test case does not belong to this project")
    if d.execution_id:
        linked_execution=db.get(Execution,d.execution_id)
        if not linked_execution: raise HTTPException(422,"Linked execution not found")
        linked_test=db.get(TestCase,linked_execution.test_case_id)
        if not linked_test or linked_test.project not in [p.key,p.name]: raise HTTPException(422,"Linked execution does not belong to this project")
    if d.build_id:
        linked_build=db.get(ApplicationBuild,d.build_id)
        if not linked_build or linked_build.project not in [p.key,p.name]: raise HTTPException(422,"Linked build does not belong to this project")
    db.add(d); db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="defect.created",resource_type="defect",resource_id=d.id,details={"project_id":p.id,"key":d.key}))
    db.commit(); db.refresh(d); return _defect_dict(d)

@router.patch("/defects/{defect_id}")
def update_defect(defect_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    d=db.get(Defect,defect_id)
    if not d: raise HTTPException(404,"Defect not found")
    dproject=_project(db,d.project_id,user,True); _role(user,"developer","tester","qe_lead")
    for k in ("title","description","severity","priority","status","platform","build_id","test_case_id","execution_id","assignee_user_id","external_ref"):
        if k in payload: setattr(d,k,payload[k])
    if d.severity not in {"critical","blocker","major","minor","trivial"} or d.status not in {"open","triaged","in_progress","resolved","closed"}: raise HTTPException(422,"Invalid defect severity or status")
    if d.priority not in {"low","medium","high","critical"} or d.platform not in {"android","ios","web","ps5","unknown"}: raise HTTPException(422,"Invalid defect priority or platform")
    if d.test_case_id:
        linked_test=db.get(TestCase,d.test_case_id)
        if not linked_test or linked_test.project not in [dproject.key,dproject.name]: raise HTTPException(422,"Linked test case does not belong to this project")
    if d.execution_id:
        linked_execution=db.get(Execution,d.execution_id)
        linked_test=db.get(TestCase,linked_execution.test_case_id) if linked_execution else None
        if not linked_test or linked_test.project not in [dproject.key,dproject.name]: raise HTTPException(422,"Linked execution does not belong to this project")
    if d.build_id:
        linked_build=db.get(ApplicationBuild,d.build_id)
        if not linked_build or linked_build.project not in [dproject.key,dproject.name]: raise HTTPException(422,"Linked build does not belong to this project")
    if d.status in {"resolved","closed"} and not d.resolved_at: d.resolved_at=_now()
    elif d.status not in {"resolved","closed"}: d.resolved_at=None
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="defect.updated",resource_type="defect",resource_id=d.id,details={"fields":list(payload.keys())}))
    db.commit(); db.refresh(d); return _defect_dict(d)

@router.post("/projects/{project_id}/release-decisions")
def create_release_decision(project_id:str,payload:dict,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True); _role(user,"qe_lead","product_owner")
    decision=str(payload.get("decision",""))
    if decision not in {"go","no_go","conditional"}: raise HTTPException(422,"Decision must be go, no_go or conditional")
    if not str(payload.get("rationale", "")).strip(): raise HTTPException(422,"Release decision rationale is required")
    if decision=="conditional" and not payload.get("conditions"): raise HTTPException(422,"Conditional GO requires at least one condition")
    if decision=="go":
        critical=db.query(Defect).filter(Defect.project_id==p.id,Defect.severity.in_(["critical","blocker"]),Defect.status.notin_(["resolved","closed"])).count()
        if critical:
            if not payload.get("override_critical_blockers") or user.role not in {"admin","qe_lead"} or not str(payload.get("rationale", "")).strip():
                raise HTTPException(409,f"Release cannot be marked GO while {critical} critical/blocker defect(s) remain open. Use conditional/no-go or an explicitly justified QE Lead/Admin override.")
    build_id=payload.get("build_id")
    if build_id:
        selected_build=db.get(ApplicationBuild,str(build_id))
        if not selected_build: raise HTTPException(422,"Build not found")
        if selected_build.project not in [p.key,p.name]: raise HTTPException(422,"Selected build is not linked to this project")
    tests=db.query(TestCase).filter(TestCase.project.in_([p.key,p.name])).all(); ids=[t.id for t in tests]
    ex=db.query(Execution).filter(Execution.test_case_id.in_(ids),Execution.build_id==build_id).all() if ids and build_id else db.query(Execution).filter(Execution.test_case_id.in_(ids)).all() if ids else []
    terminal=[e for e in ex if e.status in {"passed","failed","error","skipped"}]
    passed=sum(e.status=="passed" for e in terminal); failed=sum(e.status in {"failed","error"} for e in terminal)
    snapshot={"test_cases":len(tests),"executions":len(terminal),"passed":passed,"failed_or_error":failed,"pass_rate":round(passed/len(terminal)*100,1) if terminal else 0,"open_defects":db.query(Defect).filter(Defect.project_id==p.id,Defect.status.notin_(["resolved","closed"])).count(),"critical_open_defects":db.query(Defect).filter(Defect.project_id==p.id,Defect.severity.in_(["critical","blocker"]),Defect.status.notin_(["resolved","closed"])).count()}
    row=ReleaseDecision(id=str(uuid4()),project_id=p.id,build_id=build_id,version_label=str(payload.get("version_label",""))[:100],decision=decision,rationale=str(payload.get("rationale",""))[:10000],conditions=payload.get("conditions",[])[:50],metrics_snapshot=snapshot,decided_by=user.id)
    db.add(row); db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="release.decision",resource_type="release_decision",resource_id=row.id,details={"project_id":p.id,"decision":decision,"metrics":snapshot}))
    db.commit(); db.refresh(row); return _decision_dict(row,db)

@router.get("/users/directory")
def user_directory(project_id:str|None=None,db:Session=Depends(get_db),user:User=Depends(current_user)):
    if user.role not in {"admin","qe_lead"}:
        if not project_id: raise HTTPException(403,"Only admins and QE Leads can view the global member directory")
        p=_project(db,project_id,user)
        if p.owner_user_id!=user.id: raise HTTPException(403,"Only project owners, QE Leads and administrators can view eligible teammates")
    return [{"id":u.id,"name":u.full_name,"email":u.email,"role":u.role} for u in db.query(User).filter_by(is_active=True).order_by(User.full_name).limit(500).all()]


@router.post("/projects/{project_id}/test-cases/{test_case_id}/link")
def link_test_case(project_id:str,test_case_id:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True); _role(user,"developer","tester","qe_lead")
    test=db.get(TestCase,test_case_id)
    if not test: raise HTTPException(404,"Test case not found")
    if test.project and test.project not in [p.key,p.name]: raise HTTPException(409,"Test case already belongs to another project")
    test.project=p.key
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="project.test_case_linked",resource_type="test_case",resource_id=test.id,details={"project_id":p.id,"project_key":p.key}))
    db.commit(); return {"ok":True,"test_case_id":test.id,"project_id":p.id,"project_key":p.key}

@router.post("/projects/{project_id}/builds/{build_id}/link")
def link_build(project_id:str,build_id:str,db:Session=Depends(get_db),user:User=Depends(current_user)):
    p=_project(db,project_id,user,True); _role(user,"developer","qe_lead")
    build=db.get(ApplicationBuild,build_id)
    if not build: raise HTTPException(404,"Build not found")
    if build.project and build.project not in [p.key,p.name]: raise HTTPException(409,"Build already belongs to another project")
    build.project=p.key
    db.add(AuditEvent(id=str(uuid4()),actor_user_id=user.id,action="project.build_linked",resource_type="application_build",resource_id=build.id,details={"project_id":p.id,"project_key":p.key}))
    db.commit(); return {"ok":True,"build_id":build.id,"project_id":p.id}
