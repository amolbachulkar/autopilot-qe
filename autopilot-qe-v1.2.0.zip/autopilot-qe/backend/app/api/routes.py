from datetime import datetime, timezone
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Device, TestCase, RecordingSession, Execution, VisualCheckpoint, ApplicationBuild, TestCaseVersion, HealingProposal
from app.schemas.api import DeviceIn, RecordingStart, StepIn, TestCaseIn, ExecuteIn, ExecutionComplete, TestDataUpdate, VisualCheckpointIn
from app.services.device_discovery import discover_local_devices
from app.services.sauce import sauce_configured, sauce_webdriver_url
from app.services.headspin import headspin_status, headspin_appium_url, headspin_webdriver_url, fetch_device_configs
from app.services.test_maintenance import ensure_initial_version
from app.services.qmetry import enqueue_test_case, enqueue_execution

router = APIRouter(prefix="/api/v1")


@router.get("/visual/status")
def visual_status():
    from app.core.config import settings
    return {"provider": "applitools", "configured": bool(settings.applitools_api_key),
            "server_url": settings.applitools_server_url, "app_name": settings.applitools_app_name,
            "supported_engines": ["playwright-python", "selenium-python", "appium-python"],
            "note": "API key is stored server-side and is never returned."}


def _checkpoint_dict(row: VisualCheckpoint):
    return {"id": row.id, "test_case_id": row.test_case_id, "name": row.name, "scope": row.scope,
            "selector": row.selector, "selector_type": row.selector_type, "match_level": row.match_level, "after_step": row.after_step,
            "ignore_selectors": row.ignore_selectors or [], "layout_selectors": row.layout_selectors or [],
            "mask_selectors": row.mask_selectors or [], "wait_for_selector": row.wait_for_selector,
            "full_page": row.full_page, "disable_animations": row.disable_animations, "hide_caret": row.hide_caret, "enabled": row.enabled, "created_at": row.created_at}

@router.get("/tests/{test_id}/visual-checkpoints")
def list_visual_checkpoints(test_id: str, db: Session = Depends(get_db)):
    if not db.get(TestCase, test_id): raise HTTPException(404, "Test case not found")
    rows = db.query(VisualCheckpoint).filter_by(test_case_id=test_id).order_by(VisualCheckpoint.created_at).all()
    return [_checkpoint_dict(row) for row in rows]

@router.post("/tests/{test_id}/visual-checkpoints")
def create_visual_checkpoint(test_id: str, payload: VisualCheckpointIn, db: Session = Depends(get_db)):
    if not db.get(TestCase, test_id): raise HTTPException(404, "Test case not found")
    if payload.scope == "element" and not payload.selector:
        raise HTTPException(422, "Element checkpoints require a CSS or XPath selector")
    row = VisualCheckpoint(id=str(uuid4()), test_case_id=test_id, **payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return _checkpoint_dict(row)

@router.patch("/visual-checkpoints/{checkpoint_id}")
def update_visual_checkpoint(checkpoint_id: str, payload: VisualCheckpointIn, db: Session = Depends(get_db)):
    row = db.get(VisualCheckpoint, checkpoint_id)
    if not row: raise HTTPException(404, "Visual checkpoint not found")
    if payload.scope == "element" and not payload.selector:
        raise HTTPException(422, "Element checkpoints require a CSS or XPath selector")
    for key, value in payload.model_dump().items(): setattr(row, key, value)
    db.commit(); db.refresh(row)
    return _checkpoint_dict(row)

@router.delete("/visual-checkpoints/{checkpoint_id}")
def delete_visual_checkpoint(checkpoint_id: str, db: Session = Depends(get_db)):
    row = db.get(VisualCheckpoint, checkpoint_id)
    if not row: raise HTTPException(404, "Visual checkpoint not found")
    db.delete(row); db.commit()
    return {"deleted": checkpoint_id}

@router.get("/tests/{test_id}/visual-script")
def export_visual_script(test_id: str, target: str = "playwright", db: Session = Depends(get_db)):
    from app.core.config import settings
    from app.services.visual_export import generate_visual_script
    test = db.get(TestCase, test_id)
    if not test: raise HTTPException(404, "Test case not found")
    if target not in {"playwright", "selenium", "appium"}: raise HTTPException(422, "target must be playwright, selenium or appium")
    if target == "appium" and test.platform == "web": raise HTTPException(422, "Appium visual scripts are for native mobile tests")
    if target in {"playwright", "selenium"} and test.platform in {"android", "ios"}: raise HTTPException(422, "Browser visual scripts are for web tests")
    checkpoints = db.query(VisualCheckpoint).filter_by(test_case_id=test_id, enabled=True).order_by(VisualCheckpoint.created_at).all()
    if not checkpoints: raise HTTPException(409, "Add at least one enabled visual checkpoint first")
    config = [{"name": c.name, "scope": c.scope, "selector": c.selector, "selector_type": c.selector_type,
               "match_level": c.match_level, "after_step": c.after_step, "ignore_selectors": c.ignore_selectors or [],
               "layout_selectors": c.layout_selectors or [], "mask_selectors": c.mask_selectors or [],
               "wait_for_selector": c.wait_for_selector, "full_page": c.full_page,
               "disable_animations": c.disable_animations, "hide_caret": c.hide_caret, "enabled": c.enabled} for c in checkpoints]
    filename, content = generate_visual_script({"title": test.title, "app_id": test.app_id, "steps": test.steps or [], "test_data": test.test_data or {}}, config, target, settings.applitools_app_name)
    return {"filename": filename, "language": "python", "target": target, "content": content, "checkpoint_count": len(config)}

@router.get("/health")
def health():
    return {"status": "ok", "service": "autopilotqe-api", "version": "1.0.0"}

@router.get("/ready")
def readiness(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"status": "ready", "database": "connected"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail="Database unavailable") from exc


@router.get("/providers")
def providers():
    from app.core.config import settings
    return {
        "local": {"configured": True, "mobile": True, "web": True},
        "sauce": {"configured": sauce_configured() or bool(sauce_webdriver_url()), "mobile": sauce_configured(),
                  "web": bool(sauce_webdriver_url()), "region": settings.sauce_region,
                  "mobile_appium": sauce_configured(), "web_selenium": bool(sauce_webdriver_url()),
                  "web_playwright": False,
                  "note": "Sauce Labs Playwright cloud orchestration uses saucectl (JavaScript/TypeScript); Python agent supports Selenium remote sessions."},
        "headspin": {**headspin_status(), "mobile": bool(headspin_appium_url()),
                     "web": bool(headspin_webdriver_url()), "web_playwright": False},
        "applitools": {"configured": bool(settings.applitools_api_key), "mobile": True, "web": True,
                       "provider_type": "visual-validation", "server_url": settings.applitools_server_url,
                       "note": "Eyes visual checkpoints for Playwright Python, Selenium and Appium Python workers."},
        "playstation": {"configured": True, "mobile_appium": True, "android_package": "com.scee.psxandroid", 
                        "note": "PlayStation App UI checks run through Appium. PS Remote Play is an operator-controlled console bridge; Sony does not publish a general-purpose public automation API for the PS App UI."}
    }

@router.post("/providers/headspin/discover")
def discover_headspin(db: Session = Depends(get_db)):
    try:
        configs = fetch_device_configs()
    except Exception as exc:
        raise HTTPException(502, f"HeadSpin device discovery failed: {type(exc).__name__}") from exc
    registered = []
    for device_id, config in configs.items():
        caps = config.get("capabilities") or {}
        platform_name = str(caps.get("platformName", config.get("os", ""))).lower()
        platform = "ios" if platform_name in {"ios", "iphone", "ipad"} else "android" if platform_name == "android" else ""
        if not platform:
            continue
        safe_caps = {key: caps[key] for key in ("platformName", "deviceName", "udid", "automationName", "platformVersion", "autoAcceptAlerts", "noReset", "appiumVersion") if key in caps}
        row_id = str(device_id)[:64]
        values = {"name": str(caps.get("deviceName") or device_id)[:160], "platform": platform,
                  "os_version": str(caps.get("platformVersion", "unknown"))[:40], "device_type": "physical",
                  "provider": "headspin", "status": "available",
                  "metadata_json": {"headspin_host": str(config.get("host", ""))[:255], "automation_capabilities": safe_caps}}
        row = db.get(Device, row_id)
        if row is None: row = Device(id=row_id, **values)
        else:
            for key, value in values.items(): setattr(row, key, value)
        db.add(row); registered.append({"id": row_id, "name": values["name"], "platform": platform, "os_version": values["os_version"], "provider": "headspin"})
    db.commit()
    return {"discovered": len(registered), "devices": registered, "driver_urls": "kept server-side; never returned to the browser"}

@router.get("/web/browsers")
def web_browsers():
    from app.core.config import settings
    return {"browsers": [
        {"id": "local-chromium", "name": "Chromium", "browser": "chromium", "provider": "local", "platform": "web", "device_type": "browser"},
        {"id": "local-firefox", "name": "Firefox", "browser": "firefox", "provider": "local", "platform": "web", "device_type": "browser"},
        {"id": "local-webkit", "name": "WebKit", "browser": "webkit", "provider": "local", "platform": "web", "device_type": "browser"},
        {"id": "sauce-chrome", "name": "Chrome · Sauce Labs", "browser": "chrome", "provider": "sauce", "platform": "web", "device_type": "browser", "configured": sauce_configured()},
        {"id": "headspin-chrome", "name": "Chrome · HeadSpin", "browser": "chrome", "provider": "headspin", "platform": "web", "device_type": "browser", "configured": bool(headspin_webdriver_url())}
    ], "cloud_providers": ["sauce", "headspin"],
        "local_browser_installation_required": True,
        "sauce_playwright_cloud": "Use saucectl for Sauce Labs-managed Playwright cloud runs; this Python agent's remote browser path uses Selenium.",
        "headspin_playwright_cloud": "HeadSpin browser cloud capabilities are account/plan dependent; this Python agent supports configured Selenium WebDriver endpoints."}

@router.post("/web/browsers/register")
def register_web_browser(payload: dict, db: Session = Depends(get_db)):
    browser_id = str(payload.get("id", ""))[:64]
    provider = str(payload.get("provider", "local"))
    browser = str(payload.get("browser", "chromium"))
    if not browser_id or provider not in {"local", "sauce", "headspin"} or browser not in {"chromium", "firefox", "webkit", "chrome", "edge"}:
        raise HTTPException(422, "Invalid browser profile")
    row = db.get(Device, browser_id)
    values = {"name": str(payload.get("name", browser))[:160], "platform": "web", "os_version": str(payload.get("browser_version", "latest"))[:40],
              "device_type": "browser", "provider": provider, "status": "available",
              "metadata_json": {"browser": browser, "base_url": str(payload.get("base_url", ""))[:2048]}}
    if row is None:
        row = Device(id=browser_id, **values)
    else:
        for key, value in values.items(): setattr(row, key, value)
    db.add(row); db.commit()
    return {"id": row.id, "name": row.name, "provider": row.provider, "platform": row.platform, "status": row.status}

@router.get("/devices")
def list_devices(db: Session = Depends(get_db)):
    return [{"id": d.id, "name": d.name, "platform": d.platform, "os_version": d.os_version,
             "device_type": d.device_type, "provider": d.provider, "status": d.status,
             "metadata": d.metadata_json} for d in db.query(Device).order_by(Device.name).all()]

@router.post("/devices/discover")
def discover(db: Session = Depends(get_db)):
    devices = discover_local_devices()
    for item in devices:
        existing = db.get(Device, item.id)
        if existing:
            for key, value in item.model_dump().items(): setattr(existing, key, value)
        else: db.add(Device(**item.model_dump()))
    db.commit()
    return {"discovered": len(devices), "devices": [d.model_dump() for d in devices],
            "note": "Local discovery runs on the host where ADB/Xcode are installed. Sauce Labs devices are selected per session.",
            "sauce_configured": sauce_configured()}

@router.post("/devices")
def register_device(payload: DeviceIn, db: Session = Depends(get_db)):
    row = db.get(Device, payload.id)
    if row is None: row = Device(id=payload.id, name=payload.name, platform=payload.platform)
    for key, value in payload.model_dump().items(): setattr(row, key, value)
    db.add(row); db.commit()
    return {"id": row.id, "status": "registered"}

@router.post("/recordings")
def start_recording(payload: RecordingStart, db: Session = Depends(get_db)):
    if payload.device_id and not db.get(Device, payload.device_id):
        raise HTTPException(422, "Selected device is not registered")
    row = RecordingSession(id=str(uuid4()), **payload.model_dump())
    db.add(row); db.commit(); db.refresh(row)
    return {"id": row.id, "status": row.status, "started_at": row.started_at}

@router.post("/recordings/{session_id}/steps")
def add_step(session_id: str, payload: StepIn, db: Session = Depends(get_db)):
    row = db.get(RecordingSession, session_id)
    if not row: raise HTTPException(404, "Recording session not found")
    if row.status != "recording": raise HTTPException(409, "Recording session is not active")
    steps = list(row.steps or [])
    if len(steps) >= 500: raise HTTPException(409, "Recording step limit (500) reached")
    steps.append(payload.model_dump()); row.steps = steps
    # Register non-secret placeholders discovered by the recorder so testers can fill them in later.
    import re
    if isinstance(payload.value, str):
        for key in re.findall(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}", payload.value):
            row.test_data = {**(row.test_data or {}), key: (row.test_data or {}).get(key, "")}
    db.commit()
    return {"session_id": session_id, "step_number": len(steps)}

@router.get("/recordings/{session_id}")
def get_recording(session_id: str, db: Session = Depends(get_db)):
    row = db.get(RecordingSession, session_id)
    if not row:
        raise HTTPException(404, "Recording session not found")
    return {"id": row.id, "title": row.title, "device_id": row.device_id, "app_id": row.app_id,
            "status": row.status, "prerequisites": row.prerequisites, "test_data": row.test_data,
            "steps": row.steps or [], "started_at": row.started_at, "finished_at": row.finished_at}


@router.post("/recordings/{session_id}/stop")
def stop_recording(session_id: str, db: Session = Depends(get_db)):
    row = db.get(RecordingSession, session_id)
    if not row: raise HTTPException(404, "Recording session not found")
    if row.status != "recording": raise HTTPException(409, "Recording session is already closed")
    row.status = "completed"; row.finished_at = datetime.now(timezone.utc); db.commit()
    return {"id": row.id, "status": row.status, "steps": len(row.steps or [])}

@router.post("/recordings/{session_id}/save-as-test")
def save_recording(session_id: str, db: Session = Depends(get_db)):
    row = db.get(RecordingSession, session_id)
    if not row: raise HTTPException(404, "Recording session not found")
    if row.status != "completed": raise HTTPException(409, "Stop the recording before saving it as a test")
    device = db.get(Device, row.device_id) if row.device_id else None
    inferred_platform = device.platform if device and device.platform in {"android", "ios", "web"} else "both"
    test = TestCase(id=str(uuid4()), title=row.title, app_id=row.app_id, prerequisites=row.prerequisites,
                    test_data=row.test_data, steps=row.steps, platform=inferred_platform)
    db.add(test); db.flush(); ensure_initial_version(db, test); db.commit()
    enqueue_test_case(db, test)
    return {"id": test.id, "title": test.title, "steps": len(test.steps or []), "active_version": test.active_version}

@router.get("/recordings")
def recordings(db: Session = Depends(get_db)):
    return [{"id": r.id, "title": r.title, "status": r.status, "steps": len(r.steps or []),
             "started_at": r.started_at} for r in db.query(RecordingSession).order_by(RecordingSession.started_at.desc()).limit(200).all()]

@router.get("/tests")
def list_tests(db: Session = Depends(get_db)):
    return [{"id": t.id, "title": t.title, "project": t.project, "platform": t.platform, "app_id": t.app_id,
             "active_version": t.active_version, "steps": len(t.steps or []), "prerequisites": t.prerequisites}
            for t in db.query(TestCase).order_by(TestCase.updated_at.desc()).limit(500).all()]

@router.post("/tests")
def create_test(payload: TestCaseIn, db: Session = Depends(get_db)):
    row = TestCase(id=str(uuid4()), **payload.model_dump()); db.add(row); db.flush(); ensure_initial_version(db, row); db.commit()
    enqueue_test_case(db, row)
    return {"id": row.id, "title": row.title, "active_version": row.active_version}

@router.get("/tests/{test_id}")
def get_test(test_id: str, db: Session = Depends(get_db)):
    row = db.get(TestCase, test_id)
    if not row: raise HTTPException(404, "Test case not found")
    return {"id": row.id, "title": row.title, "project": row.project, "description": row.description, "platform": row.platform,
            "app_id": row.app_id, "prerequisites": row.prerequisites, "test_data": row.test_data, "steps": row.steps,
            "active_version": row.active_version}

@router.post("/tests/{test_id}/execute")
def execute_test(test_id: str, payload: ExecuteIn, db: Session = Depends(get_db)):
    test = db.get(TestCase, test_id)
    if not test: raise HTTPException(404, "Test case not found")
    if any((step.get("action") == "manual_step" or (step.get("metadata") or {}).get("requires_automation_mapping")) for step in (test.steps or [])):
        raise HTTPException(409, "This test case contains imported manual QMetry steps. Convert them to supported automation actions before execution.")
    if not payload.device_id: raise HTTPException(422, "device_id is required to execute a test")
    device = db.get(Device, payload.device_id)
    if not device: raise HTTPException(422, "Selected device is not registered")
    if device.status != "available": raise HTTPException(409, "Selected device is not available")
    if test.platform in {"android", "ios", "web"} and device.platform != test.platform:
        raise HTTPException(422, f"Test platform '{test.platform}' cannot execute on '{device.platform}' device")
    if test.platform == "cross_platform" and device.platform not in {"android", "ios"}:
        raise HTTPException(422, "Cross-platform PlayStation App verification must be queued on an Android or iOS Appium device")
    version = None
    if payload.test_case_version_id:
        version = db.get(TestCaseVersion, payload.test_case_version_id)
        if not version or version.test_case_id != test_id or version.status != "approved":
            raise HTTPException(422, "Selected test version must belong to this test and be approved")
        if version.build_id and version.build_id != payload.build_id:
            raise HTTPException(422, "Selected test version is scoped to a different application build")
    else:
        version = ensure_initial_version(db, test)
        if payload.build_id:
            version = db.query(TestCaseVersion).filter_by(test_case_id=test_id, build_id=payload.build_id, status="approved").order_by(TestCaseVersion.version_number.desc()).first()
        if version is None or (payload.build_id and version.build_id != payload.build_id):
            version = db.query(TestCaseVersion).filter_by(test_case_id=test_id, version_number=test.active_version, status="approved", build_id=None).first()
    build = db.get(ApplicationBuild, payload.build_id) if payload.build_id else None
    if payload.build_id and not build: raise HTTPException(422, "Application build not found")
    if build:
        if test.project and build.project and test.project != build.project:
            raise HTTPException(422, "Application build belongs to a different project")
        if build.platform == "ps5":
            if test.platform != "cross_platform" or device.platform not in {"android", "ios"}:
                raise HTTPException(422, "PS5 builds require a cross-platform test queued on an Android or iOS Appium device")
        else:
            if build.platform != device.platform:
                raise HTTPException(422, "Application build platform must match the selected execution device")
            if test.platform not in {"both", "cross_platform"} and build.platform != test.platform:
                raise HTTPException(422, "Application build platform is incompatible with test case")
        if build.platform == device.platform and build.app_id and test.app_id and build.app_id != test.app_id:
            raise HTTPException(422, "Application build app identifier does not match the test case")
    execution = Execution(id=str(uuid4()), test_case_id=test_id, device_id=payload.device_id, status="queued",
                          build_id=build.id if build else None, test_case_version_id=version.id if version else None,
                          result={"dry_run": payload.dry_run, "step_count": len((version.definition if version else {}).get("steps", test.steps or [])),
                                  "build_fingerprint": build.fingerprint if build else None})
    db.add(execution); db.commit()
    return {"execution_id": execution.id, "status": execution.status, "dry_run": payload.dry_run,
            "build_id": execution.build_id, "test_case_version_id": execution.test_case_version_id}

@router.post("/agent/executions/claim")
def claim_execution(payload: ExecuteIn, db: Session = Depends(get_db)):
    if not payload.device_id: raise HTTPException(422, "device_id is required")
    query = select(Execution).where(Execution.status == "queued", Execution.device_id == payload.device_id).order_by(Execution.started_at).with_for_update(skip_locked=True)
    execution = db.execute(query).scalars().first()
    if not execution: return {"execution": None}
    execution.status = "running"
    execution.result = {**(execution.result or {}), "claimed_at": datetime.now(timezone.utc).isoformat()}
    db.commit()
    test = db.get(TestCase, execution.test_case_id)
    if not test:
        execution.status = "error"; execution.finished_at = datetime.now(timezone.utc); execution.result = {"error": "Test case missing"}; db.commit()
        return {"execution": None}
    version = db.get(TestCaseVersion, execution.test_case_version_id) if execution.test_case_version_id else None
    definition = version.definition if version else {"title": test.title, "app_id": test.app_id, "steps": test.steps, "test_data": test.test_data}
    build = db.get(ApplicationBuild, execution.build_id) if execution.build_id else None
    return {"execution": {"id": execution.id, "test_case_id": test.id, "title": definition.get("title", test.title),
            "app_id": definition.get("app_id", test.app_id), "steps": definition.get("steps", test.steps),
            "test_data": definition.get("test_data", test.test_data), "test_case_version_id": version.id if version else None,
            "test_case_version": version.version_number if version else test.active_version,
            "build": {"id": build.id, "platform": build.platform, "version_name": build.version_name,
                      "build_number": build.build_number, "fingerprint": build.fingerprint} if build else None,
            "visual_checkpoints": [_checkpoint_dict(v) for v in db.query(VisualCheckpoint).filter_by(test_case_id=test.id, enabled=True).all()]}}

@router.post("/executions/{execution_id}/complete")
def complete_execution(execution_id: str, payload: ExecutionComplete, db: Session = Depends(get_db)):
    execution = db.execute(select(Execution).where(Execution.id == execution_id).with_for_update()).scalars().first()
    if not execution: raise HTTPException(404, "Execution not found")
    if execution.status != "running": raise HTTPException(409, "Execution is not running")
    execution.status = payload.status
    execution.result = {**(execution.result or {}), **payload.result}
    execution.finished_at = datetime.now(timezone.utc)
    # Agent reports are untrusted evidence. Persist bounded locator proposals only; never auto-approve them.
    healing_events = payload.result.get("healing_events", []) if isinstance(payload.result, dict) else []
    if isinstance(healing_events, list):
        for event in healing_events[:100]:
            if not isinstance(event, dict): continue
            original = event.get("original_locator") or {}
            candidate = event.get("candidate_locator") or {}
            allowed_locator_keys = {"id", "accessibility_id", "xpath", "class_name", "name", "text", "label", "placeholder", "test_id", "role", "css", "resource_id", "content_desc", "description", "semantic_text"}
            if not isinstance(original, dict) or not isinstance(candidate, dict) or not candidate: continue
            original = {str(k): str(v)[:1000] for k, v in original.items() if k in allowed_locator_keys and isinstance(v, (str, int, float))}
            candidate = {str(k): str(v)[:1000] for k, v in candidate.items() if k in allowed_locator_keys and isinstance(v, (str, int, float))}
            if not candidate: continue
            confidence = event.get("confidence", 0)
            try: confidence = max(0.0, min(float(confidence), 1.0))
            except (TypeError, ValueError): confidence = 0.0
            try: step_index = max(0, min(int(event.get("step_index", 0)), 500))
            except (TypeError, ValueError): step_index = 0
            evidence = event.get("evidence", {}) if isinstance(event.get("evidence"), dict) else {}
            try:
                if len(str(evidence)) > 20000: evidence = {"truncated": True, "summary": str(evidence)[:19000]}
            except Exception: evidence = {}
            db.add(HealingProposal(id=str(uuid4()), execution_id=execution.id, test_case_id=execution.test_case_id,
                test_case_version_id=execution.test_case_version_id, build_id=execution.build_id,
                step_index=step_index, original_locator=original, candidate_locator=candidate, confidence=confidence,
                evidence=evidence, status="pending"))
    db.commit()
    enqueue_execution(db, execution)
    return {"id": execution.id, "status": execution.status, "finished_at": execution.finished_at}

@router.get("/executions")
def executions(db: Session = Depends(get_db)):
    return [{"id": e.id, "test_case_id": e.test_case_id, "device_id": e.device_id, "status": e.status,
             "build_id": e.build_id, "test_case_version_id": e.test_case_version_id,
             "result": e.result, "started_at": e.started_at, "finished_at": e.finished_at}
            for e in db.query(Execution).order_by(Execution.started_at.desc()).limit(500).all()]

@router.get("/tests/{test_id}/export")
def export_test_script(test_id: str, target: str = "playwright", build_id: str | None = None,
                      test_case_version_id: str | None = None, db: Session = Depends(get_db)):
    """Export the active global version or an explicitly selected build/version snapshot."""
    from app.services.script_export import generate_script
    test = db.get(TestCase, test_id)
    if not test:
        raise HTTPException(404, "Test case not found")
    version = None
    if test_case_version_id:
        version = db.get(TestCaseVersion, test_case_version_id)
        if not version or version.test_case_id != test_id or version.status != "approved":
            raise HTTPException(422, "Selected test version must belong to this test and be approved")
        if version.build_id and version.build_id != build_id:
            raise HTTPException(422, "Selected test version is scoped to a different build")
    elif build_id:
        export_build = db.get(ApplicationBuild, build_id)
        if not export_build: raise HTTPException(422, "Application build not found")
        if test.project and export_build.project and test.project != export_build.project:
            raise HTTPException(422, "Application build belongs to a different project")
        version = db.query(TestCaseVersion).filter_by(test_case_id=test_id, build_id=build_id, status="approved").order_by(TestCaseVersion.version_number.desc()).first()
    if version is None:
        version = db.query(TestCaseVersion).filter_by(test_case_id=test_id, version_number=test.active_version, status="approved", build_id=None).first()
    definition = version.definition if version else {"title": test.title, "steps": test.steps, "test_data": test.test_data,
                                                       "app_id": test.app_id, "platform": test.platform}
    platform = definition.get("platform", test.platform)
    if target == "appium" and platform == "web":
        raise HTTPException(422, "Appium scripts are for native mobile tests")
    if target in {"playwright", "selenium"} and platform in {"android", "ios"}:
        raise HTTPException(422, "Browser scripts are for web tests")
    try:
        filename, language, content = generate_script({
            "title": definition.get("title", test.title), "steps": definition.get("steps", []),
            "test_data": definition.get("test_data", {}), "app_id": definition.get("app_id", test.app_id),
            "platform": platform,
        }, target)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return {"filename": filename, "language": language, "target": target, "content": content,
            "test_case_version_id": version.id if version else None,
            "test_case_version": version.version_number if version else test.active_version,
            "build_id": version.build_id if version else None}


@router.patch("/tests/{test_id}/test-data")
def update_test_data(test_id: str, payload: TestDataUpdate, db: Session = Depends(get_db)):
    test = db.get(TestCase, test_id)
    if not test:
        raise HTTPException(404, "Test case not found")
    test.test_data = payload.test_data
    db.commit()
    enqueue_test_case(db, test)
    return {"id": test.id, "test_data": test.test_data}
