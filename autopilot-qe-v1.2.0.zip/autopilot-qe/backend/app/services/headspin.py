import httpx
from app.core.config import settings

def headspin_configured() -> bool:
    return bool(settings.headspin_appium_url or settings.headspin_api_token or settings.headspin_webdriver_url)

def headspin_appium_url() -> str:
    return settings.headspin_appium_url.strip()

def headspin_webdriver_url() -> str:
    return settings.headspin_webdriver_url.strip()

def fetch_device_configs() -> dict:
    if not settings.headspin_api_token:
        raise RuntimeError("HEADSPIN_API_TOKEN is not configured")
    base = settings.headspin_api_base_url.rstrip("/") or "https://api.headspin.io"
    response = httpx.get(f"{base}/v0/devices/automation-config",
                         headers={"Authorization": f"Bearer {settings.headspin_api_token}"}, timeout=20.0)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError("Unexpected HeadSpin automation-config response")
    return payload

def headspin_status() -> dict:
    return {
        "provider": "headspin",
        "configured": headspin_configured(),
        "mobile_appium_configured": bool(settings.headspin_appium_url or settings.headspin_api_token),
        "web_webdriver_configured": bool(settings.headspin_webdriver_url),
        "api_discovery_configured": bool(settings.headspin_api_token),
        "note": "Mobile device discovery uses the documented /v0/devices/automation-config endpoint when an API token is configured."
    }
