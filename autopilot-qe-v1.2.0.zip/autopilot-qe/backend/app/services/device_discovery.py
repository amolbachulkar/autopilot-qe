import json, shutil, subprocess, uuid
from app.schemas.api import DeviceIn

def run(args: list[str]) -> str:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=8, check=False).stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        return ""

def discover_local_devices() -> list[DeviceIn]:
    found: list[DeviceIn] = []
    if shutil.which("adb"):
        output = run(["adb", "devices", "-l"])
        for line in output.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 2 and parts[1] == "device":
                serial = parts[0]
                model = next((p.split(":",1)[1] for p in parts[2:] if p.startswith("model:")), serial)
                version = run(["adb", "-s", serial, "shell", "getprop", "ro.build.version.release"]) or "unknown"
                found.append(DeviceIn(id=serial, name=model.replace("_", " "), platform="android", os_version=version,
                                      device_type="emulator" if serial.startswith("emulator-") else "physical", provider="local"))
    if shutil.which("xcrun"):
        output = run(["xcrun", "simctl", "list", "devices", "booted", "--json"])
        try:
            payload = json.loads(output or "{}")
            for runtime, devices in payload.get("devices", {}).items():
                for item in devices:
                    if item.get("state") == "Booted":
                        found.append(DeviceIn(id=item["udid"], name=item["name"], platform="ios",
                                              os_version=runtime.split(".")[-1], device_type="simulator", provider="local"))
        except (ValueError, KeyError, TypeError):
            pass
    return found
