"""Local-first QMetry connector with encrypted secrets and a durable outbox.

QMetry Enterprise v8.x uses its Open API for test-case CRUD and Automation API
for JUnit result imports. QTM4J uses its Jira Automation import endpoint; its
case records are created/reused as part of result imports rather than through
an assumed cross-edition CRUD endpoint.
"""
from __future__ import annotations
import hashlib, json, time, uuid
from datetime import datetime, timezone, timedelta
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.sax.saxutils import escape
from urllib.parse import urlparse
import httpx
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.config import settings
from app.models.entities import QMetryIntegration, QMetrySyncJob, QMetryTestMapping, TestCase, TestCaseVersion, Execution, ApplicationBuild


def _fernet() -> Fernet:
    seed = settings.session_secret or settings.api_key
    if len(seed) < 16:
        if settings.environment.lower() == "production":
            raise RuntimeError("SESSION_SECRET must be configured before storing QMetry credentials")
        seed = "autopilotqe-development-only-key-change-before-production"
    key = hashlib.sha256(seed.encode()).digest()
    import base64
    return Fernet(base64.urlsafe_b64encode(key))


def encrypt_secret(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode() if value else ""


def decrypt_secret(value: str) -> str:
    if not value: return ""
    try: return _fernet().decrypt(value.encode()).decode()
    except InvalidToken as exc: raise RuntimeError("Stored QMetry credential cannot be decrypted; verify SESSION_SECRET has not changed") from exc


def get_config(db: Session, create: bool = True) -> QMetryIntegration | None:
    row = db.get(QMetryIntegration, "default")
    if row is None and create:
        row = QMetryIntegration(id="default")
        db.add(row); db.commit(); db.refresh(row)
    return row


def safe_config(row: QMetryIntegration) -> dict:
    return {"enabled": row.enabled, "edition": row.edition, "base_url": row.base_url,
            "project_key": row.project_key, "project_id": row.project_id,
            "test_case_folder_id": row.test_case_folder_id, "scope": row.scope,
            "sync_test_cases": row.sync_test_cases, "sync_executions": row.sync_executions, "org_code": row.org_code,
            "jira_auth_type": row.jira_auth_type, "jira_username": row.jira_username,
            "has_api_key": bool(row.api_key_encrypted), "has_user_token": bool(row.user_token_encrypted),
            "has_jira_token": bool(row.jira_token_encrypted), "last_status": row.last_status,
            "last_error": row.last_error, "last_test_at": row.last_test_at,
            "last_sync_at": row.last_sync_at}


def _safe_base_url(value: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
        raise ValueError("QMetry base URL must be an absolute HTTP(S) URL without embedded credentials")
    if parsed.query or parsed.fragment:
        raise ValueError("QMetry base URL must not contain query parameters or fragments")
    if settings.environment.lower() == "production" and parsed.scheme != "https":
        raise ValueError("QMetry base URL must use HTTPS in production")
    return value.rstrip("/")


def _headers(row: QMetryIntegration, include_open_api: bool = False) -> dict[str, str]:
    headers = {"Accept": "application/json"}
    if row.edition == "enterprise":
        if include_open_api:
            headers.update({"usertoken": decrypt_secret(row.user_token_encrypted), "orgCode": row.org_code, "scope": row.scope})
        return headers
    if row.api_key_encrypted:
        headers["apiKey"] = decrypt_secret(row.api_key_encrypted)
        headers["apikey"] = decrypt_secret(row.api_key_encrypted)
    if row.jira_token_encrypted:
        token = decrypt_secret(row.jira_token_encrypted)
        if row.jira_auth_type == "basic":
            import base64
            raw = f"{row.jira_username}:{token}".encode()
            headers["Authorization"] = "Basic " + base64.b64encode(raw).decode()
        else:
            headers["Authorization"] = "Bearer " + token
    return headers


def test_connection(row: QMetryIntegration) -> dict:
    base = _safe_base_url(row.base_url)
    if row.edition == "enterprise":
        if not row.user_token_encrypted or not row.org_code:
            raise ValueError("QMetry Enterprise requires Open API user token and org code")
        response = httpx.get(base + "/rest/admin/project/getinfo", headers=_headers(row, True), timeout=15.0, follow_redirects=False)
    else:
        if not row.api_key_encrypted or not row.jira_token_encrypted:
            raise ValueError("QTM4J requires an Open API key and Jira PAT/API token")
        jira_api = "/rest/api/3/myself" if "atlassian.net" in urlparse(base).netloc else "/rest/api/2/myself"
        response = httpx.get(base + jira_api, headers=_headers(row), timeout=15.0, follow_redirects=False)
    if response.status_code >= 400:
        raise RuntimeError(f"QMetry connection failed ({response.status_code}); check URL, credentials and API permissions")
    return {"connected": True, "http_status": response.status_code}


def _test_hash(test: TestCase) -> str:
    raw = json.dumps({"title": test.title, "description": test.description, "steps": test.steps or [], "project": test.project}, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()


def enqueue(db: Session, entity_type: str, entity_id: str, revision: str) -> QMetrySyncJob | None:
    cfg = get_config(db, create=False)
    if not cfg or not cfg.enabled: return None
    if entity_type == "test_case" and (not cfg.sync_test_cases or cfg.edition == "qtm4j"): return None
    if entity_type == "execution" and not cfg.sync_executions: return None
    idem = f"{entity_type}:{entity_id}:{revision}"[:240]
    existing = db.execute(select(QMetrySyncJob).where(QMetrySyncJob.idempotency_key == idem)).scalar_one_or_none()
    if existing: return existing
    row = QMetrySyncJob(id=str(uuid.uuid4()), idempotency_key=idem, entity_type=entity_type,
        entity_id=entity_id, operation="upsert", status="pending", next_attempt_at=datetime.now(timezone.utc))
    db.add(row); db.commit(); db.refresh(row)
    return row


def enqueue_test_case(db: Session, test: TestCase) -> QMetrySyncJob | None:
    return enqueue(db, "test_case", test.id, _test_hash(test))


def enqueue_execution(db: Session, execution: Execution) -> QMetrySyncJob | None:
    return enqueue(db, "execution", execution.id, "final")


def _steps(test: TestCase) -> list[dict]:
    out=[]
    for i, step in enumerate(test.steps or [], 1):
        target = step.get("target") or {}
        expected = step.get("expected") or {}
        out.append({"orderId": i, "description": str(step.get("action") or "Step"),
                    "inputData": str(step.get("value") or json.dumps(target, ensure_ascii=False)),
                    "expectedOutcome": str(expected.get("text") or expected.get("value") or step.get("expected_result") or "")})
    return out


def _find_key(data, keys):
    if isinstance(data, dict):
        for k in keys:
            if data.get(k) not in (None, ""): return str(data[k])
        for v in data.values():
            found = _find_key(v, keys)
            if found: return found
    elif isinstance(data, list):
        for v in data:
            found = _find_key(v, keys)
            if found: return found
    return ""


def sync_test_case(db: Session, row: QMetrySyncJob, cfg: QMetryIntegration) -> str:
    test = db.get(TestCase, row.entity_id)
    if not test: raise RuntimeError("Local test case no longer exists")
    mapping = db.execute(select(QMetryTestMapping).where(QMetryTestMapping.test_case_id == test.id)).scalar_one_or_none()
    current_hash = _test_hash(test)
    if mapping and mapping.last_hash == current_hash:
        return mapping.external_key or mapping.external_id or "already_synced"
    if cfg.edition == "qtm4j":
        # QTM4J creates/reuses test cases through its automation-result import flow.
        # Do not fabricate a standalone test-case API call with an unverified route.
        return "deferred:qtm4j-case-upsert-on-result-import"
    if not cfg.user_token_encrypted or not cfg.org_code or not cfg.test_case_folder_id:
        raise RuntimeError("QMetry Enterprise case sync requires user token, org code and test-case folder ID")
    base = _safe_base_url(cfg.base_url)
    headers = {**_headers(cfg, True), "Content-Type": "application/json"}
    body = {"name": test.title[:255], "description": test.description or "", "steps": _steps(test),
            "tcFolderID": str(cfg.test_case_folder_id), "scope": cfg.scope, "removeSteps": []}
    if mapping and mapping.external_id:
        # Updating a QTM Enterprise case needs its current version ID. Refuse an unsafe blind overwrite.
        if not mapping.external_version_id:
            raise RuntimeError("Existing QMetry mapping has no external version ID; refresh mapping before updating")
        body.update({"tcID": mapping.external_id, "tcVersionID": mapping.external_version_id,
                     "updateWithVersion": True, "notrunall": False})
        response = httpx.put(base + "/rest/testcases", headers=headers, json=body, timeout=25.0, follow_redirects=False)
    else:
        response = httpx.post(base + "/rest/testcases", headers=headers, json=body, timeout=25.0, follow_redirects=False)
    if response.status_code >= 400:
        raise RuntimeError(f"QMetry test-case sync failed with HTTP {response.status_code}; verify API permissions and required fields")
    try: data=response.json()
    except Exception: data={}
    ext_id = _find_key(data, ("tcID", "testCaseId", "id"))
    ext_key = _find_key(data, ("entityKey", "tcKey", "key"))
    ext_ver = _find_key(data, ("tcVersionID", "tcVersionId", "versionId"))
    if not mapping:
        mapping = QMetryTestMapping(id=str(uuid.uuid4()), test_case_id=test.id)
        db.add(mapping)
    if ext_id: mapping.external_id = ext_id
    if ext_key: mapping.external_key = ext_key
    if ext_ver: mapping.external_version_id = ext_ver
    mapping.last_hash = current_hash; mapping.last_synced_at = datetime.now(timezone.utc)
    db.commit()
    return mapping.external_key or mapping.external_id or "created"


def _junit_xml(test: TestCase, execution: Execution) -> bytes:
    result = execution.result or {}
    cases = result.get("steps") if isinstance(result.get("steps"), list) else []
    suite = Element("testsuite", {"name": (test.project or "AutoPilotQE")[:180], "tests": "1",
        "failures": "1" if execution.status in {"failed", "error"} else "0", "errors": "1" if execution.status == "error" else "0"})
    case = SubElement(suite, "testcase", {"classname": f"AutoPilotQE.{test.id}", "name": test.title[:240], "time": str(max(0, ((execution.finished_at or execution.started_at) - execution.started_at).total_seconds()))})
    if execution.status in {"failed", "error"}:
        failure = SubElement(case, "failure", {"message": str(result.get("error") or result.get("failure_reason") or "Test failed")[:500], "type": "AutoPilotQEFailure"})
        failure.text = json.dumps({"execution_id": execution.id, "result": result, "step_evidence": cases[:100]}, ensure_ascii=False, default=str)[:12000]
    elif execution.status == "skipped":
        SubElement(case, "skipped", {"message": "Skipped by AutoPilotQE"})
    return tostring(suite, encoding="utf-8", xml_declaration=True)


def sync_execution(db: Session, job: QMetrySyncJob, cfg: QMetryIntegration) -> str:
    execution = db.get(Execution, job.entity_id)
    if not execution: raise RuntimeError("Execution no longer exists")
    if execution.status not in {"passed", "failed", "error", "skipped"}:
        raise RuntimeError("Execution is not in a final state")
    test = db.get(TestCase, execution.test_case_id)
    if not test: raise RuntimeError("Execution test case no longer exists")
    xml = _junit_xml(test, execution)
    base = _safe_base_url(cfg.base_url)
    if cfg.edition == "enterprise":
        if not cfg.api_key_encrypted or not cfg.project_key:
            raise RuntimeError("QMetry Enterprise result sync requires Automation API key and project key")
        headers = {"project": cfg.project_key, "apikey": decrypt_secret(cfg.api_key_encrypted)}
        data = {"entityType": "JUNIT", "automationHierarchy": "2", "testsuiteName": f"AutoPilotQE · {test.project or cfg.project_key}"}
        if cfg.project_id: data["projectID"] = cfg.project_id
        files = {"file": (f"autopilotqe-{execution.id}.xml", xml, "application/xml")}
        endpoint = base + "/rest/import/createandscheduletestresults/1"
    else:
        if not cfg.api_key_encrypted or not cfg.jira_token_encrypted:
            raise RuntimeError("QTM4J result sync requires Open API key and Jira PAT/API token")
        headers = _headers(cfg)
        data = {"format": "JUnit", "testrunname": f"AutoPilotQE · {test.project or cfg.project_key}", "testToRun": ""}
        files = {"file": (f"autopilotqe-{execution.id}.xml", xml, "application/xml")}
        endpoint = base + "/rest/qtm4j/automation/latest/importresult"
    response = httpx.post(endpoint, headers=headers, data=data, files=files, timeout=45.0, follow_redirects=False)
    if response.status_code >= 400:
        raise RuntimeError(f"QMetry execution result sync failed with HTTP {response.status_code}; verify Automation API permissions and result format")
    try: payload=response.json()
    except Exception: payload={"response": response.text[:1000]}
    return _find_key(payload, ("testRunKey", "testsuiteId", "testSuiteId", "id")) or "accepted"


def process_one(db: Session) -> bool:
    now = datetime.now(timezone.utc)
    job = db.execute(select(QMetrySyncJob).where(QMetrySyncJob.status.in_(["pending", "retry"]), QMetrySyncJob.next_attempt_at <= now).order_by(QMetrySyncJob.created_at).with_for_update(skip_locked=True)).scalars().first()
    if not job: return False
    cfg = get_config(db, create=False)
    if not cfg or not cfg.enabled:
        return False
    job.status = "running"; job.attempts += 1; job.updated_at = now; db.commit()
    try:
        if job.entity_type == "test_case": ref = sync_test_case(db, job, cfg)
        elif job.entity_type == "execution": ref = sync_execution(db, job, cfg)
        else: raise RuntimeError("Unsupported QMetry sync entity")
        if ref.startswith("deferred:"):
            job.status = "deferred"; job.external_ref = ref; job.last_error = "QTM4J creates/reuses test cases when a JUnit result is imported; no standalone test-case write was attempted."
        else:
            job.status = "succeeded"; job.external_ref = ref; job.last_error = ""; job.completed_at = datetime.now(timezone.utc)
        cfg.last_sync_at = datetime.now(timezone.utc); cfg.last_status = "connected"; cfg.last_error = ""
        db.commit()
    except Exception as exc:
        job.last_error = f"{type(exc).__name__}: {str(exc)[:900]}"
        if job.attempts >= job.max_attempts:
            job.status = "failed"
        else:
            job.status = "retry"
            job.next_attempt_at = datetime.now(timezone.utc) + timedelta(seconds=min(3600, 15 * (2 ** min(job.attempts, 8))))
        cfg.last_status = "error"; cfg.last_error = job.last_error[:1000]
        db.commit()
    return True


def pull_enterprise_test_cases(db: Session, cfg: QMetryIntegration) -> dict:
    if cfg.edition != "enterprise": raise ValueError("Pulling test cases is currently supported for QMetry Enterprise v8.x; QTM4J import requires its edition-specific Open API mapping")
    if not cfg.user_token_encrypted or not cfg.org_code or not cfg.test_case_folder_id:
        raise ValueError("Configure Open API user token, org code and test-case folder ID first")
    base = _safe_base_url(cfg.base_url)
    headers = {**_headers(cfg, True), "Content-Type": "application/json"}
    response = httpx.post(base + "/rest/testcases/list", headers=headers,
        json={"tcFolderID": int(cfg.test_case_folder_id), "showAllStateEntities": True, "scope": cfg.scope, "start": 0, "limit": 500},
        timeout=30.0, follow_redirects=False)
    if response.status_code >= 400: raise RuntimeError(f"QMetry test-case pull failed with HTTP {response.status_code}; verify Open API permissions and folder ID")
    payload=response.json()
    candidates = payload.get("data", payload.get("result", payload)) if isinstance(payload, dict) else payload
    if isinstance(candidates, dict): candidates = candidates.get("data", candidates.get("testCases", candidates.get("records", [])))
    if not isinstance(candidates, list): candidates=[]
    from app.services.test_maintenance import ensure_initial_version, create_version
    imported=0; updated=0; unchanged=0
    for item in candidates[:500]:
        if not isinstance(item, dict): continue
        ext_id = str(item.get("tcID") or item.get("id") or item.get("testCaseId") or "")
        title = str(item.get("name") or item.get("summary") or item.get("testCaseName") or "").strip()
        if not title: continue
        mapping = db.execute(select(QMetryTestMapping).where(QMetryTestMapping.external_id == ext_id)).scalar_one_or_none() if ext_id else None
        test = db.get(TestCase, mapping.test_case_id) if mapping else None
        detail = item
        ext_version = str(item.get("version") or item.get("tcVersion") or item.get("tcVersionNumber") or "1")
        if ext_id and not (item.get("steps") or item.get("testSteps")):
            try:
                detail_response = httpx.post(base + "/rest/testcases/list", headers=headers,
                    json={"id": int(ext_id), "version": int(ext_version), "scope": cfg.scope},
                    timeout=20.0, follow_redirects=False)
                if detail_response.status_code < 400:
                    detail_payload = detail_response.json()
                    detail_data = detail_payload.get("data", detail_payload.get("result", detail_payload)) if isinstance(detail_payload, dict) else detail_payload
                    if isinstance(detail_data, list) and detail_data: detail = detail_data[0]
                    elif isinstance(detail_data, dict): detail = detail_data
            except (ValueError, TypeError):
                detail = item
        remote_steps = detail.get("steps") or detail.get("testSteps") or item.get("steps") or item.get("testSteps") or []
        local_steps = []
        if isinstance(remote_steps, list):
            for step_index, remote_step in enumerate(remote_steps[:500], 1):
                if not isinstance(remote_step, dict): continue
                local_steps.append({"action": "manual_step", "value": str(remote_step.get("description") or remote_step.get("stepDescription") or ""),
                    "expected": {"text": str(remote_step.get("expectedOutcome") or remote_step.get("expectedResult") or "")},
                    "metadata": {"qmetry_order": step_index, "qmetry_input_data": str(remote_step.get("inputData") or ""), "requires_automation_mapping": True}})
        description = str(detail.get("description") or item.get("description") or "")
        incoming_hash = hashlib.sha256(json.dumps({"title":title[:240],"description":description,"steps":local_steps,"project":cfg.project_key}, sort_keys=True, default=str).encode()).hexdigest()
        if not test:
            test = TestCase(id=str(uuid.uuid4()), title=title[:240], project=cfg.project_key, description=description,
                platform="both", app_id="", prerequisites="Imported from QMetry. Convert manual steps to executable actions before running.",
                test_data={}, steps=local_steps)
            db.add(test); db.flush(); ensure_initial_version(db, test); imported += 1
        elif mapping and mapping.last_hash != incoming_hash:
            current = db.query(TestCaseVersion).filter_by(test_case_id=test.id, status="approved").order_by(TestCaseVersion.version_number.desc()).first()
            definition = {"title":title[:240],"project":cfg.project_key,"description":description,"platform":test.platform,
                "app_id":test.app_id,"prerequisites":"Imported update from QMetry. Review and approve this draft before execution.",
                "test_data":test.test_data or {},"steps":local_steps}
            create_version(db, test, definition, "Imported change from QMetry", parent_id=current.id if current else None, status="draft")
            updated += 1
        else:
            unchanged += 1
        if not mapping:
            mapping=QMetryTestMapping(id=str(uuid.uuid4()), test_case_id=test.id)
            db.add(mapping)
        mapping.external_id=ext_id; mapping.external_key=str(item.get("entityKey") or item.get("tcKey") or item.get("key") or "")
        mapping.external_version_id=str(detail.get("tcVersionID") or detail.get("tcVersionId") or item.get("tcVersionID") or item.get("tcVersionId") or "")
        mapping.last_synced_at=datetime.now(timezone.utc); mapping.last_hash=incoming_hash
    db.commit()
    return {"imported": imported, "updated": updated, "unchanged": unchanged, "received": len(candidates[:500])}

