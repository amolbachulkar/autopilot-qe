"""Version snapshots and conservative build-aware test maintenance helpers."""
from copy import deepcopy
from datetime import datetime, timezone
from uuid import uuid4
from sqlalchemy import select
from app.models.entities import TestCase, TestCaseVersion


def utcnow():
    return datetime.now(timezone.utc)


def definition_from_test(test: TestCase) -> dict:
    return {
        "title": test.title,
        "project": test.project,
        "description": test.description,
        "platform": test.platform,
        "app_id": test.app_id,
        "prerequisites": test.prerequisites,
        "test_data": deepcopy(test.test_data or {}),
        "steps": deepcopy(test.steps or []),
    }


def validate_definition(definition: dict) -> dict:
    if not isinstance(definition, dict):
        raise ValueError("Test definition must be an object")
    steps = definition.get("steps", [])
    if not isinstance(steps, list) or len(steps) > 500:
        raise ValueError("A test definition must contain at most 500 steps")
    if not isinstance(definition.get("test_data", {}), dict):
        raise ValueError("test_data must be an object")
    for index, step in enumerate(steps):
        if not isinstance(step, dict) or not isinstance(step.get("action"), str) or not step["action"].strip() or len(step["action"]) > 60:
            raise ValueError(f"Step {index + 1} must contain a valid action")
        if not isinstance(step.get("target", {}), dict) or not isinstance(step.get("expected", {}), dict):
            raise ValueError(f"Step {index + 1} target and expected values must be objects")
    return definition


def ensure_initial_version(db, test: TestCase) -> TestCaseVersion:
    # Serialize first-time snapshot creation on PostgreSQL; uniqueness remains the final guard.
    db.execute(select(TestCase.id).where(TestCase.id == test.id).with_for_update()).first()
    versions = db.query(TestCaseVersion).filter_by(test_case_id=test.id).order_by(TestCaseVersion.version_number.desc()).all()
    if versions:
        return next((v for v in versions if v.version_number == test.active_version), versions[0])
    version = TestCaseVersion(
        id=str(uuid4()), test_case_id=test.id, version_number=1, status="approved",
        definition=definition_from_test(test), change_summary="Initial imported test definition", approved_at=utcnow(),
    )
    db.add(version)
    test.active_version = 1
    db.flush()
    return version


def create_version(db, test: TestCase, definition: dict, summary: str, parent_id: str | None = None, status: str = "draft", build_id: str | None = None) -> TestCaseVersion:
    # Prevent concurrent approvals/proposals from allocating the same next version number.
    db.execute(select(TestCase.id).where(TestCase.id == test.id).with_for_update()).first()
    latest = db.query(TestCaseVersion).filter_by(test_case_id=test.id).order_by(TestCaseVersion.version_number.desc()).first()
    number = (latest.version_number if latest else 0) + 1
    validate_definition(definition)
    version = TestCaseVersion(
        id=str(uuid4()), test_case_id=test.id, version_number=number, status=status,
        definition=deepcopy(definition), change_summary=summary, parent_version_id=parent_id, build_id=build_id,
        approved_at=utcnow() if status == "approved" else None,
    )
    db.add(version)
    db.flush()
    if status == "approved" and build_id is None:
        test.active_version = number
        _sync_test_projection(test, version.definition)
    return version


def _sync_test_projection(test: TestCase, definition: dict) -> None:
    """Keep legacy API/list views aligned with the currently approved snapshot."""
    for field in ("title", "project", "description", "platform", "app_id", "prerequisites", "test_data", "steps"):
        if field in definition:
            setattr(test, field, deepcopy(definition[field]))
