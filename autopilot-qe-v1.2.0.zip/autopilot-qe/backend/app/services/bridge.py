"""In-memory websocket relay between a local Appium agent and browser clients.
For multi-worker deployments replace this relay with Redis pub/sub.
"""
import asyncio
from collections import defaultdict
from fastapi import WebSocket

class BridgeHub:
    def __init__(self):
        self.agents: dict[str, WebSocket] = {}
        self.viewers: dict[str, set[WebSocket]] = defaultdict(set)
        self.lock = asyncio.Lock()

    async def attach_agent(self, device_id: str, ws: WebSocket):
        async with self.lock: self.agents[device_id] = ws

    async def detach_agent(self, device_id: str, ws: WebSocket):
        async with self.lock:
            if self.agents.get(device_id) is ws: self.agents.pop(device_id, None)

    async def attach_viewer(self, device_id: str, ws: WebSocket):
        async with self.lock: self.viewers[device_id].add(ws)

    async def detach_viewer(self, device_id: str, ws: WebSocket):
        async with self.lock: self.viewers[device_id].discard(ws)

    async def to_agent(self, device_id: str, payload: dict):
        agent = self.agents.get(device_id)
        if agent:
            await agent.send_json(payload)
            return True
        return False

    async def broadcast(self, device_id: str, payload: dict):
        stale=[]
        for viewer in list(self.viewers.get(device_id, set())):
            try: await viewer.send_json(payload)
            except Exception: stale.append(viewer)
        for viewer in stale: await self.detach_viewer(device_id, viewer)

    def online(self, device_id: str) -> bool: return device_id in self.agents

hub = BridgeHub()
