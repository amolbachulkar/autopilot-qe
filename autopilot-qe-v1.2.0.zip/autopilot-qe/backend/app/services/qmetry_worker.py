"""Run with `python -m app.services.qmetry_worker` as a dedicated worker."""
import time
from app.core.database import SessionLocal
from app.services.qmetry import process_one

def main():
    while True:
        db=SessionLocal()
        try:
            worked=process_one(db)
        except Exception:
            db.rollback(); worked=False
        finally:
            db.close()
        if not worked: time.sleep(5)

if __name__ == "__main__": main()
