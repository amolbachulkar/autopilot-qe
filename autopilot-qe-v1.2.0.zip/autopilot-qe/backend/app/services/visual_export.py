import json


def generate_visual_script(test, checkpoints, target, app_name):
    cp_payload = repr(json.dumps(checkpoints, ensure_ascii=False))
    steps_payload = repr(json.dumps(test.get("steps", []), ensure_ascii=False))
    data_payload = repr(json.dumps(test.get("test_data", {}), ensure_ascii=False))
    title = repr(test.get("title", "AutoPilotQE visual test"))
    app = repr(app_name)
    if target == "playwright":
        lines = [
            "# Install: pip install eyes-playwright playwright",
            "# Set APPLITOOLS_API_KEY in the worker environment.",
            "import os, re, json", "from applitools.playwright import Eyes, Target, ClassicRunner, Configuration",
            "from playwright.sync_api import sync_playwright", "",
            f"CHECKPOINTS = json.loads({cp_payload})", f"STEPS = json.loads({steps_payload})",
            f"TEST_DATA = json.loads({data_payload})", f"APP_NAME = {app}", f"TEST_NAME = {title}",
            f"URL = {test.get('app_id', '')!r}", "",
            "def resolve(value):", "    if not isinstance(value, str): return value",
            "    def replace(match):", "        secret, key = match.group(1), match.group(2)",
            "        env = 'AUTOPILOTQE_SECRET_' + key if secret else None",
            "        if secret:", "            if env not in os.environ: raise RuntimeError('Missing secret: ' + env)",
            "            return os.environ[env]", "        if key not in TEST_DATA: raise RuntimeError('Missing test data: ' + key)",
            "        return str(TEST_DATA[key])", "    return re.sub(r'\\$\\{(?:(SECRET):)?([A-Za-z_][A-Za-z0-9_]*)\\}', replace, value)", "",
            "def locator(page, target):", "    if target.get('test_id'): return page.get_by_test_id(target['test_id'])",
            "    if target.get('role') and target.get('name'): return page.get_by_role(target['role'], name=target['name'])",
            "    if target.get('label'): return page.get_by_label(target['label'])",
            "    if target.get('placeholder'): return page.get_by_placeholder(target['placeholder'])",
            "    if target.get('text'): return page.get_by_text(target['text'], exact=True)",
            "    sel = target.get('css') or target.get('css_selector') or target.get('xpath')",
            "    if not sel: raise RuntimeError('Step is missing a locator')",
            "    return page.locator(('xpath=' if target.get('xpath') else '') + sel)", "",
            "def visual_check(eyes, page, cp):", "    wait_for = cp.get('wait_for_selector')",
            "    if wait_for: page.locator(wait_for).wait_for(state='visible')",
            "    if cp.get('disable_animations', True): page.add_style_tag(content='*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}')",
            "    if cp.get('hide_caret', True): page.add_style_tag(content='*{caret-color:transparent!important}')",
            "    for selector in cp.get('mask_selectors', []): page.locator(selector).evaluate(\"el => { el.dataset.mpOldStyle = el.getAttribute('style') || ''; el.style.visibility='hidden'; }\")",
            "    target = Target.window().fully() if cp.get('scope') == 'full_page' else Target.window()",
            "    if cp.get('scope') == 'element': target = Target.region(page.locator(cp['selector']))",
            "    level = cp.get('match_level', 'Dynamic').lower()",
            "    if level == 'strict': target = target.strict()",
            "    elif level == 'layout': target = target.layout()",
            "    elif level == 'ignorecolors': target = target.ignore_colors()",
            "    for selector in cp.get('ignore_selectors', []): target = target.ignore(page.locator(selector))",
            "    for selector in cp.get('layout_selectors', []): target = target.layout_regions(page.locator(selector))",
            "    try: eyes.check(cp['name'], target)", "    finally:",
            "        for selector in cp.get('mask_selectors', []): page.locator(selector).evaluate(\"el => { el.setAttribute('style', el.dataset.mpOldStyle || ''); delete el.dataset.mpOldStyle; }\")", "",
            "def run():", "    with sync_playwright() as p:", "        browser = p.chromium.launch(headless=True)", "        page = browser.new_page()", "        eyes = Eyes()", "        eyes.api_key = os.environ['APPLITOOLS_API_KEY']",
            "        eyes.open(page, APP_NAME, TEST_NAME)", "        try:",
            "            if URL: page.goto(URL, wait_until='domcontentloaded')",
            "            for cp in CHECKPOINTS:\n                if cp.get('after_step', 0) == 0: visual_check(eyes, page, cp)",
            "            for index, step in enumerate(STEPS, 1):", "                action = step.get('action', '').lower()", "                target = step.get('target') or {}", "                value = resolve(step.get('value', ''))", "                el = locator(page, target) if target else None",
            "                if action in ('navigate','goto','open'): page.goto(value or target.get('url'))",
            "                elif action in ('click','tap'): el.first.click()", "                elif action in ('fill','input','type'): el.first.fill(value)",
            "                elif action == 'select': el.first.select_option(value)", "                elif action == 'check': el.first.check()",
            "                elif action in ('assert_visible','verify_visible'): assert el.first.is_visible()",
            "                elif action in ('assert_text','verify_text'): assert (step.get('expected') or {}).get('text', value) in page.locator('body').inner_text()",
            "                elif action in ('assert_url','verify_url'): assert (step.get('expected') or {}).get('url', value) in page.url",
            "                elif action in ('assert_title','verify_title'): assert (step.get('expected') or {}).get('title', value) in page.title()",
            "                elif action in ('wait','sleep'): page.wait_for_timeout(min(max(int(float(value or 1)*1000),0),30000))",
            "                elif action == 'reload': page.reload()", "                elif action == 'back': page.go_back()",
            "                for cp in CHECKPOINTS:\n                    if cp.get('after_step', 0) == index: visual_check(eyes, page, cp)",
            "        finally:", "            eyes.close()", "            browser.close()", "",
            "if __name__ == '__main__': run()", ""
        ]
        return "autopilotqe_applitools_playwright.py", "\n".join(lines)

    lines = [
        "# Install: pip install eyes-selenium selenium (Appium uses Appium-Python-Client)",
        "# Set APPLITOOLS_API_KEY in the execution worker environment.", "import os, json",
        "from applitools.selenium import Eyes", "from selenium.webdriver.common.by import By",
        f"CHECKPOINTS = json.loads({cp_payload})", f"APP_NAME = {app}", f"TEST_NAME = {title}", "",
        "class AutoPilotQEVisualChecks:", "    def __init__(self, driver):", "        self.driver = driver", "        self.eyes = Eyes()",
        "        self.eyes.api_key = os.environ['APPLITOOLS_API_KEY']",
        "        self.eyes.server_url = os.getenv('APPLITOOLS_SERVER_URL', 'https://eyes.applitools.com')",
        "        self.eyes.open(driver, APP_NAME, TEST_NAME)",
        "    def after_step(self, step_number):", "        for cp in CHECKPOINTS:", "            if cp.get('after_step', 0) != step_number: continue",
        "            wait_for = cp.get('wait_for_selector')", "            if wait_for: self.driver.find_element(By.CSS_SELECTOR, wait_for)",
        "            if cp.get('scope') == 'element':", "                selector_type = cp.get('selector_type', 'css')",
        "                if selector_type == 'accessibility_id':", "                    from appium.webdriver.common.appiumby import AppiumBy", "                    by = AppiumBy.ACCESSIBILITY_ID",
        "                else: by = By.XPATH if selector_type == 'xpath' else By.CSS_SELECTOR",
        "                self.eyes.check_region(by=by, selector=cp['selector'], tag=cp['name'])",
        "            else: self.eyes.check_window(cp['name'])", "    def close(self):", "        try: self.eyes.close()",
        "        finally: self.eyes.abort_if_not_closed()", "",
        "# Usage: create AutoPilotQEVisualChecks(driver) before your journey; call after_step(n)",
        "# immediately after functional step n; call close() in your test's finally block.", ""
    ]
    return f"autopilotqe_applitools_{target}.py", "\n".join(lines)
