"""Password hashing, opaque revocable sessions, and role policy helpers."""
from __future__ import annotations
import hashlib, hmac, json, os, secrets
from datetime import datetime, timedelta, timezone
from uuid import uuid4
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.core.config import settings
from app.models.entities import User, AuthSession, AuditEvent, WebSocketTicket

ROLES = {"admin", "developer", "tester", "qe_lead", "product_owner"}

def utcnow(): return datetime.now(timezone.utc)

def normalize_email(email: str) -> str: return email.strip().lower()

def password_is_strong(password: str, minimum: int = 12) -> bool:
    groups = [any(c.islower() for c in password), any(c.isupper() for c in password),
              any(c.isdigit() for c in password), any(not c.isalnum() for c in password)]
    return len(password) >= minimum and sum(groups) >= 3

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return f"pbkdf2_sha256$310000${salt.hex()}${digest.hex()}"

def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, rounds, salt_hex, digest_hex = encoded.split("$")
        if scheme != "pbkdf2_sha256": return False
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds))
        return hmac.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError): return False

def token_digest(token: str) -> str:
    pepper = (settings.session_secret or "autopilotqe-development-only").encode()
    return hmac.new(pepper, token.encode(), hashlib.sha256).hexdigest()

def create_session(db: Session, user: User, ip: str = "", user_agent: str = "") -> tuple[str, datetime]:
    now = utcnow()
    token = secrets.token_urlsafe(48)
    expires = now + timedelta(hours=settings.session_ttl_hours)
    cutoff = now - timedelta(days=30)
    db.query(AuthSession).filter(or_(AuthSession.expires_at < cutoff, AuthSession.revoked_at < cutoff)).delete(synchronize_session=False)
    db.query(WebSocketTicket).filter(WebSocketTicket.expires_at < now).delete(synchronize_session=False)
    db.add(AuthSession(id=str(uuid4()), user_id=user.id, token_hash=token_digest(token), expires_at=expires,
                       ip_address=ip[:64], user_agent=user_agent[:300]))
    user.last_login_at = utcnow()
    db.add(AuditEvent(id=str(uuid4()), actor_user_id=user.id, action="auth.login", resource_type="session", details={"role": user.role}))
    db.commit()
    return token, expires

def resolve_session(db: Session, token: str):
    if not token or len(token) > 256: return None
    session = db.query(AuthSession).filter_by(token_hash=token_digest(token), revoked_at=None).first()
    if not session: return None
    expires = session.expires_at
    if expires.tzinfo is None: expires = expires.replace(tzinfo=timezone.utc)
    if expires <= utcnow(): return None
    user = db.get(User, session.user_id)
    if not user or not user.is_active: return None
    return user, session

def audit(db: Session, actor_id: str | None, action: str, resource_type: str = "", resource_id: str = "", details: dict | None = None):
    db.add(AuditEvent(id=str(uuid4()), actor_user_id=actor_id, action=action, resource_type=resource_type,
                      resource_id=resource_id, details=details or {}))

def role_invite_codes() -> dict:
    try:
        value = json.loads(settings.role_invite_codes or "{}")
        return value if isinstance(value, dict) else {}
    except json.JSONDecodeError: return {}

def seed_admin(db: Session):
    email = normalize_email(settings.bootstrap_admin_email)
    if not email or not settings.bootstrap_admin_password: return
    if db.query(User).filter_by(email=email).first(): return
    user = User(id=str(uuid4()), email=email, full_name=settings.bootstrap_admin_name,
                password_hash=hash_password(settings.bootstrap_admin_password), role="admin", is_active=True)
    db.add(user)
    audit(db, user.id, "admin.bootstrap", "user", user.id, {"email": email})
    db.commit()


def create_ws_ticket(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(WebSocketTicket(id=str(uuid4()), user_id=user.id, token_hash=token_digest(token),
                           expires_at=utcnow() + timedelta(seconds=60)))
    db.commit()
    return token

def consume_ws_ticket(db: Session, token: str) -> bool:
    if not token or len(token) > 256: return False
    row = db.query(WebSocketTicket).filter_by(token_hash=token_digest(token), consumed_at=None).first()
    if not row: return False
    expires = row.expires_at
    if expires.tzinfo is None: expires = expires.replace(tzinfo=timezone.utc)
    if expires <= utcnow(): return False
    row.consumed_at = utcnow(); db.commit()
    return True
