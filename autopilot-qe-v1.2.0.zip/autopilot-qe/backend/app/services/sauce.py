from app.core.config import settings

def sauce_configured() -> bool:
    return bool(settings.sauce_username and settings.sauce_access_key)

def sauce_remote_url() -> str:
    region = settings.sauce_region.strip() or "us-west-1"
    return f"https://ondemand.{region}.saucelabs.com/wd/hub"

def sauce_webdriver_url() -> str:
    if settings.sauce_webdriver_url:
        return settings.sauce_webdriver_url
    if not sauce_configured():
        return ""
    return f"https://{settings.sauce_username}:{settings.sauce_access_key}@ondemand.{settings.sauce_region}.saucelabs.com:443/wd/hub"

def sauce_capabilities(platform: str, device_name: str, os_version: str, app: str) -> dict:
    caps = {"platformName": platform, "appium:deviceName": device_name,
            "appium:automationName": "XCUITest" if platform.lower() == "ios" else "UiAutomator2",
            "sauce:options": {"name": "AutoPilotQE session"}}
    if os_version: caps["appium:platformVersion"] = os_version
    if app: caps["appium:app"] = app
    return caps
