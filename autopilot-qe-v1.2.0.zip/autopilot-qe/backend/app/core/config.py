from functools import lru_cache
from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "AutoPilotQE API"
    environment: str = "development"
    api_key: str = ""
    auth_required: bool = False
    session_secret: str = ""
    session_ttl_hours: int = Field(default=8, ge=1, le=72)
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: str = ""
    bootstrap_admin_name: str = "Platform Administrator"
    role_invite_codes: str = "{}"
    database_url: str = "sqlite:///./mobilepilot.db"
    cors_origins: str = "http://localhost:5173,http://localhost:8080"
    appium_url: str = "http://127.0.0.1:4723"
    sauce_username: str = ""
    sauce_access_key: str = ""
    sauce_region: str = "us-west-1"
    sauce_webdriver_url: str = ""
    headspin_appium_url: str = ""
    headspin_webdriver_url: str = ""
    headspin_api_token: str = ""
    headspin_api_base_url: str = "https://api.headspin.io"
    applitools_api_key: str = ""
    applitools_server_url: str = "https://eyes.applitools.com"
    applitools_app_name: str = "AutoPilotQE"
    artifacts_dir: str = "./artifacts"
    max_request_bytes: int = Field(default=2_000_000, ge=1024, le=20_000_000)
    auto_create_schema: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    @model_validator(mode="after")
    def validate_production(self):
        if self.environment.lower() == "production":
            if len(self.api_key) < 32:
                raise ValueError("API_KEY must contain at least 32 characters in production")
            if "sqlite" in self.database_url.lower():
                raise ValueError("PostgreSQL is required in production")
            if self.auto_create_schema:
                raise ValueError("AUTO_CREATE_SCHEMA must be false in production; apply migrations")
            if not self.auth_required or len(self.session_secret) < 32:
                raise ValueError("AUTH_REQUIRED=true and SESSION_SECRET (32+ characters) are required in production")
            admin_password = self.bootstrap_admin_password
            password_groups = [any(c.islower() for c in admin_password), any(c.isupper() for c in admin_password),
                               any(c.isdigit() for c in admin_password), any(not c.isalnum() for c in admin_password)]
            if not self.bootstrap_admin_email or len(admin_password) < 14 or sum(password_groups) < 3:
                raise ValueError("Set BOOTSTRAP_ADMIN_EMAIL and a 14+ character BOOTSTRAP_ADMIN_PASSWORD using at least three character classes")
        return self

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
