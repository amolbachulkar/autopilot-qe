from contextlib import asynccontextmanager
from pathlib import Path
import secrets
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.config import settings
from app.core.database import Base, engine, SessionLocal, get_db
from app.api.routes import router
from app.api.maintenance import router as maintenance_router
from app.api.auth import router as auth_router
from app.api.analytics import router as analytics_router
from app.api.qmetry import router as qmetry_router
from app.api.workspace import router as workspace_router
from app.services.auth import resolve_session, seed_admin, consume_ws_ticket
from app.models import entities  # noqa: F401
from app.services.bridge import hub


@asynccontextmanager
async def lifespan(_: FastAPI):
    Path(settings.artifacts_dir).mkdir(parents=True, exist_ok=True)
    if settings.auto_create_schema:
        Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_admin(db)
    finally:
        db.close()
    yield

app = FastAPI(title=settings.app_name, version="1.2.0", description="Hybrid mobile testing orchestration API", lifespan=lifespan,
              docs_url=None if settings.environment.lower() == "production" else "/docs",
              redoc_url=None if settings.environment.lower() == "production" else "/redoc",
              openapi_url=None if settings.environment.lower() == "production" else "/openapi.json")
app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins, allow_credentials=False,
                   allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
                   allow_headers=["Content-Type", "X-API-Key", "Authorization"])

class APIKeyMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        content_length = request.headers.get("content-length")
        if content_length and content_length.isdigit() and int(content_length) > settings.max_request_bytes:
            return JSONResponse(status_code=413, content={"detail": "Request body too large"})
        supplied = request.headers.get("x-api-key", "")
        public = request.url.path in {"/api/v1/health", "/api/v1/ready", "/api/v1/auth/signup", "/api/v1/auth/login"}
        if supplied:
            if not settings.api_key or not secrets.compare_digest(supplied, settings.api_key):
                return JSONResponse(status_code=401, content={"detail": "Invalid API key"})
            path, method = request.url.path, request.method
            parts = path.strip("/").split("/")
            service_allowed = (
                (method == "POST" and (path == "/api/v1/devices" or path == "/api/v1/agent/executions/claim")) or
                (method == "POST" and path.startswith("/api/v1/recordings")) or
                (method == "POST" and len(parts) == 5 and parts[:3] == ["api", "v1", "executions"] and parts[4] == "complete") or
                (method == "GET" and len(parts) == 4 and parts[:3] == ["api", "v1", "tests"]) or
                (method == "GET" and len(parts) == 5 and parts[:3] == ["api", "v1", "tests"] and parts[4] in {"visual-checkpoints", "visual-script"})
            )
            # Machine credentials are restricted to worker/device operations, never admin or QE dashboards.
            if not service_allowed:
                return JSONResponse(status_code=403, content={"detail": "Service API keys are not authorized for this endpoint; use a user session"})
            request.state.service_auth = True
        elif settings.api_key and not public and not request.headers.get("authorization") and not settings.auth_required:
            return JSONResponse(status_code=401, content={"detail": "A valid API key or user session is required"})
        return await call_next(request)

class RoleAuthMiddleware(BaseHTTPMiddleware):
    def _allowed_roles(self, path: str, method: str):
        if path.startswith("/api/v1/analytics"):
            return {"admin", "qe_lead", "product_owner"}
        if path.startswith("/api/v1/projects") or path.startswith("/api/v1/requirements") or path.startswith("/api/v1/defects") or path.startswith("/api/v1/users/directory"):
            if method == "GET": return {"admin", "developer", "tester", "qe_lead", "product_owner"}
            return {"admin", "developer", "tester", "qe_lead", "product_owner"}
        if path.startswith("/api/v1/integrations/qmetry/jobs"):
            return {"admin", "qe_lead"}
        if path == "/api/v1/integrations/qmetry" and method == "PUT":
            return {"admin"}
        if path.startswith("/api/v1/integrations/qmetry") and method in {"POST", "DELETE"}:
            return {"admin", "qe_lead"}
        if path.startswith("/api/v1/analytics"):
            return {"admin", "qe_lead"}
        if path.startswith("/api/v1/auth/users"):
            return {"admin"}
        if path.endswith("/approve") or path.endswith("/accept") or "/rollback/" in path:
            return {"admin", "qe_lead"}
        if path.startswith("/api/v1/auth/users") or path.startswith("/api/v1/auth/audit-events"):
            return {"admin"}
        if path == "/api/v1/builds" and method == "POST":
            return {"admin", "developer", "qe_lead"}
        if path.endswith("/versions") and method == "POST":
            return {"admin", "developer", "qe_lead"}
        if (path.endswith("/visual-checkpoints") or "/visual-checkpoints/" in path) and method in {"POST", "PATCH", "DELETE"}:
            return {"admin", "developer", "qe_lead"}
        if path.startswith("/api/v1/devices") and method in {"POST", "PATCH", "DELETE"}:
            return {"admin", "developer", "qe_lead"}
        if path.startswith("/api/v1/providers") and method in {"POST", "PATCH", "DELETE"}:
            return {"admin", "developer", "qe_lead"}
        if path.startswith("/api/v1/web/browsers") and method in {"POST", "PATCH", "DELETE"}:
            return {"admin", "developer", "qe_lead"}
        if path == "/api/v1/tests" and method == "POST":
            return {"admin", "developer", "tester", "qe_lead", "product_owner"}
        if path.endswith("/execute") and method == "POST":
            return {"admin", "developer", "tester", "qe_lead", "product_owner"}
        if path.startswith("/api/v1/recordings") and method != "GET":
            return {"admin", "developer", "tester", "qe_lead", "product_owner"}
        if path.startswith("/api/v1/tests/") and method in {"PATCH", "PUT", "DELETE"} and not path.endswith("/test-data"):
            return {"admin", "developer", "qe_lead"}
        if method in {"POST", "PUT", "PATCH", "DELETE"}:
            return {"admin", "developer", "tester", "qe_lead", "product_owner"}
        return {"admin", "developer", "tester", "qe_lead", "product_owner"}

    async def dispatch(self, request, call_next):
        path = request.url.path
        public = path in {"/api/v1/health", "/api/v1/ready", "/api/v1/auth/signup", "/api/v1/auth/login"}
        if not path.startswith("/api/v1/") or public or getattr(request.state, "service_auth", False):
            return await call_next(request)
        authorization = request.headers.get("authorization", "")
        token = authorization[7:].strip() if authorization.lower().startswith("bearer ") else ""
        user = None
        if token:
            override = request.app.dependency_overrides.get(get_db)
            db_generator = (override or get_db)()
            db = next(db_generator)
            try:
                resolved = resolve_session(db, token)
                if not resolved:
                    return JSONResponse(status_code=401, content={"detail": "Session is invalid or expired"})
                user, _ = resolved
                request.state.user = user
            finally:
                try: next(db_generator)
                except StopIteration: pass
        elif settings.auth_required:
            return JSONResponse(status_code=401, content={"detail": "Authentication required"})
        if user:
            parts = path.strip("/").split("/")
            if path.startswith("/api/v1/agent/") or (request.method == "POST" and len(parts) == 5 and parts[:3] == ["api", "v1", "executions"] and parts[4] == "complete"):
                return JSONResponse(status_code=403, content={"detail": "This endpoint is reserved for authenticated execution agents"})
            allowed = self._allowed_roles(path, request.method)
            if user.role == "product_owner" and request.method in {"POST", "PUT", "PATCH", "DELETE"} and path != "/api/v1/auth/logout":
                po_allowed = (request.method == "POST" and (path == "/api/v1/projects" or path.endswith("/members") or path.endswith("/requirements") or path.endswith("/release-decisions"))) or (request.method == "PATCH" and path.startswith("/api/v1/requirements/"))
                if not po_allowed:
                    return JSONResponse(status_code=403, content={"detail": "Product Owner access is limited to requirement authoring and release decisions"})
            if user.role not in allowed:
                return JSONResponse(status_code=403, content={"detail": "Your role does not have permission for this action"})
        return await call_next(request)

app.add_middleware(RoleAuthMiddleware)
app.add_middleware(APIKeyMiddleware)
app.include_router(auth_router)
app.include_router(analytics_router)
app.include_router(qmetry_router)
app.include_router(workspace_router)
app.include_router(router)
app.include_router(maintenance_router)

@app.get("/")
def root():
    return {"name": "AutoPilotQE", "docs": "/docs", "health": "/api/v1/health"}


def valid_ws_key(websocket: WebSocket, allow_service_key: bool = False) -> bool:
    # Browser viewers use a short-lived one-time ticket; agents use the service API key.
    header_key = websocket.headers.get("x-api-key", "")
    query_key = websocket.query_params.get("token", "")
    if allow_service_key and settings.api_key and header_key and secrets.compare_digest(header_key, settings.api_key): return True
    if query_key:
        db = SessionLocal()
        try: return consume_ws_ticket(db, query_key)
        finally: db.close()
    return not settings.auth_required and not settings.api_key

@app.websocket("/api/v1/bridge/agent/{device_id}")
async def bridge_agent(device_id: str, websocket: WebSocket):
    if not valid_ws_key(websocket, allow_service_key=True):
        await websocket.close(code=4401, reason="Unauthorized")
        return
    await websocket.accept()
    await hub.attach_agent(device_id, websocket)
    await hub.broadcast(device_id, {"type": "agent_status", "online": True})
    try:
        while True:
            message = await websocket.receive_json()
            await hub.broadcast(device_id, message)
    except WebSocketDisconnect:
        pass
    finally:
        await hub.detach_agent(device_id, websocket)
        await hub.broadcast(device_id, {"type": "agent_status", "online": False})

@app.websocket("/api/v1/bridge/ui/{device_id}")
async def bridge_ui(device_id: str, websocket: WebSocket):
    if not valid_ws_key(websocket):
        await websocket.close(code=4401, reason="Unauthorized")
        return
    await websocket.accept()
    await hub.attach_viewer(device_id, websocket)
    await websocket.send_json({"type": "agent_status", "online": hub.online(device_id)})
    try:
        while True:
            message = await websocket.receive_json()
            if not isinstance(message, dict) or len(str(message)) > 16_000:
                await websocket.send_json({"type": "error", "message": "Invalid or oversized bridge command"})
                continue
            if not await hub.to_agent(device_id, message):
                await websocket.send_json({"type": "error", "message": "Device agent is offline. Start the local agent."})
    except WebSocketDisconnect:
        pass
    finally:
        await hub.detach_viewer(device_id, websocket)
