from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, Boolean, ForeignKey, JSON, Integer, Float, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base

def now(): return datetime.now(timezone.utc)

class Device(Base):
    __tablename__ = "devices"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    platform: Mapped[str] = mapped_column(String(20))
    os_version: Mapped[str] = mapped_column(String(40), default="unknown")
    device_type: Mapped[str] = mapped_column(String(30), default="emulator")
    provider: Mapped[str] = mapped_column(String(30), default="local")
    status: Mapped[str] = mapped_column(String(30), default="available")
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

class TestCase(Base):
    __tablename__ = "test_cases"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(240))
    project: Mapped[str] = mapped_column(String(160), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    platform: Mapped[str] = mapped_column(String(20), default="both")
    app_id: Mapped[str] = mapped_column(String(240), default="")
    prerequisites: Mapped[str] = mapped_column(Text, default="")
    test_data: Mapped[dict] = mapped_column(JSON, default=dict)
    steps: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    active_version: Mapped[int] = mapped_column(Integer, default=1)

class RecordingSession(Base):
    __tablename__ = "recording_sessions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(240))
    device_id: Mapped[str] = mapped_column(String(64), default="")
    app_id: Mapped[str] = mapped_column(String(240), default="")
    status: Mapped[str] = mapped_column(String(30), default="recording")
    prerequisites: Mapped[str] = mapped_column(Text, default="")
    test_data: Mapped[dict] = mapped_column(JSON, default=dict)
    steps: Mapped[list] = mapped_column(JSON, default=list)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class Execution(Base):
    __tablename__ = "executions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id"))
    device_id: Mapped[str] = mapped_column(String(64), default="")
    status: Mapped[str] = mapped_column(String(30), default="queued")
    result: Mapped[dict] = mapped_column(JSON, default=dict)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    build_id: Mapped[str | None] = mapped_column(ForeignKey("application_builds.id"), nullable=True)
    test_case_version_id: Mapped[str | None] = mapped_column(ForeignKey("test_case_versions.id"), nullable=True)


class VisualCheckpoint(Base):
    __tablename__ = "visual_checkpoints"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(180))
    scope: Mapped[str] = mapped_column(String(24), default="full_page")
    selector: Mapped[str] = mapped_column(Text, default="")
    selector_type: Mapped[str] = mapped_column(String(24), default="css")
    match_level: Mapped[str] = mapped_column(String(24), default="Dynamic")
    after_step: Mapped[int] = mapped_column(Integer, default=0)
    ignore_selectors: Mapped[list] = mapped_column(JSON, default=list)
    layout_selectors: Mapped[list] = mapped_column(JSON, default=list)
    mask_selectors: Mapped[list] = mapped_column(JSON, default=list)
    wait_for_selector: Mapped[str] = mapped_column(Text, default="")
    full_page: Mapped[bool] = mapped_column(Boolean, default=True)
    disable_animations: Mapped[bool] = mapped_column(Boolean, default=True)
    hide_caret: Mapped[bool] = mapped_column(Boolean, default=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class ApplicationBuild(Base):
    __tablename__ = "application_builds"
    __table_args__ = (UniqueConstraint("fingerprint", name="uq_application_build_fingerprint"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    project: Mapped[str] = mapped_column(String(160), default="", index=True)
    app_id: Mapped[str] = mapped_column(String(240), default="", index=True)
    platform: Mapped[str] = mapped_column(String(24), index=True)
    version_name: Mapped[str] = mapped_column(String(80), default="unknown")
    build_number: Mapped[str] = mapped_column(String(80), default="unknown")
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class TestCaseVersion(Base):
    __tablename__ = "test_case_versions"
    __table_args__ = (UniqueConstraint("test_case_id", "version_number", name="uq_test_case_version_number"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    version_number: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="draft", index=True)
    definition: Mapped[dict] = mapped_column(JSON, default=dict)
    change_summary: Mapped[str] = mapped_column(Text, default="")
    parent_version_id: Mapped[str | None] = mapped_column(ForeignKey("test_case_versions.id"), nullable=True)
    build_id: Mapped[str | None] = mapped_column(ForeignKey("application_builds.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class HealingProposal(Base):
    __tablename__ = "healing_proposals"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    execution_id: Mapped[str] = mapped_column(ForeignKey("executions.id", ondelete="CASCADE"), index=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    test_case_version_id: Mapped[str | None] = mapped_column(ForeignKey("test_case_versions.id"), nullable=True)
    build_id: Mapped[str | None] = mapped_column(ForeignKey("application_builds.id"), nullable=True)
    step_index: Mapped[int] = mapped_column(Integer)
    original_locator: Mapped[dict] = mapped_column(JSON, default=dict)
    candidate_locator: Mapped[dict] = mapped_column(JSON, default=dict)
    confidence: Mapped[float] = mapped_column(Float)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    reviewed_by: Mapped[str] = mapped_column(String(160), default="")
    review_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160), default="")
    password_hash: Mapped[str] = mapped_column(String(256))
    role: Mapped[str] = mapped_column(String(24), default="tester", index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    ip_address: Mapped[str] = mapped_column(String(64), default="")
    user_agent: Mapped[str] = mapped_column(String(300), default="")


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    actor_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(100), index=True)
    resource_type: Mapped[str] = mapped_column(String(80), default="")
    resource_id: Mapped[str] = mapped_column(String(64), default="")
    details: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)


class WebSocketTicket(Base):
    __tablename__ = "websocket_tickets"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    consumed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class QMetryIntegration(Base):
    __tablename__ = "qmetry_integrations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default="default")
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    edition: Mapped[str] = mapped_column(String(24), default="enterprise")
    base_url: Mapped[str] = mapped_column(String(500), default="")
    project_key: Mapped[str] = mapped_column(String(160), default="")
    project_id: Mapped[str] = mapped_column(String(80), default="")
    test_case_folder_id: Mapped[str] = mapped_column(String(80), default="")
    scope: Mapped[str] = mapped_column(String(24), default="project")
    sync_test_cases: Mapped[bool] = mapped_column(Boolean, default=True)
    sync_executions: Mapped[bool] = mapped_column(Boolean, default=True)
    api_key_encrypted: Mapped[str] = mapped_column(Text, default="")
    user_token_encrypted: Mapped[str] = mapped_column(Text, default="")
    org_code: Mapped[str] = mapped_column(String(160), default="")
    jira_auth_type: Mapped[str] = mapped_column(String(16), default="bearer")
    jira_username: Mapped[str] = mapped_column(String(240), default="")
    jira_token_encrypted: Mapped[str] = mapped_column(Text, default="")
    test_case_folder_path: Mapped[str] = mapped_column(String(500), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    last_test_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_status: Mapped[str] = mapped_column(String(24), default="not_configured")
    last_error: Mapped[str] = mapped_column(Text, default="")


class QMetryTestMapping(Base):
    __tablename__ = "qmetry_test_mappings"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), unique=True, index=True)
    external_id: Mapped[str] = mapped_column(String(120), default="")
    external_key: Mapped[str] = mapped_column(String(120), default="")
    external_version_id: Mapped[str] = mapped_column(String(120), default="")
    last_synced_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_hash: Mapped[str] = mapped_column(String(64), default="")


class QMetrySyncJob(Base):
    __tablename__ = "qmetry_sync_jobs"
    __table_args__ = (UniqueConstraint("idempotency_key", name="uq_qmetry_sync_idempotency"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    idempotency_key: Mapped[str] = mapped_column(String(240), index=True)
    entity_type: Mapped[str] = mapped_column(String(32), index=True)
    entity_id: Mapped[str] = mapped_column(String(64), index=True)
    operation: Mapped[str] = mapped_column(String(32), default="upsert")
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=8)
    next_attempt_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    last_error: Mapped[str] = mapped_column(Text, default="")
    external_ref: Mapped[str] = mapped_column(String(160), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Project(Base):
    __tablename__ = "projects"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    key: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    description: Mapped[str] = mapped_column(Text, default="")
    product: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(24), default="active", index=True)
    owner_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

class ProjectMember(Base):
    __tablename__ = "project_members"
    __table_args__ = (UniqueConstraint("project_id", "user_id", name="uq_project_member"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    project_role: Mapped[str] = mapped_column(String(24), default="contributor")
    added_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Requirement(Base):
    __tablename__ = "requirements"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(40), index=True)
    title: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text, default="")
    acceptance_criteria: Mapped[list] = mapped_column(JSON, default=list)
    priority: Mapped[str] = mapped_column(String(16), default="medium")
    status: Mapped[str] = mapped_column(String(24), default="draft", index=True)
    owner_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    external_ref: Mapped[str] = mapped_column(String(160), default="")
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)

class RequirementTestLink(Base):
    __tablename__ = "requirement_test_links"
    __table_args__ = (UniqueConstraint("requirement_id", "test_case_id", name="uq_requirement_test_link"),)
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    requirement_id: Mapped[str] = mapped_column(ForeignKey("requirements.id", ondelete="CASCADE"), index=True)
    test_case_id: Mapped[str] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Defect(Base):
    __tablename__ = "defects"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    key: Mapped[str] = mapped_column(String(40), index=True)
    title: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text, default="")
    severity: Mapped[str] = mapped_column(String(16), default="major", index=True)
    priority: Mapped[str] = mapped_column(String(16), default="medium")
    status: Mapped[str] = mapped_column(String(24), default="open", index=True)
    platform: Mapped[str] = mapped_column(String(24), default="unknown")
    build_id: Mapped[str | None] = mapped_column(ForeignKey("application_builds.id"), nullable=True, index=True)
    test_case_id: Mapped[str | None] = mapped_column(ForeignKey("test_cases.id"), nullable=True, index=True)
    execution_id: Mapped[str | None] = mapped_column(ForeignKey("executions.id"), nullable=True, index=True)
    assignee_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    external_ref: Mapped[str] = mapped_column(String(160), default="")
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, onupdate=now)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

class ReleaseDecision(Base):
    __tablename__ = "release_decisions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), index=True)
    build_id: Mapped[str | None] = mapped_column(ForeignKey("application_builds.id"), nullable=True, index=True)
    version_label: Mapped[str] = mapped_column(String(100), default="")
    decision: Mapped[str] = mapped_column(String(16), index=True)
    rationale: Mapped[str] = mapped_column(Text, default="")
    conditions: Mapped[list] = mapped_column(JSON, default=list)
    metrics_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    decided_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
