# AutoPilotQE – Chrome Universal Recorder

This Manifest V3 extension captures browser navigation, clicks, form changes, selects, checkboxes and form submissions into an active AutoPilotQE recording session. It records field values as `${VARIABLE}` placeholders and likely secrets as `${SECRET:VARIABLE}`; literal entered values are not copied into step payloads.

## Install
1. Start AutoPilotQE API and create a recording session in **Universal Recorder → Web application**.
2. In Chrome/Chromium, open `chrome://extensions` and enable Developer mode.
3. Choose **Load unpacked** and select this `browser-extension` folder.
4. Open the target website. Open the extension popup.
5. Set API URL (normally `http://localhost:8000`), API key if configured, and the active recording session ID. Select **Save connection**.
6. Select **Enable recording on this tab**. Grant access to the current website when Chrome asks.
7. Interact with the page. Steps appear in the active AutoPilotQE recording. Stop and save the session in the web app.

## Permissions and safety
- The extension requests access to the configured AutoPilotQE API and only the website origin on which you explicitly enable recording.
- It does not capture keystrokes on every keypress; field values are converted to variable placeholders when a change/blur event is emitted.
- Passwords, OTPs and fields with secret-like names/autocomplete metadata are emitted as secret placeholders, not literal values.
- Do not use on pages containing sensitive information unless you have permission to test them.
- This extension is a recorder companion; it does not itself execute tests. Execute saved tests with the AutoPilotQE Playwright/Selenium worker or export a standalone script.

## Browser support
The extension targets Chrome/Chromium Manifest V3. The AutoPilotQE web test engine separately supports Playwright Chromium/Firefox/WebKit locally and configured Selenium remote browsers.
