const $ = (id) => document.getElementById(id);
chrome.storage.local.get(['apiBase','apiKey','sessionId','enabled'], (cfg) => {
  $('apiBase').value = cfg.apiBase || 'http://localhost:8000'; $('apiKey').value = cfg.apiKey || ''; $('sessionId').value = cfg.sessionId || '';
  $('status').textContent = cfg.enabled ? 'Recording enabled for configured session.' : 'Not recording.';
  $('toggle').textContent = cfg.enabled ? 'Disable recording' : 'Enable recording on this tab';
});
$('save').addEventListener('click', async () => {
  const apiBase = $('apiBase').value.trim().replace(/\/$/, '');
  const sessionId = $('sessionId').value.trim();
  if (!/^https?:\/\//.test(apiBase) || !sessionId) { $('status').textContent = 'Enter a valid API URL and recording session ID.'; return; }
  try {
    const origin = new URL(apiBase).origin;
    const permitted = await chrome.permissions.contains({ origins:[origin + '/*'] });
    if (!permitted) {
      const granted = await chrome.permissions.request({ origins:[origin + '/*'] });
      if (!granted) { $('status').textContent = 'Permission to connect to the API was not granted.'; return; }
    }
    await chrome.storage.local.set({apiBase,apiKey:$('apiKey').value,sessionId,enabled:false});
    $('status').textContent = 'Connection saved. Enable recording to capture this tab.';
  } catch (e) { $('status').textContent = String(e); }
});
$('toggle').addEventListener('click', async () => {
  const cfg = await chrome.storage.local.get(['apiBase','sessionId','enabled']);
  if (!cfg.apiBase || !cfg.sessionId) { $('status').textContent = 'Save an API URL and session ID first.'; return; }
  if (cfg.enabled) { await chrome.storage.local.set({enabled:false}); $('toggle').textContent='Enable recording on this tab'; $('status').textContent='Recording disabled.'; return; }
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id || !tab.url || !/^https?:/.test(tab.url)) { $('status').textContent='Open a normal website tab first.'; return; }
  const origin = new URL(tab.url).origin;
  const allowed = await chrome.permissions.request({origins:[origin + '/*']});
  if (!allowed) { $('status').textContent='Site access was not granted.'; return; }
  await chrome.storage.local.set({enabled:true});
  $('toggle').textContent='Disable recording';
  try {
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']});
    chrome.tabs.sendMessage(tab.id,{type:'AUTOPILOTQE_CAPTURE_CURRENT'},()=>{ void chrome.runtime.lastError; });
    $('status').textContent='Recording enabled for this site. Interact with the page.';
  } catch (e) { $('status').textContent='Could not inject recorder. Refresh the tab and try again.'; }
});
