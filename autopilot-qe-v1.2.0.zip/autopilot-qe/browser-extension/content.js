(() => {
  if (window.__autopilotqeRecorderInstalled) return;
  window.__autopilotqeRecorderInstalled = true;
  let scrollTimer = null;
  const now = () => new Date().toISOString();
  const safe = (v) => String(v || '').slice(0, 500);
  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `#${CSS.escape(el.id)}`;
    const testId = el.getAttribute('data-testid') || el.getAttribute('data-test');
    if (testId) return `[data-testid="${CSS.escape(testId)}"]`;
    const parts = [];
    while (el && el.nodeType === 1 && parts.length < 5) {
      let part = el.tagName.toLowerCase();
      if (el.getAttribute('name')) part += `[name="${CSS.escape(el.getAttribute('name'))}"]`;
      else if (el.classList?.length) part += '.' + [...el.classList].slice(0, 2).map(CSS.escape).join('.');
      parts.unshift(part); el = el.parentElement;
    }
    return parts.join(' > ');
  }
  function describe(el) {
    const tag = (el.tagName || '').toLowerCase();
    const type = safe(el.getAttribute('type')).toLowerCase();
    const label = el.labels?.[0]?.innerText || '';
    const role = el.getAttribute('role') || ({button:'button',a:'link',input:'textbox',textarea:'textbox',select:'combobox'}[tag] || '');
    const name = el.getAttribute('aria-label') || el.getAttribute('title') || label || el.innerText?.trim().slice(0, 100) || '';
    const fieldName = safe(el.getAttribute('name') || el.id || label || tag).toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_|_$/g, '') || 'FIELD';
    const sensitive = type === 'password' || /password|passwd|secret|token|otp|pin|cvv/i.test(`${el.name} ${el.id} ${el.autocomplete} ${label}`);
    const isField = ['input','textarea','select'].includes(tag);
    const value = isField ? (sensitive ? '${SECRET:' + fieldName + '}' : '${' + fieldName + '}') : null;
    return {
      tag, css: cssPath(el), ...(el.getAttribute('data-testid') ? {test_id:el.getAttribute('data-testid')} : {}),
      ...(role ? {role} : {}), ...(name ? {name:safe(name)} : {}), ...(label ? {label:safe(label)} : {}),
      ...(el.getAttribute('placeholder') ? {placeholder:safe(el.getAttribute('placeholder'))} : {}),
      ...(el.getAttribute('href') ? {href:safe(el.getAttribute('href'))} : {}),
      ...(el.id ? {id:safe(el.id)} : {}), ...(el.getAttribute('name') ? {field_name:safe(el.getAttribute('name'))} : {}),
      sensitive, variable: isField ? fieldName : undefined
    , value };
  }
  function emit(action, el, value = null, expected = {}) {
    if (!el) return;
    const info = describe(el);
    const step = { action, target: info, value: value ?? info.value ?? null, expected, timestamp: now(), metadata: { source:'chrome-extension', url:location.href, title:document.title, tag:info.tag, redacted:!!info.sensitive } };
    chrome.runtime.sendMessage({ type:'AUTOPILOTQE_STEP', step }, () => { void chrome.runtime.lastError; });
  }
  document.addEventListener('click', (event) => {
    const el = event.target?.closest?.('button,a,input[type=button],input[type=submit],[role=button],[data-testid]') || event.target;
    if (el && el.closest && el.closest('body')) emit('click', el);
  }, true);
  document.addEventListener('change', (event) => {
    const el = event.target;
    if (!el || !['INPUT','TEXTAREA','SELECT'].includes(el.tagName)) return;
    const info = describe(el);
    emit(el.tagName === 'SELECT' ? 'select' : (el.type === 'checkbox' || el.type === 'radio' ? 'check' : 'fill'), el, info.value);
  }, true);
  document.addEventListener('submit', (event) => {
    const form = event.target;
    emit('submit', form, null, { submit: true });
  }, true);
  document.addEventListener('scroll', (event) => {
    clearTimeout(scrollTimer);
    const el = event.target === document ? document.documentElement : event.target;
    scrollTimer = setTimeout(() => emit('scroll_into_view', el), 650);
  }, true);
  document.addEventListener('keydown', (event) => {
    if (['Enter','Escape','Tab'].includes(event.key) && event.target?.nodeType === 1) emit('press', event.target, event.key);
  }, true);
  function captureNavigation() { chrome.runtime.sendMessage({ type:'AUTOPILOTQE_STEP', step:{ action:'navigate', target:{url:location.href}, value:location.href, timestamp:now(), metadata:{source:'chrome-extension',title:document.title} } }, () => { void chrome.runtime.lastError; }); }
  chrome.runtime.onMessage.addListener((message) => { if (message?.type === 'AUTOPILOTQE_CAPTURE_CURRENT') captureNavigation(); });
  window.addEventListener('load', captureNavigation, { once:true });
  window.addEventListener('popstate', captureNavigation); window.addEventListener('hashchange', captureNavigation);
  const originalPushState = history.pushState.bind(history); history.pushState = (...args) => { const result = originalPushState(...args); setTimeout(captureNavigation, 0); return result; };
  const originalReplaceState = history.replaceState.bind(history); history.replaceState = (...args) => { const result = originalReplaceState(...args); setTimeout(captureNavigation, 0); return result; };
})();
