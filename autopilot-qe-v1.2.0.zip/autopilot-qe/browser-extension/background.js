chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'AUTOPILOTQE_STEP') return;
  chrome.storage.local.get(['apiBase', 'apiKey', 'sessionId', 'enabled'], async (cfg) => {
    if (!cfg.enabled || !cfg.sessionId || !cfg.apiBase) {
      sendResponse({ ok: false, error: 'Recorder is not enabled or session is missing.' }); return;
    }
    try {
      const response = await fetch(`${cfg.apiBase.replace(/\/$/, '')}/api/v1/recordings/${encodeURIComponent(cfg.sessionId)}/steps`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(cfg.apiKey ? { 'X-API-Key': cfg.apiKey } : {}) },
        body: JSON.stringify(message.step), keepalive: true
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.detail || `HTTP ${response.status}`);
      sendResponse({ ok: true, step_number: body.step_number });
    } catch (error) { sendResponse({ ok: false, error: String(error.message || error) }); }
  });
  return true;
});

// Re-inject only on origins the user explicitly granted while recording is enabled.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;
  chrome.storage.local.get(['enabled'], async (cfg) => {
    if (!cfg.enabled) return;
    try {
      const origin = new URL(tab.url).origin;
      const allowed = await chrome.permissions.contains({origins:[origin + '/*']});
      if (allowed) await chrome.scripting.executeScript({target:{tabId}, files:['content.js']});
    } catch (_) { /* restricted browser pages are intentionally not scriptable */ }
  });
});
