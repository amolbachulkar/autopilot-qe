# AutoPilotQE

**AI-Powered Quality Engineering Platform**  
*Autonomous Testing. Intelligent Quality. Faster Releases.*

Hybrid AI-assisted mobile quality engineering platform. This repository contains a React/TypeScript web console, FastAPI orchestration API, PostgreSQL-ready data model, and a Python/Appium device agent.

> **Implementation status (v1.2):** Includes a unified, project-scoped collaboration workspace for requirements, acceptance criteria, linked test cases, build inventory, defects, team membership and auditable release decisions. Also includes universal mobile/web recording, PlayStation DevKit Target Manager integration, Applitools visual checkpoints, failure triage, build-aware self-healing proposals, immutable test versions, signup/login with server-enforced RBAC, Admin/Developer/Tester/QE Lead/Product Owner workspaces, role-specific navigation and dashboards, and QE Lead/Product Owner read-only quality analytics. Provider credentials, real devices, Sony DevKit access and live cloud comparisons still require environment-specific staging validation.

## Architecture

**Release:** 1.2.0 – Unified project collaboration workspace, traceability, defect tracking and release governance

- **Web:** React 19 + TypeScript + Vite
- **API:** Python 3.12 + FastAPI + SQLAlchemy
- **Database:** PostgreSQL (Docker) or SQLite (local development)
- **Execution queue:** database-backed queued/running/completed lifecycle with host-side Appium and web workers; Redis is included in Compose but is not yet the distributed queue backend
- **Mobile automation:** Appium 2, UiAutomator2 (Android), XCUITest (iOS)
- **Device discovery:** `adb devices -l` and `xcrun simctl list devices booted --json`
- **Cloud:** Sauce Labs and HeadSpin Appium/Selenium provider adapters and configuration


## Unified project workspace (v1.2)

The **Project Workspace** is the shared delivery hub for Product Owners, Developers, Testers and QE Leads. A project groups requirements, acceptance criteria, reusable test cases, application builds, defects, team membership, executions and release decisions.

### Collaboration workflow

1. Create a project with a stable key (for example `MOBX`). The creator becomes its owner and initial member.
2. QE Leads, administrators or the project owner add active users to the project. Project membership scopes Developer, Tester and Product Owner visibility; QE Leads and Admins can oversee all projects. Existing free-text project groupings are migrated into project records where possible.
3. Product Owners author requirements and acceptance criteria; link existing unassigned test cases to establish requirement-to-test traceability.
4. Developers and Testers link test cases/builds, execute tests and log defects with optional build, test and execution references.
5. QE Leads and Product Owners record conditional/no-go/go release decisions with a persisted metrics snapshot. A plain GO is blocked while critical/blocker defects remain open; an explicit, justified override is restricted to QE Leads and administrators.

### Role responsibilities

- **Admin:** platform-wide access and governance.
- **Product Owner:** project visibility, requirement authoring and release recommendation/decision; no test execution administration or defect triage.
- **Developer:** test/build linking, defect updates and automation/build work.
- **Tester:** test linking, execution and defect reporting/updates.
- **QE Lead:** quality governance, release decisions, team membership and project quality oversight.

### Project workspace API

- `GET/POST /api/v1/projects` – list and create projects.
- `GET /api/v1/projects/{project_id}/workspace` – project summary, requirements, test cases, builds, defects, executions, members and release history.
- `POST /api/v1/projects/{project_id}/members` – add a project member.
- `POST /api/v1/projects/{project_id}/requirements` and `PATCH /api/v1/requirements/{requirement_id}` – author/update requirements and link test cases.
- `POST /api/v1/projects/{project_id}/defects` and `PATCH /api/v1/defects/{defect_id}` – track defects and their execution/build/test references.
- `POST /api/v1/projects/{project_id}/release-decisions` – record release decision and immutable quality snapshot.
- `POST /api/v1/projects/{project_id}/test-cases/{test_case_id}/link` and `/builds/{build_id}/link` – associate existing unassigned assets.

Migration: `0007_project_collaboration`. Project keys are used to associate the existing test case and build records without breaking their current IDs. Unassigned assets can be linked to a project; assets already assigned to a different project are not silently moved.

## Requirements

- Python 3.11+ (3.12 recommended)
- Node.js 20+
- Appium 2 server and the relevant driver (`uiautomator2`, `xcuitest`)
- Android SDK Platform Tools for Android devices
- macOS + Xcode + Xcode command-line tools for iOS simulator / physical iPhone automation
- Docker Desktop for the full PostgreSQL/Redis/container stack (optional for local API development)

## Run locally (recommended for device access)

### 1. Start the API

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://localhost:8000/docs

SQLite is used by default. The default file remains `backend/mobilepilot.db` for compatibility with existing installations; the database schema and migration history are unchanged.

### 2. Start the web app

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. For local development, create `frontend/.env.local` with `VITE_API_URL=http://localhost:8000` (and `VITE_API_KEY` only when the local API has API-key auth enabled).

### 3. Discover devices

Connect / boot an Android emulator or iOS simulator, then select **Device Lab → Discover devices**.

```bash
adb devices -l
xcrun simctl list devices booted
```

The discovery endpoint only sees devices accessible to the machine/container running the API. For local USB devices, running the API directly on the host is generally easiest. If containerized, pass through ADB/USB and host tools deliberately; the standard Compose file does not automatically expose host devices.

### 4. Start Appium

```bash
npm install -g appium
appium driver install uiautomator2
# On macOS for iOS:
appium driver install xcuitest
appium --address 0.0.0.0 --port 4723
```

For iOS, Appium/XCUITest must run on macOS with Xcode configured and a booted simulator or trusted, provisioned physical iPhone. Android requires a working SDK, accepted licenses, and USB debugging for physical devices.

### 5. Install and run the Python agent

```bash
cd agent
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
autopilotqe-agent replay <TEST_CASE_ID> --platform android --device-id emulator-5554
# iOS simulator example:
autopilotqe-agent replay <TEST_CASE_ID> --platform ios --device-id <SIMULATOR_UDID>
```

The test case ID is returned by `POST /api/v1/recordings/{session_id}/save-as-test` or `POST /api/v1/tests`.

## Docker deployment

```bash
cp .env.example .env
# Review secrets and settings before deployment.
docker compose up --build
```

- Web: http://localhost:8080
- API: http://localhost:8000
- Swagger: http://localhost:8000/docs
- PostgreSQL: localhost:5432 (internal Compose network by default)
- Redis: localhost:6379

The Compose deployment is a web/API/database baseline. It does **not** run a macOS/Xcode host, Appium server, or device passthrough. Use a host-side agent/Appium server for device access, or deploy dedicated macOS/Android execution workers.

## API quick reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/health` | Health check |
| GET | `/api/v1/devices` | List registered devices |
| POST | `/api/v1/devices/discover` | Discover local ADB / booted iOS simulators |
| POST | `/api/v1/devices` | Register a device |
| POST | `/api/v1/recordings` | Start a recording session |
| POST | `/api/v1/recordings/{id}/steps` | Append normalized interaction event |
| POST | `/api/v1/recordings/{id}/stop` | Stop recording |
| POST | `/api/v1/recordings/{id}/save-as-test` | Convert recording into reusable test case |
| GET/POST | `/api/v1/tests` | List/create test cases |
| GET | `/api/v1/tests/{id}` | Fetch test definition |
| POST | `/api/v1/tests/{id}/execute` | Queue execution record |
| GET | `/api/v1/executions` | List execution history |

### Recording event shape

```json
{
  "action": "tap",
  "target": {"accessibility_id": "login_button", "text": "Login"},
  "value": null,
  "expected": {"screen": "Login"},
  "screenshot": "artifacts/step-01.png",
  "timestamp": "2026-11-08T10:00:00Z",
  "metadata": {"app_version": "1.2.3", "orientation": "portrait"}
}
```

Supported replay actions in the initial agent: `launch`, `tap`, `input`, `swipe`/`scroll`, `back`, `wait`, and `assert_text`. Locators supported: accessibility ID, resource/id, XPath, class name and exact text fallback. Locator fallback is conservative; production self-healing should add confidence scoring, hierarchy diffs, approval workflow and immutable audit history.

## Security and production hardening

Before production use, add full user authentication/RBAC, TLS at the deployment edge, tenant isolation, signed agent registration, audit logs, artifact access controls and retention policies, a managed encrypted secret vault, stronger PII redaction, rate limits, distributed queue leases/retries, and device cleanup/recovery. The current API-key protection and database-backed worker queue are suitable for a controlled single-workspace beta, not a multi-tenant public service. Do not store real passwords or cloud access keys in source control or ordinary test data.

## Roadmap / known gaps

1. Redis-backed distributed execution queue, device leases, agent heartbeats, retries and crash recovery.
2. Sauce Labs app upload/device catalogue/session lifecycle and richer HeadSpin artifact/performance ingestion.
3. Durable step-level evidence storage, video/log collection and richer execution reports.
4. App build metadata collection (APK/IPA, package/bundle ID, version/build) and visual regression baselines.
5. AI test generation, exploratory navigation, defect clustering and human-approved self-healing.
6. Test suite tags, smoke/sanity/regression selection, CI webhooks and parallel device/browser matrix runs.
7. Full OIDC authentication, RBAC, audit trails and tenant isolation for enterprise deployment.

## License

Internal starter project. Add your organization's preferred license and dependency review before distribution.

### Interactive device recording (agent CLI)

The Python CLI recorder remains available for Appium-driven capture. The Universal Recorder adds browser capture through the Chrome/Chromium extension and native mobile capture through the Appium Live Bridge. The native bridge records interactions initiated through AutoPilotQE controls; it does not silently intercept arbitrary OS-wide physical touches. Platform-specific direct-touch capture remains subject to Android permissions and iOS restrictions.

```bash
autopilotqe-agent record --title "Login journey" --platform android \
  --device-id emulator-5554 --app /absolute/path/to/app.apk \
  --app-id com.example.app \
  --prerequisites "App installed; user is logged out" \
  --test-data '{"username":"${USERNAME}"}'
```

At the `autopilotqe>` prompt:

```text
tap {"accessibility_id":"login_button"}
type {"accessibility_id":"username"} ${USERNAME}
type {"accessibility_id":"password","sensitive":true} actual-secret-value
tap {"accessibility_id":"submit_login"}
assert Welcome
back
quit
```

For a sensitive input, set `"sensitive": true` in the locator JSON. The value is entered into the app but the recorded step stores a secret placeholder rather than the literal value. Supply secrets through a secure vault/agent environment in a production deployment.

For Sauce Labs, export `SAUCE_USERNAME`, `SAUCE_ACCESS_KEY`, and optionally `SAUCE_REGION` in the agent process environment, then use `--provider sauce --device-name "iPhone 16"` (or the exact Sauce device name) with a Sauce-supported `--app` storage reference. Upload the app to Sauce Storage separately; this starter does not yet automate app upload or query the Sauce device catalogue.

## Live Device Bridge (browser screen + remote interaction)

The Live Bridge tab streams screenshots from the host-side Appium agent to the browser and forwards browser-issued tap, swipe, type, back and home commands to the active Appium session. Each successful action is appended to the selected recording session with a screenshot artifact.

1. Start the API and web dashboard with `docker compose up --build`.
2. Install and start Appium 2 on the machine that can access the target device (`appium`). Install the platform driver (`appium driver install uiautomator2` for Android or `appium driver install xcuitest` on macOS for iOS).
3. Install agent dependencies: `cd agent && python -m pip install -r requirements.txt && python -m pip install -e .`.
4. Run `autopilotqe-agent discover --api-url http://localhost:8000` on the host with ADB/Xcode access (this discovers Android ADB devices and booted iOS simulators locally, then registers them with the API). Select a device in Device Lab and create a recording session in Recorder. The dashboard-side Discover button only sees devices visible to the API container/process.
5. Start the bridge from the host terminal, using the selected device UDID and active recording session ID:

   `autopilotqe-agent bridge --platform android --device-id <ANDROID_UDID> --session-id <RECORDING_SESSION_ID> --api-url http://localhost:8000`

   For iOS, use `--platform ios` on a macOS host with Xcode, a booted simulator or trusted physical device, and WebDriverAgent configured.
6. Open Live Bridge, select the same device, and click Connect browser. Click the streamed screen to tap; use the bridge controls for swipe, text, back, home and UI hierarchy capture. Enable “Mask this input in the recording” before entering passwords, OTPs or other sensitive values; the app still receives the text but the saved step stores a redaction token.
7. Stop the agent with Ctrl+C, then stop and save the recording in Recorder.

**Platform note:** this bridge records interactions initiated through the AutoPilotQE browser controls. It does not silently intercept arbitrary touches made directly on a physical device. Android raw input capture can be device/permission dependent; iOS does not provide a general-purpose API for third-party apps to observe arbitrary system-wide physical touches. The current relay is in-memory and intended for a single API worker; use Redis pub/sub and authenticated device pairing before multi-worker or production deployment. Do not expose the bridge WebSocket publicly without authentication and TLS.


## Security and container hardening (0.2)

The Compose deployment now requires a `.env` file with strong `POSTGRES_PASSWORD`, `REDIS_PASSWORD`, and `API_KEY` values (API key at least 32 characters). Database and Redis ports are not published; web/API ports bind to localhost by default. API requests use `X-API-Key`; WebSocket connections use `?token=`. The backend container runs as a non-root user and has a health check.

Production startup deliberately disables automatic schema creation. The backend container runs `alembic upgrade head` before starting the API and includes the initial `0001_initial` migration. Review migration diffs and take database backups before applying future schema changes; do not set `AUTO_CREATE_SCHEMA=true` in production to bypass migrations.

Docker is required to build and run the stack. On the current authoring host Docker CLI/daemon is unavailable, so image build and container integration tests could not be executed here. Python/API and frontend checks should be run on a Docker-enabled host before production use.


## Device execution worker

Queued test executions are claimed by a device-bound worker. Start one worker per connected Appium session/device (on the host with ADB/Xcode installed):

```bash
export AUTOPILOTQE_API_KEY="<same API_KEY from .env>"
autopilotqe-agent worker --platform android --device-id <ADB_SERIAL> --appium-url http://127.0.0.1:4723 --api-url http://localhost:8000
```

Use `--platform ios` on a macOS host with Xcode/WebDriverAgent. The worker polls only executions assigned to its device and reports step results. This is a first execution-worker foundation; production queue operations still need observability, lease expiry/recovery for crashed workers, retry policy, and distributed locking tests against PostgreSQL.


## Release status and important limitations

This revision is a **hardened self-hosted development/beta build**, not a certified production release. The Compose ports bind to `127.0.0.1` intentionally. Do not expose this single-workspace UI/API directly to the public internet: the browser receives the local workspace API key at build time. A multi-user internet-facing deployment needs OIDC/session-based authentication, tenant isolation, role-based access control, secret rotation, HTTPS termination, audit logging, and rate limiting.

The agent worker now claims queued executions and reports results, but lease recovery after an agent crash, bounded retries, distributed queue semantics, Sauce Labs session lifecycle, visual healing, and full physical-device integration tests remain follow-up work. No software can be guaranteed bug-free; validate on your supported host OS, Appium server, Xcode/Android SDK versions, and Sauce Labs account before production rollout.

## Clean Docker quick start

1. Install Docker Engine/Desktop with the Compose plugin.
2. Copy `.env.example` to `.env` and replace all placeholder secrets. Use separate random values for `API_KEY`, `POSTGRES_PASSWORD`, and `REDIS_PASSWORD` (at least 32 random characters is a good baseline).
3. Start the stack:

   ```bash
   docker compose config
   docker compose up --build -d
   docker compose ps
   docker compose logs -f api
   ```

4. Open `http://localhost:8080`. API docs are at `http://localhost:8000/docs`.
5. Install the agent on a host with Android SDK/ADB or macOS/Xcode:

   ```bash
   python -m venv .venv
   . .venv/bin/activate  # Windows: .venv\\Scripts\\activate
   pip install -e ./agent
   export AUTOPILOTQE_API_KEY="<API_KEY from .env>"
   autopilotqe-agent discover --api-url http://localhost:8000
   ```

The API container runs the initial Alembic migration before starting. The `artifacts/` directory is mounted from the project folder. Keep `.env` out of source control. This local Compose profile is not a public internet deployment; see the release limitations above.


### Secret test data

Sensitive text entered through Live Bridge is not written into the recorded step value and the post-action screenshot is suppressed for that action. The step stores a placeholder such as `${SECRET:PASSWORD}`. Set `AUTOPILOTQE_SECRET_PASSWORD` in the **agent host environment** before replay; secret values are not kept in the test-case JSON. Avoid storing credentials directly in ordinary `test_data`.


## Mobile + Web providers (v0.3)

AutoPilotQE now models mobile and browser execution targets in one device inventory. Test cases can use `platform=android`, `ios`, `web`, or `both`.

### Providers

- **Local mobile:** Appium with UiAutomator2 (Android) and XCUITest (iOS). Run the Python agent on the host that can access ADB/Xcode.
- **Sauce Labs mobile:** Appium remote sessions. Configure `SAUCE_USERNAME`, `SAUCE_ACCESS_KEY`, and `SAUCE_REGION`. App upload references must be Sauce Storage IDs/URLs accepted by your account.
- **HeadSpin mobile:** HSAppium remote sessions. Configure `HEADSPIN_API_TOKEN` and `HEADSPIN_API_BASE_URL` for automatic device discovery using the documented automation-config endpoint, or set `HEADSPIN_APPIUM_URL` to a specific per-device proxy URL.
- **Local web:** Python Playwright (Chromium, Firefox, WebKit). Install browser binaries with `playwright install chromium firefox webkit` as needed.
- **Sauce Labs web:** Python Selenium Remote WebDriver through `SAUCE_WEBDRIVER_URL` or credentials/region. Sauce-managed Playwright cloud runs are a separate `saucectl` workflow (official Sauce Labs Playwright cloud support is JavaScript/TypeScript); this Python agent does not claim to run saucectl.
- **HeadSpin web:** Selenium Remote WebDriver through the account-assigned `HEADSPIN_WEBDRIVER_URL`. HeadSpin browser-cloud access and features depend on account entitlements.

### Configure HeadSpin

Set these on the machine/container running the agent (and on the API service if you want provider status displayed):

```env
HEADSPIN_APPIUM_URL=https://<account-assigned-hsappium-proxy>/wd/hub
HEADSPIN_WEBDRIVER_URL=https://<account-assigned-selenium-endpoint>
HEADSPIN_API_TOKEN=<optional-account-api-token>
HEADSPIN_API_BASE_URL=https://api.headspin.io
```

The Appium proxy URL contains an account-issued token. Treat it as a secret. Do not commit it to source control or expose it to the browser. For automatic mobile device discovery, set `HEADSPIN_API_TOKEN` and the API base URL; AutoPilotQE calls the documented automation-config endpoint. The agent fetches the selected device driver URL directly using the token. For HeadSpin web sessions, register a browser profile and run `web-worker --provider headspin` with the assigned WebDriver URL. See the [HeadSpin Appium API guide](https://info.headspin.io/hubfs/Getting%20started/HeadSpin-Appium-Getting-Started.pdf).

### Configure Sauce Labs

```env
SAUCE_USERNAME=<username>
SAUCE_ACCESS_KEY=<access-key>
SAUCE_REGION=us-west-1
# Optional explicit WebDriver endpoint including auth, stored only in the agent environment
SAUCE_WEBDRIVER_URL=
```

Sauce Appium endpoint is `https://ondemand.<region>.saucelabs.com/wd/hub`. The web Selenium endpoint is generated from the credentials/region unless `SAUCE_WEBDRIVER_URL` is supplied.

### Web worker

Local web worker in Docker (Chromium):

```bash
docker compose --profile workers up --build -d web-worker
```

Configure `WEB_WORKER_DEVICE_ID`, `WEB_WORKER_PROVIDER`, `WEB_WORKER_BROWSER`, and `WEB_WORKER_REMOTE_URL` in `.env` for a cloud worker. For local host execution instead:

```bash
pip install -r agent/requirements.txt
playwright install chromium
autopilotqe-agent web-worker --device-id local-chromium --provider local --browser chromium --api-url http://localhost:8000
```

Web test steps support `navigate`, `click`, `fill`/`input`, `select`, `check`, `submit`, `hover`, `press`, `scroll`, `assert_visible`, `assert_text`, `assert_url`, `assert_title`, `reload`, `back`, `wait`, and `screenshot`. Locators can use test IDs, roles/names, labels, placeholders, CSS or XPath. Test-data placeholders and `${SECRET:NAME}` environment references are resolved by the worker.

### Important scope notes

- Provider status only reports whether required configuration is present; it does not prove credentials or account entitlements are valid.
- HeadSpin mobile device discovery uses its documented automation-config API. App upload, device lock/unlock operations outside HSAppium, and detailed HeadSpin performance artifact ingestion are not yet implemented. The Appium and Selenium session adapters accept the endpoints supplied by HeadSpin.
- Cloud device/browser execution requires a worker with network access to the provider and a valid account.
- Real device recording, provider session creation, app upload, video/log retrieval, and cloud account verification still need integration tests against your actual Sauce Labs and HeadSpin tenants.


## Universal Test Recorder (v0.4)

The Universal Recorder provides one test lifecycle for native Android/iOS and web applications. It creates a recording session, stores normalized interaction steps, saves the journey as a reusable test case, queues execution against a compatible registered device/browser, and exports editable Python scripts.

### Web recording with the Chrome extension

1. Start the stack and create a **Universal Recorder → Web application** session.
2. Load the unpacked extension from `browser-extension/` in Chrome/Chromium (`chrome://extensions` → Developer mode → Load unpacked).
3. In the extension popup, enter the API base URL, API key when enabled, and active recording session ID.
4. Enable recording on the target website and grant access to that site origin.
5. Interact with the page. Navigation, clicks, form changes, selects, checkboxes, submit events, scrolls and selected keyboard actions are normalized into test steps.
6. Stop and save the recording in AutoPilotQE. Review/update the captured test-data JSON before execution.

The extension requests site permission per origin when recording is enabled. It does not capture literal form values: ordinary fields are represented as `${VARIABLE}` and likely sensitive fields as `${SECRET:VARIABLE}`. Supply ordinary variables in the test-data editor and secrets through `AUTOPILOTQE_SECRET_VARIABLE` environment variables on the execution worker.

### Native mobile recording

Choose Android or iOS and a registered device in Universal Recorder, start the session, then use **Open Live Device Bridge**. The app transfers the selected device and recording session to the bridge screen. Start the host-side `autopilotqe-agent bridge` command shown there. iOS Appium/XCUITest requires macOS and Xcode.

### Execute a saved universal test

After saving, choose a compatible execution target and select **Execute recorded test**. Start the matching worker on a host with the required browser/device access. For web, for example:

```bash
cd agent
python -m pip install -r requirements.txt
playwright install chromium
python -m pip install -e .
autopilotqe-agent web-worker --device-id browser-local-chromium --provider local --browser chromium --api-url http://localhost:8000
```

For remote web execution, use the registered browser profile ID and provider `sauce` or `headspin`; configure the corresponding `SAUCE_WEBDRIVER_URL` / Sauce credentials or `HEADSPIN_WEBDRIVER_URL` on the worker. For native tests, run a device-bound `autopilotqe-agent worker` on the host with Appium and the device connected. The API rejects execution if the test platform and registered target platform do not match.

### Generate editable automation scripts

The Universal Recorder offers script generation and download after a test is saved:

- **Web:** Python Playwright or Python Selenium.
- **Native Android/iOS:** Python Appium.

API: `GET /api/v1/tests/{test_id}/export?target=playwright|selenium|appium` returns `{filename, language, target, content}`. Generated scripts are starting points: review selectors, app capabilities, environment variables and cloud provider endpoint before running them.

Update recorded test data with `PATCH /api/v1/tests/{test_id}/test-data` and body `{"test_data": {"EMAIL": "qa@example.com"}}`.

### Recorder scope and limitations

- The web recorder companion currently targets Chrome/Chromium (Manifest V3). Web test replay supports local Playwright Chromium/Firefox/WebKit and configured Selenium remote browsers.
- Browser extension recording is performed in the local browser; the resulting saved test can then be executed on a compatible Sauce Labs or HeadSpin remote browser worker.
- Native capture uses the AutoPilotQE Appium bridge, not system-wide hidden touch interception.
- Generated scripts are editable exports, not a guarantee that every application-specific workflow is executable without reviewing selectors and capabilities.
- Docker image builds and live cloud sessions must be validated on the deployment host with actual provider credentials.

## Applitools Eyes visual testing (v0.5)

AutoPilotQE includes a Visual Testing workspace for defining named visual checkpoints on saved test cases. Each checkpoint is scheduled **before the first functional action** (`after_step: 0`) or **after a selected recorded step**. The execution worker submits checkpoints to Applitools Eyes while the browser/Appium session is still open.

### Configure Applitools

Add these values to `.env` (never commit the API key):

```env
APPLITOOLS_API_KEY=your-eyes-api-key
APPLITOOLS_SERVER_URL=https://eyes.applitools.com
APPLITOOLS_APP_NAME=AutoPilotQE
```

Rebuild the worker/API containers after changing environment variables:

```bash
docker compose up --build -d
```

The agent image installs the optional Eyes Python SDKs from `agent/requirements-visual.txt`. For a host-installed agent, install them with:

```bash
pip install -r agent/requirements.txt -r agent/requirements-visual.txt
export APPLITOOLS_API_KEY=your-eyes-api-key
export APPLITOOLS_SERVER_URL=https://eyes.applitools.com
export APPLITOOLS_APP_NAME="AutoPilotQE"
```

On Windows PowerShell, use `$env:APPLITOOLS_API_KEY="..."` and set the other variables the same way. The local device worker must inherit these variables when it is launched.

The API exposes `/api/v1/visual/status` (credential-safe status only), and the UI exposes **Visual Testing** and **Integrations → Applitools Eyes**.

### Configure a checkpoint

1. Save a functional web, Android or iOS test case.
2. Open **Visual Testing** and select that test.
3. Give the checkpoint a meaningful name, such as `Checkout – order summary`.
4. Choose full page/screen, viewport, or a specific element.
5. Select the step after which the screen should be validated.
6. Choose a match level and define dynamic, ignore and sensitive-data selectors.
7. Save the checkpoint and execute the original test on the desired browser/device.

### Match and region strategies

- **Dynamic**: preferred default for content that changes naturally (dates, IDs, counters, prices). Eyes Visual AI can tolerate expected dynamic text while identifying meaningful visual regressions.
- **Strict**: use for brand-critical or fixed UI where text, color, size and placement matter.
- **Layout**: validate structure and placement while tolerating content changes.
- **Ignore Colors**: tolerate color-only changes while checking other visual differences.
- **Layout-only selectors**: preserve the region's geometry while normalizing its changing text for this worker's capture.
- **Ignore selectors**: exclude an irrelevant region such as a third-party ad or live media.
- **Mask selectors**: hide private or sensitive values before capture while preserving the element's layout. This is not a replacement for avoiding sensitive data in test fixtures and logs.
- **Wait-for selector**: wait for a screen/component to be visible before taking the checkpoint.
- **Stability options**: disable CSS animations/transitions and hide the blinking caret before browser captures.

Prefer `Dynamic` or `Layout` for changing business data instead of ignoring a large part of the screen. For example, validate the dashboard's layout with `Layout`, then add separate functional assertions for the exact account balance or order total. Mask PII, passwords and personal identifiers; do not treat changing business values as automatically correct merely because they are dynamic. CSS ignore/layout/mask selectors are designed for web DOMs; for native mobile checkpoints use Appium accessibility-ID element checkpoints and screen-level match levels.

### Baselines and review

The first Eyes run establishes a baseline for the relevant application/test/environment. Subsequent runs compare against it. Review visual differences and approve/reject baseline changes in the Applitools Eyes Test Manager; AutoPilotQE does not silently approve new baselines. Browser/device/OS/viewport differences can result in separate Eyes environments/baselines.

### Script export

The Visual Testing workspace can generate Python examples for:

- `eyes-playwright` with Playwright Python
- `eyes-selenium` with Selenium Python
- `eyes-selenium` with Appium Python

The Playwright export includes the saved functional steps and checkpoint positions. Selenium/Appium exports provide a visual-check helper to call immediately after the corresponding functional step in your existing test script. Set `APPLITOOLS_API_KEY` in the script's execution environment.

### API endpoints

- `GET /api/v1/visual/status`
- `GET /api/v1/tests/{test_id}/visual-checkpoints`
- `POST /api/v1/tests/{test_id}/visual-checkpoints`
- `PATCH /api/v1/visual-checkpoints/{checkpoint_id}`
- `DELETE /api/v1/visual-checkpoints/{checkpoint_id}`
- `GET /api/v1/tests/{test_id}/visual-script?target=playwright|selenium|appium`

The `0002_visual_checkpoints` Alembic migration creates the checkpoint configuration table. Run `alembic upgrade head` before starting the API in production.


## v0.6.0 — failure analysis and cross-platform scenarios

### Failure analysis

Mobile Appium and web executions now attach a deterministic triage report to failed runs. It classifies common failures (locator/UI change, assertion mismatch, synchronization timeout, visual regression, connectivity/service, app launch/configuration, or unclassified), lists possible causes and recommended next checks, and explicitly marks the root cause as unconfirmed. Where the driver allows it, the agent also saves a screenshot and a bounded UI/page-source excerpt; Android logcat is collected opportunistically. Evidence paths are local to the agent host unless you mount/share the artifacts directory with your API or CI system.

The Executions view surfaces the failure category, summary, possible causes and suggested actions. This is diagnostic assistance, not an AI claim that the root cause has been proven.

### Cross-platform Scenario Studio

Use **Scenario Studio** to save a reusable scenario as a normal test case with `platform: cross_platform`. The scenario definition is stored in the same persistent test-case library, can be edited as JSON, and is available in Test Cases and execution history. Cross-platform scenarios are queued to an Android/iOS Appium device for the mobile verification leg.

#### PlayStation example: game launched on PS5 → currently playing shown in PlayStation App

1. Sign in to the same PSN account on the PS5 and the PlayStation App.
2. Make sure PSN privacy/activity settings allow the current game to be visible.
3. Launch the game on the PS5, either directly on the console or using Sony's PS Remote Play app.
4. Connect an Android/iOS device with the PlayStation App installed to AutoPilotQE through Appium.
5. In Scenario Studio, choose the connected device, confirm the PlayStation App package/bundle ID, enter the game title, save, and run the scenario. The generated steps launch the PlayStation App, wait for the game title to appear, and assert the title/playing text in the app's accessible UI hierarchy.

For Android, the PlayStation App package is `com.scee.psxandroid` (the Google Play listing identifies this package). Confirm the installed version and package on the test device. For iOS, supply the bundle identifier discovered for the installed app; do not reuse the Android package ID. The app may change its accessible labels between releases/locales, so inspect the UI hierarchy and tune the assertions for your target build.

**Automation boundary:** Sony officially documents PS Remote Play as a way to control a PS4/PS5 from supported PC, Mac and mobile devices. This project does not claim a supported public API for programmatically driving the proprietary PS5 dashboard or the PlayStation App's private presence service. The PS5 game launch is therefore a console/Remote Play precondition in this initial integration; AutoPilotQE automates and verifies the PlayStation App leg through Appium. This still tests the cross-surface outcome (game active on console, corresponding activity visible in the companion app) without storing PSN passwords or reverse-engineering private endpoints.

Official setup references: [PS Remote Play](https://remoteplay.dl.playstation.net/remoteplay/lang/en/) and [PlayStation App on Google Play](https://play.google.com/store/apps/details?id=com.scee.psxandroid).

### Building more saved scenarios

Create one scenario per project or journey (for example, game activity, notification delivery, account/profile sync, purchase receipt visibility, or device-to-companion-app state). Keep each scenario's prerequisites, test data, ordered steps, app ID and device platform explicit. Use `${GAME_TITLE}`-style placeholders for variable test data and `${SECRET:KEY}` for secrets supplied only through the agent environment. Avoid storing PSN passwords, refresh tokens or session cookies in test data.

Supported native actions now include `wait_for_text` and `assert_any_text` in addition to existing launch, tap, input, swipe, wait and text assertion actions. `wait_for_text` supports a bounded timeout (up to 60 seconds); `assert_any_text` accepts `expected.texts`.

## PS5 DevKit + Target Manager integration (v0.7 architecture)

AutoPilotQE can coordinate a PS5 DevKit and the PlayStation App on Android or iOS in one saved cross-platform scenario. The console adapter is a thin host-side wrapper around the **user-installed Sony Prospero Target Manager CLI** (`prospero-ctrl.exe`); AutoPilotQE does not reimplement Sony protocols or bundle Sony SDK binaries.

### Host requirements

- Authorised PlayStation developer/partner access and a PS5 DevKit/TestKit.
- Windows host with the PlayStation SDK and Target Manager Server installed.
- DevKit connected to the same wired LAN as the Windows host and configured according to the approved Sony development workflow.
- Appium server plus Android `adb` or an iOS/Xcode-connected real device (iOS automation requires macOS/Xcode; the PS5 Target Manager host remains Windows, so use a second Mac/Appium worker for iOS if needed).

Set these variables on the Windows host running the PS5 bridge (and Android Appium worker, if Android is tested there):

```powershell
$env:PS5_PROSPERO_CTRL = 'C:\Program Files (x86)\SCE\Prospero\Tools\Target Manager Server\bin\prospero-ctrl.exe'
$env:PS5_TARGET = '192.168.1.100'
```

The executable path is configurable because SDK installation locations vary. Do not copy Sony SDK binaries into this repository or Docker images. For iOS, run Appium on a separate macOS/Xcode host and configure that worker with `PS5_BRIDGE_URL=http://<windows-host>:8787` and the same `PS5_BRIDGE_TOKEN`; the Mac worker will send the approved PS5 operations to the Windows Target Manager bridge.

### Target Manager smoke checks

```powershell
autopilotqe-agent ps5 discover
autopilotqe-agent ps5 list
autopilotqe-agent ps5 connect --target 192.168.1.100
autopilotqe-agent ps5 info --target 192.168.1.100
autopilotqe-agent ps5 health --target 192.168.1.100
autopilotqe-agent ps5 launch --target 192.168.1.100 --title-id PPSA00000
autopilotqe-agent ps5 screenshot --target 192.168.1.100 --output .\artifacts\ps5-game.png --mode GAME

# On Windows: start the token-protected bridge for the remote iOS worker
$env:PS5_BRIDGE_TOKEN = '<generate-a-random-secret-at-least-24-characters>'
autopilotqe-agent ps5-bridge --host 0.0.0.0 --port 8787
```

On the Mac iOS Appium worker, set `PS5_BRIDGE_URL` and `PS5_BRIDGE_TOKEN` to reach the Windows bridge. Restrict port 8787 to the trusted QA network/firewall. For screenshots to be available in central reports, configure a shared artifact folder or copy the bridge host's output into the AutoPilotQE artifact store.

The command adapter uses an allow-list of read/launch/screenshot operations. It does not expose arbitrary shell execution, firmware update, factory reset, or destructive power commands.

### Cross-surface scenario actions

A saved mobile scenario can include `ps5_connect`, `ps5_health`, `ps5_launch`, and `ps5_screenshot` before normal Appium actions (`launch`, `tap`, `wait_for_text`, `assert_text`, etc.). Example:

```json
[
  {"action":"ps5_connect","target":{"target_ip":"${PS5_TARGET_IP}"}},
  {"action":"ps5_launch","value":"${PS5_TITLE_ID}","target":{"target_ip":"${PS5_TARGET_IP}","title_id":"${PS5_TITLE_ID}"},"timeout":90},
  {"action":"wait","value":"8"},
  {"action":"ps5_screenshot","target":{"target_ip":"${PS5_TARGET_IP}","mode":"GAME"}},
  {"action":"launch","metadata":{"app_id":"${PS_APP_ID}"}},
  {"action":"wait_for_text","value":"${GAME_TITLE}","expected":{"text":"${GAME_TITLE}"},"timeout":60},
  {"action":"assert_any_text","expected":{"texts":["Playing","Now playing"]}}
]
```

Use the actual PS5 Title ID for the installed game. The iOS PlayStation App bundle ID must be supplied for the installed build; AutoPilotQE intentionally does not guess it. Add app-specific navigation taps/locators after inspecting the PlayStation App with Appium Inspector on each platform. The Android and iOS UI hierarchies may differ.

### Platform topology

The PS5 Target Manager Server workflow is Windows-hosted. Android Appium can run on that Windows host. Real-device iOS Appium requires macOS/Xcode, so use a Windows PS5 bridge host plus a separate Mac iOS Appium host connected to the same AutoPilotQE API. The Mac worker can call the token-protected Windows bridge through `PS5_BRIDGE_URL`; the bridge exposes only discover/list/connect/info/health, application start and screenshot operations. It rejects arbitrary commands and requires a 24-character minimum shared token. For screenshots to appear in central reports, configure a shared artifact folder or copy the bridge host's output into the AutoPilotQE artifact store.

### Evidence and limitations

Console launch output and screenshot paths are included in step results; Appium contributes mobile UI evidence and assertions. Presence may be delayed or hidden by PSN privacy/account settings. This is a DevKit workflow, not a retail-console automation interface. Confirm the exact `prospero-ctrl` command behavior against the Target Manager version installed with your licensed SDK.

## v0.8.0 — AI Self-Healing & Build Intelligence

AutoPilotQE now includes conservative runtime locator recovery and build-scoped test versioning.

### Self-healing behaviour

- Enable self-healing explicitly on a worker with `--self-heal` (disabled by default).
- Appium workers inspect the current UI XML/accessibility hierarchy; web workers inspect a bounded inventory of visible actionable DOM elements.
- Candidate matching uses deterministic evidence such as exact accessible text/label, role, content description, placeholder, test ID, element type and resource-ID similarity.
- A candidate is retried only when its confidence is at least 0.93 and it is clearly separated from the next candidate. Ambiguous candidates are not used.
- The original test definition and expected assertions are never changed at runtime. A successful runtime repair is included in the execution result as a `healing_event`.
- The API persists healing events as pending proposals. Reviewers can reject them or accept them into a new draft version. A draft must be separately approved before it is used as the active definition.
- The runtime matcher is deterministic and does not call an external LLM. Confidence values are heuristic evidence scores, not statistically calibrated probabilities. Keep healing disabled for high-risk actions unless your QA policy explicitly permits controlled retries.

### Build-aware versions

- Register Android, iOS, web or PS5 builds through `POST /api/v1/builds`.
- Supply a verified SHA-256 artifact digest as `fingerprint` when available. If omitted, AutoPilotQE creates an identity fingerprint from project, app ID, platform, version, build number and metadata; this is **not** a binary checksum.
- Each new test case receives an immutable approved v1 snapshot. Later edits are created as draft versions and require explicit approval.
- A version may be global (`build_id` omitted) or scoped to one registered build (`build_id` set). Executions select the latest approved version scoped to the chosen build, falling back to the global approved version.
- Approving a build-scoped version does not overwrite the global baseline or versions for other builds.
- Rollback creates a new approved version copied from the selected historical version; it does not delete or rewrite history.
- Build impact is available from `GET /api/v1/builds/{build_id}/impact`.

### Worker commands

```bash
# Appium worker: opt in to high-confidence locator recovery
autopilotqe-agent worker --platform android --device-id <udid> --self-heal

# Local Playwright / Selenium web worker
autopilotqe-agent web-worker --device-id <browser-id> --provider local --browser chromium --self-heal
```

The worker still needs to be configured with the correct API URL, API key and Appium/browser provider settings. A worker without `--self-heal` retains the previous strict locator behaviour. For the Docker web worker, set `WEB_WORKER_SELF_HEAL=true` in `.env` to opt in.

### Build Intelligence UI

Open **Build Intelligence** to:

1. Register application builds and inspect the build inventory.
2. View test impact for a selected build.
3. Review healing proposals with original/candidate locators, confidence and evidence.
4. Accept a proposal into a build-scoped draft or reject it.
5. Approve draft versions or create a rollback version.
6. Queue a selected test against a registered build and compatible device.

### API endpoints

- `POST /api/v1/builds`, `GET /api/v1/builds`
- `GET /api/v1/builds/{build_id}/impact`
- `GET /api/v1/tests/{test_id}/versions`, `POST /api/v1/tests/{test_id}/versions`
- `POST /api/v1/versions/{version_id}/approve`
- `POST /api/v1/tests/{test_id}/rollback/{version_id}`
- `GET /api/v1/healing-proposals`
- `POST /api/v1/healing-proposals/{proposal_id}/accept`
- `POST /api/v1/healing-proposals/{proposal_id}/reject`
- Queue execution with optional `build_id` and `test_case_version_id` in `POST /api/v1/tests/{test_id}/execute`.
- Export the correct approved build-scoped script with `GET /api/v1/tests/{test_id}/export?target=appium&build_id=<build-id>` (or use `test_case_version_id` explicitly).

### Production deployment and security notes

- Apply the Alembic migration through `0004_build_aware_self_healing` before deploying the v0.8 API. The Docker API entrypoint runs `alembic upgrade head` before starting Uvicorn. For an existing local installation, run `cd backend && alembic upgrade head`.
- Production mode requires PostgreSQL, `AUTO_CREATE_SCHEMA=false`, and an `API_KEY` of at least 32 characters. In Docker Compose, the frontend uses a same-origin Nginx `/api/` reverse proxy and injects the API key server-side at runtime; the key is not passed as a Vite build argument or embedded in browser JavaScript. WebSocket upgrades use the same trusted proxy header. Keep the API port bound to localhost/private network and protect the frontend origin with TLS at an external reverse proxy.
- For local Vite development only, configure `VITE_API_URL` (and optionally `VITE_API_KEY`) in `frontend/.env.local`. Never set `VITE_API_KEY` in a production build; `VITE_` variables are public client-side values.
- The current reviewer field is an audit label, not an identity assertion. For multi-user production approval, place the API behind your organisation's SSO/RBAC gateway and pass authenticated reviewer identity from that trusted layer. Do not treat a shared API key as per-user approval authority.
- Build metadata and healing evidence are bounded; avoid sending secrets, customer data or personal data in locator metadata or screenshots. Configure artifact retention and access controls for your environment.
- Self-healing is deliberately conservative and opt-in. It is not a guarantee that arbitrary UI changes can be inferred. Preserve explicit assertions and validate replacements in CI before promoting them.

## v0.8.0 validation

- Backend API tests: 29 passed.
- Backend API tests: 31 passed.
- Agent tests: 14 passed.
- Python compile checks: passed.
- Fresh SQLite Alembic migration through `0004_build_aware_self_healing`: passed; upgrade from a v0.7 schema with an existing test row preserved that row and added the new foreign keys.
- Frontend TSX transpile/syntax checks: passed for App, Build Intelligence, Scenario Studio, Visual Testing and API client.
- Docker Compose YAML and the expanded Nginx reverse-proxy template syntax: passed.
- Full npm production build and Docker image build were not run in this environment; actual device/browser self-healing requires connected target hardware and a configured worker.

## v0.9.0 — Identity, role-based access and QE analytics

### Authentication and roles

AutoPilotQE now includes email/password signup and login, opaque revocable bearer sessions, PBKDF2-SHA256 password hashing, session expiry, logout, one-time WebSocket tickets, administrator provisioning, account deactivation, password reset, and audit events.

Roles:

- **Admin:** workspace-wide access, user and role administration, account activation/deactivation, password reset and audit history.
- **Developer:** create and maintain test cases, register builds, manage visual checkpoints and review implementation evidence; cannot approve QE release/healing changes.
- **Tester:** record scenarios, manage test data, execute tests and inspect results; cannot manage users, builds or approve healing changes.
- **QE Lead:** team quality analytics, build-to-build result/failure comparisons, build registration, test version review and healing approval; cannot administer user accounts.

Admin accounts are not self-selectable during signup. The first configured administrator is provisioned from `BOOTSTRAP_ADMIN_EMAIL` and `BOOTSTRAP_ADMIN_PASSWORD` at API startup. Developer and QE Lead signup require role-specific invitation codes configured in `ROLE_INVITE_CODES` (JSON). Tester signup is available by default and is rate-limited at the Nginx edge.

### Production environment

Set the following in `.env` before starting the production Compose stack:

```env
ENVIRONMENT=production
AUTH_REQUIRED=true
API_KEY=<at-least-32-random-characters-for-agent-service-auth>
SESSION_SECRET=<different-random-secret-of-at-least-32-characters>
BOOTSTRAP_ADMIN_EMAIL=admin@your-company.example
BOOTSTRAP_ADMIN_PASSWORD=<unique-password-of-at-least-14-characters>
BOOTSTRAP_ADMIN_NAME=Platform Administrator
SESSION_TTL_HOURS=8
ROLE_INVITE_CODES={"developer":"<long-random-developer-invite>","qe_lead":"<long-random-qe-lead-invite>"}
```

Use HTTPS at the ingress/reverse proxy, keep the API and database on a private network, rotate the service API key and session secret deliberately, and do not expose secrets in frontend build arguments. The browser uses a short-lived bearer session stored in `sessionStorage`; its WebSocket bridge obtains a single-use ticket (60-second expiry) instead of putting the long-lived session token in a URL. Device agents continue to use the server-side service API key. The web proxy no longer injects the service key into browser requests.

Production startup requires PostgreSQL, explicit Alembic migrations (`0005_auth_quality_analytics`), `AUTO_CREATE_SCHEMA=false`, auth enabled, a session secret and bootstrap administrator credentials. The API startup command runs `alembic upgrade head` before starting Uvicorn. The bootstrap admin is created only if the configured email does not already exist; changing the environment password does not silently reset an existing account. Use the Admin > User Management password-reset action for an intentional reset.

Developer/QE Lead invitation codes are shared secrets; distribute them out-of-band and rotate them after use. For public internet deployments, put signup behind company SSO or an email-verification/invitation workflow before broad rollout. Password reset currently requires an administrator; self-service email reset is not enabled.

### QE Lead analytics

The **QE Analytics** workspace is visible to Admin and QE Lead roles. It includes configurable 7/30/90/180/365-day execution trends, pass/failure rates, average duration, classified failure categories and exact-build comparisons. Build comparisons require the same project and platform and only include executions tagged with the selected build IDs. The dashboard shows result deltas (passed, failed, errors, skipped, duration) and failure-category deltas. It deliberately does not infer build association for executions with missing build metadata or normalize comparisons for differing suite sizes.

API endpoints:

- `POST /api/v1/auth/signup`, `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`, `POST /api/v1/auth/logout`, `POST /api/v1/auth/ws-ticket`
- `GET /api/v1/auth/users`, `PATCH /api/v1/auth/users/{user_id}`
- `POST /api/v1/auth/users/{user_id}/password-reset`, `GET /api/v1/auth/audit-events`
- `GET /api/v1/analytics/summary?days=30&project=...`
- `GET /api/v1/analytics/compare?build_a=...&build_b=...`

### Security boundaries

API-key-authenticated agents are treated as service principals but are restricted to device registration, recording ingestion, test retrieval, execution claim/completion and the agent WebSocket. The key cannot access user administration, analytics, build administration or approval endpoints; issue it only to trusted workers. Human browser sessions are checked against the current database user status and role on each request, so deactivation and role changes take effect without waiting for token expiry. Role authorization is enforced by the API, not only by hiding UI navigation. Password hashes and session token hashes are never returned to the client.


QMetry API references used by the connector:
- QMetry Enterprise Open API authentication and test-case endpoints: https://qmetrysupport.atlassian.net/wiki/spaces/QPro/pages/796393573/API+for+Test+Cases
- QMetry Enterprise Automation API JUnit result import: https://qmetrysupport.atlassian.net/wiki/spaces/QTMS8191/pages/4241111990
- QTM4J Open API authentication: https://qmetrysupport.atlassian.net/wiki/spaces/QTM4JD480/pages/3617159634/QMetry+Open+API+4.8.0
- QTM4J automation result import endpoint is version-specific; validate the endpoint against the installed QTM4J edition before production enablement.


## v1.1.0 role-aware UI refresh

The refreshed UI groups tools by workflow and presents persona-specific quick actions. Supported workspace roles are Admin, Developer, Tester, QE Lead and Product Owner. Product Owner is a read-only role for overview, test-case library, execution history and QE analytics; write requests are rejected by the API. Configure `product_owner` in `ROLE_INVITE_CODES` to enable invitation-based signup.

The UI refresh includes responsive navigation, improved typography and spacing, clearer data tables, accessible keyboard focus, and updated form and status treatments.


### Role experience and permissions (v1.1)

- **Developer:** recording, scenario authoring, device lab, visual checks and build-specific test maintenance.
- **Tester:** test library, recording, device execution, visual testing and execution history.
- **QE Lead:** execution and failure analytics, build comparisons, build intelligence, QMetry sync oversight and healing approvals.
- **Product Owner:** read-only product quality overview, test library, execution outcomes and QE analytics/build comparisons. Product Owner access is invitation-gated through `ROLE_INVITE_CODES` and enforced as read-only in API middleware.
- **Admin:** workspace-wide configuration, user and role administration, integrations and audit history.

The v1.1 UI refresh groups navigation by workflow, adds role-aware dashboard shortcuts, improves responsive layouts, form controls, data tables, status indicators and keyboard focus visibility.
