# Changelog

## 1.2.0 – Unified project collaboration workspace
- Added project-scoped workspace with stable project keys, descriptions, products, owner and active/archive status.
- Added project membership and visibility scoping for Developer, Tester and Product Owner users. QE Leads and admins can oversee all projects; project owners can manage their team. Existing free-text test/build project groupings are migrated into project records and linked to their historical assets.
- Added requirements with acceptance criteria, priority, status, external references and links to test cases.
- Added defect tracking with severity, priority, status, platform and optional test case, build and execution links.
- Added auditable release decisions (GO / conditional / NO-GO) with an immutable execution/defect metrics snapshot. Plain GO is blocked by open critical/blocker defects unless an explicitly justified QE Lead/Admin override is supplied.
- Added project-level traceability and dashboard summary for requirements, test coverage, builds, recent executions, pass rate and open defects. Added project-aware linking for existing unassigned test cases and builds.
- Added UI navigation and role-aware workflows for Product Owners, Developers, Testers, QE Leads and Admins.
- Added API validation to prevent silently moving test cases/builds between projects and prevent cross-project defect references.
- Added Alembic migration `0007_project_collaboration` and API coverage for project access, requirements, defects, release gates and Product Owner permissions.

## 1.2.0 validation
- Backend API tests: 49 passed.
- Agent tests: 14 passed.
- Fresh Alembic upgrade through `0007_project_collaboration`: passed.
- Frontend TSX transpile/syntax checks for App and ProjectWorkspace: passed.
- Full npm production build and Docker image build: not run in this environment.

## 1.1.0 – Role-aware product experience
- Refreshed the workspace UI with clearer hierarchy, responsive navigation, accessible focus states, improved tables, forms, cards and dashboard spacing.
- Grouped navigation into Workspace, Author & Automate, Device & Visual Lab, Quality & Release, and Administration.
- Added persona-specific dashboard actions for Developers, QE Leads, Testers and Product Owners.
- Added a Product Owner read-only role for release visibility, test library browsing, execution history and QE analytics.
- Added Product Owner invitation-code signup and administrator role assignment.
- Enforced read-only Product Owner access at the API middleware layer, not just in the UI.

# Changelog

## 0.4.0 – Universal Recorder

- Added Chrome/Chromium Manifest V3 recorder companion with per-site permission requests.
- Captures navigation, click, form change, select, checkbox, submit, scroll and selected key actions.
- Uses stable test-id, role/name, label, placeholder and CSS locator metadata.
- Replaces typed field values with test-data placeholders; likely sensitive fields use secret placeholders.
- Added live recording detail API and timeline polling in the Universal Recorder UI.
- Added platform inference when a recording is saved as a test case.
- Added test-data update endpoint so captured variables can be reviewed before execution.
- Added script export API for Python Playwright, Selenium and Appium.
- Added universal execution target selection and worker launch commands.
- Added platform compatibility validation for queued executions.
- Extended web replay actions for submit, hover, press, scroll, visibility/title assertions, reload and back.
- Added API tests for script generation, test-data updates, live timelines and platform checks.

## Validation

- Backend API tests: 19 passed.
- Python compileall: passed.
- Agent tests: 7 passed.
- Chrome extension JavaScript syntax: passed.
- Extension manifest JSON: valid.
- Frontend TSX transpile/syntax diagnostics: 0.
- Docker Compose YAML: valid.
- Full npm dependency install/frontend production build and Docker image build were not run in this environment.

## 0.5.0 – Applitools Visual Testing
- Added persisted visual checkpoint definitions associated with test cases.
- Added before-step/after-step checkpoint scheduling, full-page/viewport/element scopes, match levels, ignore/layout/mask selectors, readiness selectors and screenshot stabilization options.
- Added Applitools Eyes credential-safe configuration/status and Docker environment wiring.
- Added optional Eyes Playwright/Selenium SDKs to the agent image and checkpoint execution for Playwright, Selenium and Appium workers.
- Added a Visual Testing workspace and Python script exports.
- Added Alembic migration `0002_visual_checkpoints`.
- Pinned optional Applitools Python SDKs for reproducible worker builds (`eyes-playwright` 6.5.20 and `eyes-selenium` 6.4.42).


## 0.6.0 — Failure intelligence and cross-platform scenario support

- Added Scenario Studio for authoring, saving and running reusable cross-platform scenarios against Android/iOS Appium devices.
- Added a PlayStation example that validates a PS5-launched game's current-activity title in the PlayStation App. Console launch is an explicit PS Remote Play/console precondition; PS App verification is automated with Appium.
- Added `wait_for_text` and `assert_any_text` mobile actions for asynchronous activity/presence checks.
- Added failure triage categories, likely causes, suggested actions, screenshot/UI evidence and opportunistic Android logcat capture for mobile failures.
- Added browser failure analysis with screenshot and page-source evidence.
- Added PlayStation App integration status and surfaced failure analysis in execution history.

## 0.7.0 - PS5 DevKit Target Manager integration
- Added a host-side adapter for the installed Sony Prospero Target Manager CLI: discover/list/connect/info/health, launch by Title ID, and GAME/SYSTEM screenshots.
- Added cross-platform replay actions `ps5_connect`, `ps5_health`, `ps5_launch`, and `ps5_screenshot` that can precede Android/iOS Appium steps.
- Added a token-protected Windows PS5 bridge for macOS iOS Appium workers, with an explicit command allow-list and no arbitrary shell execution.
- Updated Scenario Studio with DevKit IP, game Title ID, Android/iOS app identifier and a PS5-to-PlayStation-App sample journey.
- Documented Windows Target Manager + Android Appium and Windows bridge + macOS/Xcode iOS Appium topologies, including evidence-sharing caveats.
- Sony SDK binaries are not bundled; actual DevKit execution requires authorised SDK access and hardware.

## 0.8.0 — AI Self-Healing & Build Intelligence

- Added immutable test-case version snapshots with global and application-build-scoped approved versions.
- Added application build registry with SHA-256 fingerprinting/idempotent registration for Android, iOS, web and PS5 builds.
- Added build impact reports and build-aware execution selection; worker claims now include the exact approved test snapshot and build metadata.
- Added conservative deterministic Appium UI-hierarchy and web DOM locator candidate ranking. Recovery is opt-in, requires high confidence and an unambiguous candidate, and only retries the failed locator lookup at runtime.
- Added bounded healing-event persistence, proposal review, acceptance into draft versions, explicit approval and rollback-as-new-version.
- Added Build Intelligence UI for build registration, impact inspection, proposal review, test version approval/rollback and build-aware execution.
- Added Alembic migration `0004_build_aware_self_healing` and production deployment guidance.
- No automatic rewriting of approved test cases or expected assertions; runtime proposals always require review.


## 0.8.0 validation

- Backend API tests: 31 passed.
- Agent tests: 14 passed.
- Fresh and v0.7-to-v0.8 SQLite migrations: passed; existing test row preserved.
- Frontend TSX syntax diagnostics: 0.
- Docker Compose YAML and Nginx template syntax: passed.
- Full frontend production build, Docker image build and live hardware execution were not run in this environment.

## 0.9.0 — Authentication, RBAC and QE analytics

- Added signup/login, PBKDF2 password hashing, expiring/revocable opaque sessions, logout and one-time WebSocket tickets.
- Added Admin, Developer, Tester and QE Lead roles with server-side route authorization.
- Added environment-provisioned administrator bootstrap, invitation-code gating for elevated roles, account disable/enable, administrator password reset and authentication/admin audit events.
- Removed browser exposure of the machine API key; browser API requests use user bearer sessions while agents retain service-key authentication.
- Added Nginx rate limits for signup/login endpoints and production configuration validation for mandatory auth, session secret and bootstrap admin credentials.
- Added QE Lead analytics: execution trends, pass/failure rates, average duration, failure categories, and exact-build result/failure comparisons.
- Added migration `0005_auth_quality_analytics`.


## 0.9.0 validation

- Backend API/auth/RBAC/analytics tests: 36 passed.
- Agent tests: 14 passed.
- Fresh Alembic migration through `0005_auth_quality_analytics`: passed.
- Frontend TSX syntax diagnostics: 0 across App, Auth, QE Analytics, User Management and API client.
- Docker Compose YAML/auth wiring: passed.
- Nginx template syntax: passed with the Compose `api` upstream substituted for local syntax validation.
- Full npm dependency install timed out in this environment; full frontend type-check/production build and Docker image build were not run.


## 1.0.0 - QMetry integration
- Added optional enable/disable QMetry connector with QTM Enterprise v8.x and QTM4J result-import adapters.
- Added encrypted credential storage, test-connection action and role-gated settings.
- Added local-first SQL outbox, idempotent jobs, retry/backoff, manual backfill and job monitoring.
- Added internal test-case mappings, Enterprise test-case pull/upsert and JUnit execution-result publishing.
- Added a dedicated QMetry UI and worker service.
