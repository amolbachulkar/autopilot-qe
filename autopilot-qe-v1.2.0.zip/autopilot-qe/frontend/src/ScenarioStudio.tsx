import {useMemo,useState} from 'react';
import {api,Device} from './lib/api';

type Props={devices:Device[];onNotice:(message:string)=>void;onError:(message:string)=>void;onRefresh:()=>Promise<void>};
const playstationTemplate={
  title:'PlayStation cross-platform: game appears as currently playing',
  description:'Verify that a game launched on PS5 is reflected in the PlayStation App activity/presence UI.',
  platform:'cross_platform',
  app_id:'',
  prerequisites:'1) Install the authorised PlayStation SDK and Target Manager Server on this Windows host. 2) Connect the PS5 DevKit on the same wired LAN and ensure it is in the approved development/test mode. 3) Set PS5_PROSPERO_CTRL and PS5_TARGET on the host. 4) Sign in to the same PSN account on the DevKit and PlayStation App; enable activity visibility. 5) Connect Android/iOS via Appium. The scenario uses the DevKit Title ID to launch the game, captures a console screenshot, then verifies mobile presence.',
  test_data:{GAME_TITLE:'ASTRO BOT',PS_APP_ID:'com.scee.psxandroid',PS5_TITLE_ID:'CUSA00000',PS5_TARGET_IP:'192.168.1.100'},
  steps:[
    {action:'ps5_connect',target:{target_ip:'${PS5_TARGET_IP}'}},
    {action:'ps5_launch',value:'${PS5_TITLE_ID}',target:{target_ip:'${PS5_TARGET_IP}',title_id:'${PS5_TITLE_ID}'},timeout:90},
    {action:'wait',value:'8',target:{}},
    {action:'ps5_screenshot',target:{target_ip:'${PS5_TARGET_IP}',mode:'GAME'}},
    {action:'launch',target:{},metadata:{app_id:'${PS_APP_ID}'}},
    {action:'wait',value:'3',target:{}},
    {action:'wait_for_text',value:'${GAME_TITLE}',timeout:45,target:{},expected:{text:'${GAME_TITLE}'}},
    {action:'assert_text',value:'${GAME_TITLE}',target:{},expected:{text:'${GAME_TITLE}'}},
    {action:'assert_any_text',target:{},expected:{texts:['Playing','Now playing']}}
  ]
};
export default function ScenarioStudio({devices,onNotice,onError,onRefresh}:Props){
 const [title,setTitle]=useState(playstationTemplate.title),[project,setProject]=useState('PlayStation QA'),[platform,setPlatform]=useState<'android'|'ios'>('android'),[deviceId,setDeviceId]=useState(''),[appId,setAppId]=useState('com.scee.psxandroid'),[game,setGame]=useState('ASTRO BOT'),[titleId,setTitleId]=useState('CUSA00000'),[targetIp,setTargetIp]=useState('192.168.1.100'),[prereq,setPrereq]=useState(playstationTemplate.prerequisites),[steps,setSteps]=useState(JSON.stringify(playstationTemplate.steps,null,2)),[busy,setBusy]=useState(false),[savedId,setSavedId]=useState('');
 const targets=useMemo(()=>devices.filter(d=>d.platform===platform&&d.status==='available'),[devices,platform]);
 function loadTemplate(){setTitle(playstationTemplate.title);setProject('PlayStation QA');setPrereq(playstationTemplate.prerequisites);setAppId(platform==='android'?'com.scee.psxandroid':'');setGame('ASTRO BOT');setTitleId('CUSA00000');setTargetIp('192.168.1.100');setSteps(JSON.stringify(playstationTemplate.steps,null,2));setSavedId('')}
 async function save(){setBusy(true);try{const parsed=JSON.parse(steps);if(!Array.isArray(parsed)||!parsed.length)throw new Error('Steps must be a non-empty JSON array.');const testData={GAME_TITLE:game,PS_APP_ID:appId,PS5_TITLE_ID:titleId,PS5_TARGET_IP:targetIp};const created=await api<any>('/api/v1/tests',{method:'POST',body:JSON.stringify({title,project,description:'Reusable cross-platform scenario: PS5 game state verified in the PlayStation App.',platform:'cross_platform',app_id:appId,prerequisites:prereq,test_data:testData,steps:parsed})});setSavedId(created.id);onNotice(`Scenario saved as reusable test case ${created.id}`);await onRefresh()}catch(e){onError(e instanceof Error?e.message:String(e))}finally{setBusy(false)}}
 async function run(){if(!savedId){onError('Save the scenario before running it.');return}if(!deviceId){onError('Select the Android/iOS device running the PlayStation App.');return}setBusy(true);try{const queued=await api<any>(`/api/v1/tests/${savedId}/execute`,{method:'POST',body:JSON.stringify({device_id:deviceId,dry_run:false})});onNotice(`Cross-platform verification queued · ${queued.execution_id}. Ensure the matching Appium worker is running.`);await onRefresh()}catch(e){onError(String(e))}finally{setBusy(false)}}
 return <><div className="page-heading"><div><div className="eyebrow">MULTI-SURFACE TEST ORCHESTRATION</div><h1>Scenario Studio</h1><p>Save reusable journeys that begin on one platform and verify the resulting state on another.</p></div><span className="tag purple">CROSS-PLATFORM</span></div>
 <div className="recorder-layout"><section className="panel form-panel"><div className="panel-title"><h2>Scenario definition</h2><button className="outline" onClick={loadTemplate}>Load PlayStation example</button></div>
 <label>Project / application group<input value={project} onChange={e=>setProject(e.target.value)} placeholder="e.g. PlayStation QA, Banking App, Commerce"/></label>
 <label>Scenario name<input value={title} onChange={e=>setTitle(e.target.value)}/></label>
 <label>Verification device platform<select value={platform} onChange={e=>{const next=e.target.value as 'android'|'ios';setPlatform(next);setDeviceId('');setAppId(next==='android'?'com.scee.psxandroid':'')}}><option value="android">Android · PlayStation App</option><option value="ios">iOS · PlayStation App</option></select></label>
 <label>Appium device<select value={deviceId} onChange={e=>setDeviceId(e.target.value)}><option value="">Select connected device</option>{targets.map(d=><option key={d.id} value={d.id}>{d.name} · {d.provider}</option>)}</select></label>
 <label>PlayStation App package / bundle ID<input value={appId} onChange={e=>setAppId(e.target.value)} placeholder={platform==='android'?'com.scee.psxandroid':'Enter the installed iOS PlayStation App bundle ID'}/></label>
 <label>PS5 DevKit IP address<input value={targetIp} onChange={e=>setTargetIp(e.target.value)} placeholder="192.168.1.100"/></label>
 <label>PS5 game Title ID<input value={titleId} onChange={e=>setTitleId(e.target.value)} placeholder="CUSA / PPSA title identifier"/></label>
 <label>Expected game title<input value={game} onChange={e=>setGame(e.target.value)}/></label>
 <label>Prerequisites<textarea rows={5} value={prereq} onChange={e=>setPrereq(e.target.value)}/></label>
 <label>Scenario steps · JSON<textarea className="scenario-json" rows={18} value={steps} onChange={e=>setSteps(e.target.value)} spellCheck={false}/></label>
 <div className="button-row"><button className="primary" disabled={busy||!title.trim()} onClick={save}>Save reusable scenario</button><button className="outline" disabled={busy||!savedId||!deviceId} onClick={run}>Run verification</button></div>
 {savedId&&<small className="hint">Saved test ID: {savedId}</small>}
 </section><section className="panel"><h2>PlayStation example workflow</h2>
 <div className="step"><div className="step-num">01</div><div className="step-content"><b>Launch the game through Target Manager</b><small>On the authorised Windows SDK host, AutoPilotQE calls the installed prospero-ctrl CLI to connect to the DevKit and launch the configured Title ID. Console screenshot evidence is captured after launch.</small></div></div>
 <div className="step"><div className="step-num">02</div><div className="step-content"><b>Connect PlayStation App</b><small>Use an Android/iOS device with the PlayStation App installed and an Appium worker connected.</small></div></div>
 <div className="step"><div className="step-num">03</div><div className="step-content"><b>Verify current activity</b><small>Launch the app, wait for the game title, then assert that the expected title or playing state is visible in the accessibility/UI hierarchy.</small></div></div>
 <div className="notice-box"><b>Important connection notes</b><p>Target Manager is available only on a licensed PlayStation SDK host with authorised DevKit access. Keep the PS5 bridge on Windows; Android Appium may run there too, while iOS Appium must run on macOS/Xcode and call the Windows bridge using PS5_BRIDGE_URL plus PS5_BRIDGE_TOKEN. Provide the game's actual Title ID and DevKit IP. Use the same PSN account and activity privacy settings. Inspect each app's UI with Appium Inspector and add recorded navigation steps to the activity/profile page before the title and “Playing” assertions. The iOS bundle ID must be supplied from the installed app; it is not guessed.</p></div>
 <h3>Reusable project scenarios</h3><p className="hint">Save each project journey as a separate test case. You can clone the template and replace steps for other games, apps, account states, or cross-device workflows. All scenarios remain in Test Cases and execution history.</p>
 <pre className="command-block">{platform==='android'?`# Windows host: licensed PS5 SDK + Android Appium
$env:PS5_PROSPERO_CTRL='C:\\Program Files (x86)\\SCE\\Prospero\\Tools\\Target Manager Server\\bin\\prospero-ctrl.exe'
$env:PS5_TARGET='${targetIp}'
pip install -r agent/requirements.txt
autopilotqe-agent ps5 info --target ${targetIp}
autopilotqe-agent worker --platform android --device-id <ANDROID_UDID> --appium-url http://127.0.0.1:4723 --api-url http://<AUTOPILOTQE_API>:8000`:`# Windows PS5 bridge host
$env:PS5_PROSPERO_CTRL='C:\\Program Files (x86)\\SCE\\Prospero\\Tools\\Target Manager Server\\bin\\prospero-ctrl.exe'
$env:PS5_TARGET='${targetIp}'
$env:PS5_BRIDGE_TOKEN='<random-secret-24-chars-or-more>'
autopilotqe-agent ps5-bridge --host 0.0.0.0 --port 8787

# macOS host: iOS Appium + Xcode
export PS5_BRIDGE_URL='http://<WINDOWS_HOST_IP>:8787'
export PS5_BRIDGE_TOKEN='<same-random-secret>'
autopilotqe-agent worker --platform ios --device-id <IOS_UDID> --appium-url http://127.0.0.1:4723 --api-url http://<AUTOPILOTQE_API>:8000`}</pre>
 </section></div></>
}
