export const API_BASE = import.meta.env.VITE_API_URL || window.location.origin;
const getToken = () => sessionStorage.getItem('autopilotqe_access_token') || ''; 
export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 20_000);
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...init, signal: init?.signal || controller.signal,
      headers: { ...(init?.body ? { 'Content-Type': 'application/json' } : {}), ...(getToken() ? { 'Authorization': `Bearer ${getToken()}` } : {}), ...(init?.headers || {}) }
    });
    if (!response.ok) {
      const detail = await response.text();
      if (response.status === 401 && getToken()) {
        sessionStorage.removeItem('autopilotqe_access_token');
        window.dispatchEvent(new Event('autopilotqe:unauthorized'));
      }
      throw new Error(`${response.status}: ${detail.slice(0, 500)}`);
    }
    return response.status === 204 ? (undefined as T) : response.json();
  } finally { window.clearTimeout(timeout); }
}
export type Device = { id: string; name: string; platform: string; os_version: string; device_type: string; provider: string; status: string };
export type TestCase = { id: string; title: string; project?: string; active_version?: number; platform: string; app_id: string; steps: number; prerequisites: string };
