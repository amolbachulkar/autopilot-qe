import os
import pytest
from autopilotqe_agent.web_replay import WebReplayEngine, WebReplayError

def test_web_test_data_substitution():
    engine = WebReplayEngine()
    assert engine._resolve("Hello ${USER}", {"USER": "QA"}) == "Hello QA"

def test_web_secret_substitution(monkeypatch):
    monkeypatch.setenv("AUTOPILOTQE_SECRET_PASS", "masked-value")
    engine = WebReplayEngine()
    assert engine._resolve("${SECRET:PASS}", {}) == "masked-value"

def test_web_missing_variable_fails_closed():
    engine = WebReplayEngine()
    with pytest.raises(WebReplayError):
        engine._resolve("${MISSING}", {})

def test_web_self_healing_ranks_exact_accessible_name():
    from autopilotqe_agent.self_healing import find_safe_web_candidate
    inventory = [
        {'text': 'Sign in', 'aria_label': 'Sign in', 'role': 'button', 'id': 'signin'},
        {'text': 'Cancel', 'aria_label': 'Cancel', 'role': 'button', 'id': 'cancel'},
    ]
    candidate = find_safe_web_candidate(inventory, {'css': '#login', 'text': 'Sign in', 'role': 'button'})
    assert candidate['locator'] == {'role': 'button', 'name': 'Sign in'}
    assert candidate['confidence'] >= 0.93


def test_web_self_healing_rejects_ambiguous_candidates():
    from autopilotqe_agent.self_healing import find_safe_web_candidate
    inventory = [
        {'text': 'Continue', 'role': 'button', 'id': 'continue-a'},
        {'text': 'Continue', 'role': 'button', 'id': 'continue-b'},
    ]
    assert find_safe_web_candidate(inventory, {'text': 'Continue'}) is None
