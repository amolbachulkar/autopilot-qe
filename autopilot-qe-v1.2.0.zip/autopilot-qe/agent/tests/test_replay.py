from autopilotqe_agent.replay import ReplayEngine

def test_replay_resolves_test_data_placeholders():
    engine = ReplayEngine(driver=None, test_data={"USERNAME": "qa-user"})
    assert engine._resolve_value("Hello ${USERNAME}") == "Hello qa-user"

def test_replay_resolves_secret_from_environment(monkeypatch):
    monkeypatch.setenv("AUTOPILOTQE_SECRET_PASSWORD", "not-stored-in-test-data")
    engine = ReplayEngine(driver=None, test_data={})
    assert engine._resolve_value("${SECRET:PASSWORD}") == "not-stored-in-test-data"

def test_replay_fails_on_missing_secret_reference(monkeypatch):
    monkeypatch.delenv("AUTOPILOTQE_SECRET_PASSWORD", raising=False)
    engine = ReplayEngine(driver=None, test_data={})
    result = engine.run([{"action": "wait", "value": "${SECRET:PASSWORD}"}])
    assert result["status"] == "failed"
    assert "AUTOPILOTQE_SECRET_PASSWORD" in result["steps"][0]["error"]

def test_replay_bounds_wait_duration():
    engine = ReplayEngine(driver=None)
    result = engine.run([{"action": "wait", "value": "31"}])
    assert result["status"] == "failed"
    assert "between 0 and 30" in result["steps"][0]["error"]

def test_failure_analysis_classifies_locator_errors():
    from autopilotqe_agent.failure_analysis import analyze_failure
    report = analyze_failure('Unable to resolve target: {"accessibility_id": "start"}', {"action": "tap"})
    assert report["category"] == "locator_or_ui_change"
    assert report["root_cause_confirmed"] is False
    assert report["recommended_actions"]


def test_ps5_launch_action_uses_target_manager_adapter(monkeypatch):
    from autopilotqe_agent.replay import ReplayEngine
    calls = []
    class FakeManager:
        def __init__(self, **kwargs): calls.append(('init', kwargs))
        def launch(self, title_id): calls.append(('launch', title_id)); return 'started'
    monkeypatch.setattr('autopilotqe_agent.ps5.PS5TargetManager', FakeManager)
    result = ReplayEngine(driver=None, test_data={'TITLE':'PPSA12345','IP':'10.0.0.5'}).execute_step({
        'action':'ps5_launch','value':'${TITLE}','target':{'target_ip':'${IP}','title_id':'${TITLE}'}})
    assert result['status'] == 'passed'
    assert ('launch','PPSA12345') in calls


def test_ps5_launch_rejects_empty_title_id():
    from autopilotqe_agent.ps5 import PS5TargetManager, PS5TargetError
    manager = PS5TargetManager(executable='not-installed')
    try:
        manager.launch('')
    except PS5TargetError as exc:
        assert 'Title ID' in str(exc)
    else:
        raise AssertionError('Expected invalid title ID to be rejected')

def test_self_healing_finds_exact_semantic_match_without_mutating_source():
    from autopilotqe_agent.self_healing import find_safe_candidate
    source = '''<hierarchy><node class="android.widget.Button" text="Sign in" content-desc="signin_button" resource-id="com.example:id/signin" bounds="[1,2][3,4]"/></hierarchy>'''
    original = {'accessibility_id': 'login_button', 'text': 'Sign in', 'class_name': 'android.widget.Button'}
    candidate = find_safe_candidate(source, original)
    assert candidate['locator'] == {'accessibility_id': 'signin_button'}
    assert candidate['confidence'] >= 0.93
    assert original['accessibility_id'] == 'login_button'


def test_self_healing_refuses_ambiguous_candidates():
    from autopilotqe_agent.self_healing import find_safe_candidate
    source = '''<hierarchy><node class="Button" text="Continue" content-desc="continue_a"/><node class="Button" text="Continue" content-desc="continue_b"/></hierarchy>'''
    assert find_safe_candidate(source, {'text': 'Continue'}) is None
