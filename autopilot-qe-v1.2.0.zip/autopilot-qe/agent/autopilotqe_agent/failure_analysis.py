import re

def analyze_failure(error: str, step: dict | None = None) -> dict:
    """Produce deterministic, evidence-led triage; never claim a root cause as certain."""
    message = str(error or "Unknown execution failure")
    lowered = message.lower()
    action = (step or {}).get("action", "unknown")
    if any(x in lowered for x in ("no such element", "unable to resolve target", "element not found", "stale element")):
        category, confidence = "locator_or_ui_change", "high"
        causes = ["The locator is missing, ambiguous, stale, or changed in the current app build.", "The target screen may not have loaded before the lookup."]
        actions = ["Inspect the captured screenshot and UI hierarchy.", "Prefer a stable accessibility ID or resource ID over positional XPath.", "Add a wait-for condition and re-record the affected step."]
    elif any(x in lowered for x in ("expected text", "assertion", "not found in page source")):
        category, confidence = "assertion_mismatch", "high"
        causes = ["The expected text/state is not present, or the app is showing a different state.", "The expected value may be dynamic, localized, or delayed."]
        actions = ["Check the screenshot and actual page source.", "Confirm test data, account state, locale, and backend response.", "Use a stable semantic assertion rather than exact dynamic text where appropriate."]
    elif any(x in lowered for x in ("timeout", "timed out", "wait")):
        category, confidence = "timeout_or_synchronization", "medium"
        causes = ["The app or network responded more slowly than the configured wait.", "A loading overlay, permission dialog, or transient state may be blocking progress."]
        actions = ["Increase the wait only after checking for a genuine hang.", "Wait for a specific screen or element instead of a fixed sleep.", "Review device performance and network logs."]
    elif any(x in lowered for x in ("applitools", "eyes", "visual")):
        category, confidence = "visual_regression", "medium"
        causes = ["The rendered screen differs from its approved baseline, or the Eyes service could not be reached."]
        actions = ["Open the Eyes result and inspect changed regions.", "Check dynamic content masks and baseline environment before approving changes."]
    elif any(x in lowered for x in ("connection", "network", "refused", "unreachable", "http")):
        category, confidence = "connectivity_or_service", "medium"
        causes = ["The device, Appium server, application backend, or external service may be unreachable."]
        actions = ["Check Appium/device connectivity and service health.", "Verify the test environment and credentials without placing secrets in test data."]
    elif any(x in lowered for x in ("launch", "activate_app", "app id", "bundle")):
        category, confidence = "app_launch_or_configuration", "medium"
        causes = ["The app identifier may be incorrect, the app may not be installed, or launch permissions may be missing."]
        actions = ["Verify the Android package name or iOS bundle ID on the target device.", "Install/update the app and confirm the selected device platform."]
    else:
        category, confidence = "unclassified", "low"
        causes = ["The available error message is insufficient to identify a reliable root cause."]
        actions = ["Review the failing step, screenshot, UI source, and device logs.", "Re-run once with verbose agent logging to check reproducibility."]
    return {"category": category, "confidence": confidence, "summary": f"Step action '{action}' failed: {message[:500]}",
            "possible_causes": causes, "recommended_actions": actions, "root_cause_confirmed": False}
