"""Optional Applitools Eyes adapters for Playwright, Selenium and Appium drivers."""
import os

class VisualConfigurationError(RuntimeError):
    pass


def _api_key():
    key = os.getenv("APPLITOOLS_API_KEY", "")
    if not key:
        raise VisualConfigurationError("Visual checkpoints are configured but APPLITOOLS_API_KEY is missing on the execution worker")
    return key


class PlaywrightEyes:
    def __init__(self, page, app_name, test_name):
        from applitools.playwright import Eyes, ClassicRunner, Configuration
        self.page = page
        self.runner = ClassicRunner()
        config = Configuration()
        config.set_api_key(_api_key())
        server = os.getenv("APPLITOOLS_SERVER_URL")
        if server:
            config.set_server_url(server)
        self.eyes = Eyes(self.runner)
        self.eyes.set_configuration(config)
        self.app_name = app_name
        self.test_name = test_name
        self.opened = False

    def open(self):
        viewport = self.page.viewport_size or {"width": 1280, "height": 720}
        self.eyes.open(self.page, self.app_name, self.test_name, viewport)
        self.opened = True

    def check(self, checkpoint):
        from applitools.playwright import Target
        wait_for = checkpoint.get("wait_for_selector")
        if wait_for:
            self.page.locator(wait_for).wait_for(state="visible")
        # Mask private/dynamic values before sending any screenshot to Eyes.
        if checkpoint.get("disable_animations", True):
            self.page.add_style_tag(content="*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}")
        if checkpoint.get("hide_caret", True):
            self.page.add_style_tag(content="*{caret-color:transparent!important}")
        self.page.evaluate("""selectors => selectors.forEach(sel => document.querySelectorAll(sel).forEach(el => {
          if (!el.dataset.mpVisualOriginal) el.dataset.mpVisualOriginal = el.getAttribute('style') || '';
          el.style.visibility = 'hidden';
        }))""", checkpoint.get("mask_selectors", []))
        self.page.evaluate("""selectors => selectors.forEach(sel => document.querySelectorAll(sel).forEach(el => {
          if (!el.dataset.mpVisualLayoutOriginal) el.dataset.mpVisualLayoutOriginal = el.getAttribute('style') || '';
          el.style.color = 'transparent'; el.style.textShadow = 'none';
          el.querySelectorAll('*').forEach(child => { child.style.color = 'transparent'; child.style.textShadow = 'none'; });
        }))""", checkpoint.get("layout_selectors", []))
        try:
            scope = checkpoint.get("scope", "full_page")
            if scope == "element":
                target = Target.region(self.page.locator(checkpoint["selector"]))
            else:
                target = Target.window().fully() if scope == "full_page" else Target.window()
            level = checkpoint.get("match_level", "Dynamic").lower()
            if level == "strict": target = target.strict()
            elif level == "layout": target = target.layout()
            elif level == "ignorecolors": target = target.ignore_colors()
            for selector in checkpoint.get("ignore_selectors", []):
                target = target.ignore(self.page.locator(selector))
            self.eyes.check(checkpoint["name"], target)
        finally:
            self.page.evaluate("""selectors => selectors.forEach(sel => document.querySelectorAll(sel).forEach(el => {
              el.setAttribute('style', el.dataset.mpVisualOriginal || ''); delete el.dataset.mpVisualOriginal;
            }))""", checkpoint.get("mask_selectors", []))
            self.page.evaluate("""selectors => selectors.forEach(sel => document.querySelectorAll(sel).forEach(el => {
              el.setAttribute('style', el.dataset.mpVisualLayoutOriginal || ''); delete el.dataset.mpVisualLayoutOriginal;
            }))""", checkpoint.get("layout_selectors", []))

    def close(self):
        if self.opened:
            try: self.eyes.close()
            finally: self.opened = False
        return self.runner.get_all_test_results() if self.runner else None


class SeleniumEyes:
    def __init__(self, driver, app_name, test_name):
        from applitools.selenium import Eyes
        self.driver = driver
        self.eyes = Eyes()
        self.eyes.api_key = _api_key()
        server = os.getenv("APPLITOOLS_SERVER_URL")
        if server:
            self.eyes.server_url = server
        self.app_name = app_name
        self.test_name = test_name
        self.opened = False

    def open(self):
        self.eyes.open(self.driver, self.app_name, self.test_name)
        self.opened = True

    def check(self, checkpoint):
        from selenium.webdriver.common.by import By
        from applitools.selenium import Target
        try:
            from applitools.common import MatchLevel
        except ImportError:
            MatchLevel = None
        wait_for = checkpoint.get("wait_for_selector")
        if wait_for:
            self.driver.find_element(By.CSS_SELECTOR, wait_for)
        # For web DOMs, mask and layout-normalize configured regions while retaining geometry.
        masks = checkpoint.get("mask_selectors", []) + checkpoint.get("ignore_selectors", [])
        layouts = checkpoint.get("layout_selectors", [])
        for selector in masks:
            try: self.driver.execute_script("el => { el.dataset.mpVisualOriginal = el.getAttribute('style') || ''; el.style.visibility='hidden'; }", self.driver.find_element(By.CSS_SELECTOR, selector))
            except Exception: pass
        for selector in layouts:
            try: self.driver.execute_script("el => { el.dataset.mpVisualLayoutOriginal = el.getAttribute('style') || ''; el.style.color='transparent'; el.style.textShadow='none'; el.querySelectorAll('*').forEach(x => x.style.color='transparent'); }", self.driver.find_element(By.CSS_SELECTOR, selector))
            except Exception: pass
        try:
            if checkpoint.get("scope") == "element":
                selector_type = checkpoint.get("selector_type", "css")
                if selector_type == "accessibility_id":
                    from appium.webdriver.common.appiumby import AppiumBy
                    by = AppiumBy.ACCESSIBILITY_ID
                else:
                    by = By.XPATH if selector_type == "xpath" else By.CSS_SELECTOR
                self.eyes.check_region(by=by, selector=checkpoint["selector"], tag=checkpoint["name"])
            else:
                level = checkpoint.get("match_level", "Dynamic").lower()
                if MatchLevel is not None:
                    if level == "layout": self.eyes.match_level = MatchLevel.Layout
                    elif level == "strict": self.eyes.match_level = MatchLevel.Strict
                    elif level == "ignorecolors": self.eyes.match_level = MatchLevel.IgnoreColors
                    else: self.eyes.match_level = MatchLevel.Dynamic
                target = Target.window().fully() if checkpoint.get("scope") == "full_page" else Target.window()
                for selector in checkpoint.get("ignore_selectors", []):
                    try: target = target.ignore(self.driver.find_element(By.CSS_SELECTOR, selector))
                    except Exception: pass
                self.eyes.check(checkpoint["name"], target)
        finally:
            for selector in masks:
                try: self.driver.execute_script("el => { el.setAttribute('style', el.dataset.mpVisualOriginal || ''); delete el.dataset.mpVisualOriginal; }", self.driver.find_element(By.CSS_SELECTOR, selector))
                except Exception: pass
            for selector in layouts:
                try: self.driver.execute_script("el => { el.setAttribute('style', el.dataset.mpVisualLayoutOriginal || ''); delete el.dataset.mpVisualLayoutOriginal; }", self.driver.find_element(By.CSS_SELECTOR, selector))
                except Exception: pass

    def close(self):
        if self.opened:
            try: return self.eyes.close()
            finally:
                self.eyes.abort_if_not_closed()
                self.opened = False
        return None
