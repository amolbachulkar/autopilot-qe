import os, re, time

class WebReplayError(RuntimeError):
    pass

class WebReplayEngine:
    def __init__(self, provider="local", browser="chromium", remote_url="", timeout_ms=10000, heal=False):
        self.provider=provider; self.browser=browser; self.remote_url=remote_url; self.timeout_ms=timeout_ms; self.heal=heal
        self.healing_events=[]

    def _resolve(self, value, data):
        if not isinstance(value, str): return value
        def sub(m):
            secret, key=m.group(1), m.group(2)
            if secret:
                env=f"AUTOPILOTQE_SECRET_{key}"
                if env not in os.environ: raise WebReplayError(f"Missing secret environment variable: {env}")
                return os.environ[env]
            if key not in data: raise WebReplayError(f"Missing test-data variable: {key}")
            return str(data[key])
        return re.sub(r"\$\{(?:(SECRET):)?([A-Za-z_][A-Za-z0-9_]*)\}",sub,value)

    def run(self, steps, test_data=None, visual_checkpoints=None, app_name="AutoPilotQE", test_name="AutoPilotQE visual test"):
        data=test_data or {}; results=[]; visual_results=[]; visual_runner=None; driver=None; browser_obj=None; page=None; engine="playwright"; self.healing_events=[]
        try:
            if self.provider == "local":
                from playwright.sync_api import sync_playwright
                pw=sync_playwright().start(); browser_type=getattr(pw,self.browser if self.browser in {"chromium","firefox","webkit"} else "chromium")
                browser_obj=browser_type.launch(headless=True); page=browser_obj.new_page()
            else:
                from selenium import webdriver
                from selenium.webdriver.chrome.options import Options as ChromeOptions
                from selenium.webdriver.edge.options import Options as EdgeOptions
                from selenium.webdriver.firefox.options import Options as FirefoxOptions
                if not self.remote_url: raise WebReplayError(f"No remote WebDriver URL configured for provider {self.provider}")
                options=FirefoxOptions() if self.browser=="firefox" else EdgeOptions() if self.browser=="edge" else ChromeOptions()
                driver=webdriver.Remote(command_executor=self.remote_url,options=options); engine="selenium"
            checkpoints = [c for c in (visual_checkpoints or []) if c.get("enabled", True)]
            if checkpoints:
                from autopilotqe_agent.visual import PlaywrightEyes, SeleniumEyes
                visual_runner = PlaywrightEyes(page, app_name, test_name) if engine == "playwright" else SeleniumEyes(driver, app_name, test_name)
                visual_runner.open()
                for cp in checkpoints:
                    if int(cp.get("after_step", 0)) == 0:
                        visual_runner.check(cp); visual_results.append({"name": cp.get("name"), "status": "submitted"})
            for i,raw in enumerate(steps,1):
                step=raw or {}; action=str(step.get("action","")).lower(); target=step.get("target") or {}; value=self._resolve(step.get("value", ""),data); started=time.time()
                selector=target.get("css") or target.get("css_selector") or target.get("xpath")
                by="xpath" if target.get("xpath") else "css selector"
                if engine=="playwright":
                    if target.get("test_id"): loc=page.get_by_test_id(target["test_id"])
                    elif target.get("role") and target.get("name"): loc=page.get_by_role(target["role"], name=target["name"])
                    elif target.get("label"): loc=page.get_by_label(target["label"])
                    elif target.get("placeholder"): loc=page.get_by_placeholder(target["placeholder"])
                    elif target.get("text"): loc=page.get_by_text(target["text"], exact=True)
                    else: loc=page.locator(("xpath=" + selector) if by == "xpath" and selector else selector) if selector else None
                    if self.heal and loc is not None and action in {"click","tap","fill","input","type","select","check","hover","press"}:
                        try: count = loc.count()
                        except Exception: count = 0
                        if count == 0:
                            inventory = page.locator("button,a,input,select,textarea,[role],[aria-label],[data-testid],label").evaluate_all("els => els.map(e => ({text:(e.innerText||e.textContent||'').trim().slice(0,200),aria_label:e.getAttribute('aria-label')||'',title:e.getAttribute('title')||'',placeholder:e.getAttribute('placeholder')||'',id:e.id||'',test_id:e.getAttribute('data-testid')||'',role:e.getAttribute('role')||e.tagName.toLowerCase(),visible:!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length)}))")
                            from autopilotqe_agent.self_healing import find_safe_web_candidate
                            healed = find_safe_web_candidate(inventory, target)
                            if healed:
                                candidate = healed["locator"]
                                if candidate.get("role"): loc = page.get_by_role(candidate["role"], name=candidate.get("name"))
                                elif candidate.get("label"): loc = page.get_by_label(candidate["label"])
                                elif candidate.get("placeholder"): loc = page.get_by_placeholder(candidate["placeholder"])
                                elif candidate.get("test_id"): loc = page.get_by_test_id(candidate["test_id"])
                                elif candidate.get("css"): loc = page.locator(candidate["css"])
                                else: loc = page.get_by_text(candidate.get("text", ""), exact=True)
                                self.healing_events.append({"step_index": i-1, "original_locator": target, "candidate_locator": candidate,
                                    "confidence": healed["confidence"], "evidence": healed["evidence"]})
                    if action in {"navigate","goto","open"}: page.goto(value or target.get("url"),wait_until="domcontentloaded",timeout=self.timeout_ms)
                    elif action in {"click","tap"}: loc.first.click(timeout=self.timeout_ms)
                    elif action in {"fill","input","type"}: loc.first.fill(value,timeout=self.timeout_ms)
                    elif action=="select": loc.first.select_option(value,timeout=self.timeout_ms)
                    elif action=="check": loc.first.check(timeout=self.timeout_ms)
                    elif action=="submit": loc.first.evaluate("el => el.requestSubmit ? el.requestSubmit() : el.submit()")
                    elif action=="hover": loc.first.hover(timeout=self.timeout_ms)
                    elif action=="press": loc.first.press(str(value or "Enter"), timeout=self.timeout_ms)
                    elif action in {"scroll","scroll_into_view"}: loc.first.scroll_into_view_if_needed(timeout=self.timeout_ms)
                    elif action in {"assert_visible","verify_visible"}:
                        if not loc.first.is_visible(): raise WebReplayError("Expected element is not visible")
                    elif action in {"assert_text","verify_text"}:
                        expected=step.get("expected",{}).get("text",value)
                        if expected not in page.locator("body").inner_text(): raise WebReplayError(f"Expected text not found: {expected}")
                    elif action in {"assert_url","verify_url"}:
                        expected=step.get("expected",{}).get("url",value)
                        if expected not in page.url: raise WebReplayError(f"Expected URL fragment not found: {expected}")
                    elif action in {"assert_title","verify_title"}:
                        expected=step.get("expected",{}).get("title",value)
                        if expected not in page.title(): raise WebReplayError(f"Expected title not found: {expected}")
                    elif action in {"wait","sleep"}: page.wait_for_timeout(min(max(int(float(value or 1)*1000),0),30000))
                    elif action=="reload": page.reload(wait_until="domcontentloaded",timeout=self.timeout_ms)
                    elif action=="back": page.go_back(wait_until="domcontentloaded",timeout=self.timeout_ms)
                    elif action=="screenshot": page.screenshot(path=target.get("path","web-step.png"))
                    else: raise WebReplayError(f"Unsupported web action: {action}")
                else:
                    from selenium.webdriver.common.by import By
                    element=None
                    if selector:
                        try: element=driver.find_element(By.XPATH if by=="xpath" else By.CSS_SELECTOR,selector)
                        except Exception:
                            if self.heal and action in {"click","tap","fill","input","type","select","check","hover","press"}:
                                from autopilotqe_agent.self_healing import find_safe_web_candidate
                                inventory=[]
                                for el in driver.find_elements(By.CSS_SELECTOR,"button,a,input,select,textarea,[role],[aria-label],[data-testid],label")[:300]:
                                    try:
                                        if not el.is_displayed(): continue
                                    except Exception: continue
                                    inventory.append({"text":(el.text or "")[:200],"aria_label":el.get_attribute("aria-label") or "","title":el.get_attribute("title") or "","placeholder":el.get_attribute("placeholder") or "","id":el.get_attribute("id") or "","test_id":el.get_attribute("data-testid") or "","role":el.get_attribute("role") or el.tag_name})
                                healed=find_safe_web_candidate(inventory,target)
                                if healed:
                                    candidate=healed["locator"]
                                    if candidate.get("css"): element=driver.find_element(By.CSS_SELECTOR,candidate["css"])
                                    elif candidate.get("test_id"): element=driver.find_element(By.CSS_SELECTOR,f'[data-testid="{candidate["test_id"]}"]')
                                    elif candidate.get("label"): element=driver.find_element(By.CSS_SELECTOR,f'[aria-label="{candidate["label"]}"]')
                                    elif candidate.get("placeholder"): element=driver.find_element(By.CSS_SELECTOR,f'[placeholder="{candidate["placeholder"]}"]')
                                    elif candidate.get("name"): element=driver.find_element(By.XPATH,f"//*[@role='{candidate['role']}' and (@aria-label='{candidate['name']}' or normalize-space(.)='{candidate['name']}')]")
                                    self.healing_events.append({"step_index":i-1,"original_locator":target,"candidate_locator":candidate,"confidence":healed["confidence"],"evidence":healed["evidence"]})
                    if action in {"navigate","goto","open"}: driver.get(value or target.get("url"))
                    elif action in {"click","tap"}: element.click()
                    elif action in {"fill","input","type"}: element.clear(); element.send_keys(value)
                    elif action=="select":
                        from selenium.webdriver.support.ui import Select
                        Select(element).select_by_value(value)
                    elif action=="check":
                        if not element.is_selected(): element.click()
                    elif action=="submit": element.submit()
                    elif action=="hover":
                        from selenium.webdriver import ActionChains
                        ActionChains(driver).move_to_element(element).perform()
                    elif action=="press": element.send_keys(value or "ENTER")
                    elif action in {"scroll","scroll_into_view"}: driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
                    elif action in {"assert_visible","verify_visible"}:
                        if not element.is_displayed(): raise WebReplayError("Expected element is not visible")
                    elif action in {"assert_text","verify_text"}:
                        expected=step.get("expected",{}).get("text",value)
                        if expected not in driver.find_element(By.TAG_NAME,"body").text: raise WebReplayError(f"Expected text not found: {expected}")
                    elif action in {"assert_url","verify_url"}:
                        expected=step.get("expected",{}).get("url",value)
                        if expected not in driver.current_url: raise WebReplayError(f"Expected URL fragment not found: {expected}")
                    elif action in {"assert_title","verify_title"}:
                        expected=step.get("expected",{}).get("title",value)
                        if expected not in driver.title: raise WebReplayError(f"Expected title not found: {expected}")
                    elif action in {"wait","sleep"}: time.sleep(min(max(float(value or 1),0),30))
                    elif action=="reload": driver.refresh()
                    elif action=="back": driver.back()
                    elif action=="screenshot": driver.save_screenshot(target.get("path","web-step.png"))
                    else: raise WebReplayError(f"Unsupported remote web action: {action}")
                results.append({"step":i,"status":"passed","action":action,"engine":engine,"duration_ms":round((time.time()-started)*1000)})
                if visual_runner:
                    for cp in checkpoints:
                        if int(cp.get("after_step", 0)) == i:
                            visual_runner.check(cp); visual_results.append({"name": cp.get("name"), "status": "submitted", "after_step": i})
            visual_summary = visual_runner.close() if visual_runner else None
            visual_runner = None
            return {"status":"passed" if results else "failed","engine":engine,"provider":self.provider,"steps":results,"healing_events":self.healing_events,"healing_enabled":self.heal,"failure_analysis":None,"visual": {"status":"submitted" if visual_results else "not_configured", "checkpoints":visual_results, "summary":str(visual_summary)[:2000] if visual_summary else None}}
        except Exception as exc:
            from autopilotqe_agent.failure_analysis import analyze_failure
            evidence = {}
            try:
                artifact_dir=os.getenv("AUTOPILOTQE_ARTIFACTS_DIR","./artifacts"); os.makedirs(artifact_dir,exist_ok=True)
                path=os.path.join(artifact_dir,f"web-failure-{int(time.time())}.png")
                if page:
                    page.screenshot(path=path); evidence["screenshot"]=path
                elif driver and driver.save_screenshot(path): evidence["screenshot"]=path
            except Exception: pass
            try: evidence["page_source_excerpt"]=(page.content() if page else driver.page_source if driver else "")[:12000]
            except Exception: pass
            failed_step={"action": (steps[len(results)] or {}).get("action", "unknown") if len(steps)>len(results) else "unknown"}
            analysis=analyze_failure(str(exc),failed_step)
            results.append({"step":len(results)+1,"status":"failed","action":failed_step["action"],"error":str(exc),"failure_analysis":analysis,"evidence":evidence})
            if visual_runner:
                try: visual_runner.close()
                except Exception: pass
            return {"status":"failed","engine":engine,"provider":self.provider,"steps":results,"healing_events":self.healing_events,"healing_enabled":self.heal,"failure_analysis":analysis,"visual":{"status":"failed" if visual_checkpoints else "not_configured","error":str(exc)[:1000]}}
        finally:
            if driver:
                try: driver.quit()
                except Exception: pass
            if browser_obj:
                try: browser_obj.close(); pw.stop()
                except Exception: pass
