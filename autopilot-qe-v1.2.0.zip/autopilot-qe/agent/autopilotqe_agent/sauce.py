import os
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.options.ios import XCUITestOptions

def connect_sauce(platform: str, device_name: str, platform_version: str, app_reference: str):
    username=os.getenv('SAUCE_USERNAME',''); access_key=os.getenv('SAUCE_ACCESS_KEY','')
    region=os.getenv('SAUCE_REGION','us-west-1')
    if not username or not access_key: raise RuntimeError('Set SAUCE_USERNAME and SAUCE_ACCESS_KEY in the agent environment.')
    driver_name='XCUITest' if platform.lower()=='ios' else 'UiAutomator2'
    options=XCUITestOptions() if platform.lower()=='ios' else UiAutomator2Options()
    options.set_capability('platformName','iOS' if platform.lower()=='ios' else 'Android')
    options.set_capability('appium:automationName',driver_name)
    options.set_capability('appium:deviceName',device_name)
    if platform_version: options.set_capability('appium:platformVersion',platform_version)
    if app_reference: options.set_capability('appium:app',app_reference)
    options.set_capability('sauce:options',{'username':username,'accessKey':access_key,'name':'AutoPilotQE replay'})
    return webdriver.Remote(f'https://ondemand.{region}.saucelabs.com/wd/hub',options=options)
