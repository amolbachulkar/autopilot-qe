from datetime import datetime, timezone
from pathlib import Path

class Recorder:
    """Small recorder adapter. Feed it normalized events from an Appium proxy or desktop overlay."""
    def __init__(self, api_client, session_id: str, artifacts_dir="artifacts"):
        self.api=api_client; self.session_id=session_id; self.artifacts=Path(artifacts_dir); self.artifacts.mkdir(parents=True,exist_ok=True)
    def capture(self, driver, action: str, target=None, value=None, expected=None, metadata=None, capture_screenshot=True):
        target=target or {}; screenshot=None
        try:
            if not capture_screenshot:
                raise RuntimeError("Screenshot intentionally suppressed for sensitive action")
            name=f"{self.session_id}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%f')}.png"
            path=self.artifacts/name
            if driver.get_screenshot_as_file(str(path)): screenshot=str(path)
        except Exception: pass
        step={"action":action,"target":target,"value":value,"expected":expected or {},"screenshot":screenshot,
              "timestamp":datetime.now(timezone.utc).isoformat(),"metadata":metadata or {}}
        return self.api.add_step(self.session_id,step)
