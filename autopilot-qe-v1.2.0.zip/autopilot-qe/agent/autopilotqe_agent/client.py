import os
import requests

class APIClient:
    def __init__(self, base_url: str, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        key = api_key if api_key is not None else os.getenv("AUTOPILOTQE_API_KEY", "")
        if key:
            self.session.headers.update({"X-API-Key": key})

    def _request(self, method, path, **kwargs):
        response = self.session.request(method, f"{self.base_url}{path}", timeout=20, **kwargs)
        response.raise_for_status()
        return response.json() if response.content else {}

    def get_test(self, test_id): return self._request("GET", f"/api/v1/tests/{test_id}")
    def start_recording(self, payload): return self._request("POST", "/api/v1/recordings", json=payload)
    def add_step(self, session_id, step): return self._request("POST", f"/api/v1/recordings/{session_id}/steps", json=step)
    def stop_recording(self, session_id): return self._request("POST", f"/api/v1/recordings/{session_id}/stop")
    def save_recording(self, session_id): return self._request("POST", f"/api/v1/recordings/{session_id}/save-as-test")
    def register_device(self, device): return self._request("POST", "/api/v1/devices", json=device)

    def claim_execution(self, device_id):
        return self._request("POST", "/api/v1/agent/executions/claim", json={"device_id": device_id})

    def complete_execution(self, execution_id, status, result):
        return self._request("POST", f"/api/v1/executions/{execution_id}/complete", json={"status": status, "result": result})
