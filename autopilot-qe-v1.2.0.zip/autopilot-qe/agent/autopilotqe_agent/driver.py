from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.options.ios import XCUITestOptions


def connect(platform: str, device_id: str, appium_url: str, app: str = "", platform_version: str = "", app_id: str = "", provider: str = "local"):
    platform=platform.lower()
    if platform not in {"android","ios"}: raise ValueError("platform must be android or ios")
    options=UiAutomator2Options() if platform=="android" else XCUITestOptions()
    options.set_capability("platformName", "Android" if platform=="android" else "iOS")
    options.set_capability("appium:automationName", "UiAutomator2" if platform=="android" else "XCUITest")
    options.set_capability("appium:deviceName", device_id or ("Android Device" if platform=="android" else "iPhone Simulator"))
    if device_id: options.set_capability("appium:udid",device_id)
    if app: options.set_capability("appium:app",app)
    if app_id:
        options.set_capability("appium:appPackage" if platform=="android" else "appium:bundleId", app_id)
        options.set_capability("appium:noReset", True)
    if platform_version: options.set_capability("appium:platformVersion",platform_version)
    if provider == "headspin":
        import os, requests
        token = os.getenv("HEADSPIN_API_TOKEN", "")
        base = os.getenv("HEADSPIN_API_BASE_URL", "https://api.headspin.io").rstrip("/")
        if token and device_id:
            response = requests.get(f"{base}/v0/devices/automation-config", headers={"Authorization": f"Bearer {token}"}, timeout=20)
            response.raise_for_status()
            config = response.json().get(device_id)
            if not config or not config.get("driver_url"):
                raise RuntimeError(f"HeadSpin did not return an Appium driver URL for device {device_id}")
            appium_url = config["driver_url"]
            for key, value in (config.get("capabilities") or {}).items():
                if key == "platformName":
                    options.set_capability("platformName", value)
                elif key in {"deviceName", "udid", "automationName", "platformVersion", "autoAcceptAlerts", "noReset"}:
                    options.set_capability(f"appium:{key}", value)
                else:
                    cap = key if "." in key or ":" in key else f"appium:{key}"
                    options.set_capability(cap, value)
        else:
            appium_url = os.getenv("HEADSPIN_APPIUM_URL", appium_url)
        if not appium_url or appium_url == "http://127.0.0.1:4723":
            raise RuntimeError("Configure HEADSPIN_API_TOKEN (recommended) or HEADSPIN_APPIUM_URL for HeadSpin.")
    return webdriver.Remote(appium_url,options=options)
