import argparse, json, os, time
from autopilotqe_agent.client import APIClient
from autopilotqe_agent.driver import connect
from autopilotqe_agent.recorder import Recorder
from autopilotqe_agent.replay import ReplayEngine


def make_driver(args):
    if args.provider == 'sauce':
        from autopilotqe_agent.sauce import connect_sauce
        return connect_sauce(args.platform,args.device_name or args.device_id,args.platform_version,args.app)
    return connect(args.platform,args.device_id,args.appium_url,args.app,args.platform_version,getattr(args,'app_id',''),args.provider)


def main():
    parser=argparse.ArgumentParser(prog="autopilotqe-agent")
    sub=parser.add_subparsers(dest="command",required=True)
    discover=sub.add_parser("discover",help="Discover connected local devices")
    discover.add_argument("--api-url",default=os.getenv("AUTOPILOTQE_API", os.getenv("MOBILEPILOT_API", "http://127.0.0.1:8000")))
    def device_args(cmd):
        cmd.add_argument('--platform',choices=['android','ios'],required=True)
        cmd.add_argument('--device-id',default=''); cmd.add_argument('--device-name',default='')
        cmd.add_argument('--app',default=''); cmd.add_argument('--app-id',default=''); cmd.add_argument('--platform-version',default='')
        cmd.add_argument('--provider',choices=['local','sauce','headspin'],default='local')
        cmd.add_argument('--appium-url',default=os.getenv('APPIUM_URL','http://127.0.0.1:4723'))
        cmd.add_argument('--api-url',default=os.getenv('AUTOPILOTQE_API', os.getenv('MOBILEPILOT_API', 'http://127.0.0.1:8000')))
    rec=sub.add_parser('record',help='Interactively record Appium actions into a reusable test')
    device_args(rec); rec.add_argument('--title',required=True)
    rec.add_argument('--prerequisites',default=''); rec.add_argument('--test-data',default='{}')
    bridge=sub.add_parser('bridge',help='Start live browser-to-device interaction bridge')
    device_args(bridge); bridge.add_argument('--session-id',required=True); bridge.add_argument('--interval',type=float,default=0.8)
    worker=sub.add_parser('worker',help='Poll and execute queued tests for this device')
    device_args(worker); worker.add_argument('--poll-interval',type=float,default=2.0); worker.add_argument('--self-heal',action='store_true',default=os.getenv('AUTOPILOTQE_SELF_HEAL', os.getenv('MOBILEPILOT_SELF_HEAL', 'false')).lower()=='true',help='Allow high-confidence runtime locator recovery; proposals still require review')
    webworker=sub.add_parser('web-worker',help='Poll and execute queued web tests using Playwright locally or Selenium remotely')
    webworker.add_argument('--device-id',required=True); webworker.add_argument('--provider',choices=['local','sauce','headspin'],default='local')
    webworker.add_argument('--browser',choices=['chromium','firefox','webkit','chrome','edge'],default='chromium')
    webworker.add_argument('--remote-url',default=''); webworker.add_argument('--api-url',default=os.getenv('AUTOPILOTQE_API', os.getenv('MOBILEPILOT_API', 'http://127.0.0.1:8000')))
    webworker.add_argument('--poll-interval',type=float,default=2.0); webworker.add_argument('--self-heal',action='store_true',default=os.getenv('AUTOPILOTQE_SELF_HEAL', os.getenv('MOBILEPILOT_SELF_HEAL', 'false')).lower()=='true',help='Allow high-confidence runtime locator recovery; proposals still require review')
    replay=sub.add_parser('replay',help='Replay a saved test case on a connected Appium device')
    replay.add_argument('test_id'); device_args(replay); replay.add_argument('--heal',action='store_true')
    args=parser.parse_args()
    if args.command=='discover':
        # Discover on the host (where ADB/Xcode are installed), then register with the API.
        import shutil, subprocess
        found=[]
        def run_local(command):
            try: return subprocess.run(command,capture_output=True,text=True,timeout=10).stdout.strip()
            except (OSError,subprocess.TimeoutExpired): return ''
        if shutil.which('adb'):
            lines=run_local(['adb','devices','-l']).splitlines()[1:]
            for line in lines:
                parts=line.split()
                if len(parts)>=2 and parts[1]=='device':
                    serial=parts[0]; model=next((p.split(':',1)[1] for p in parts[2:] if p.startswith('model:')),serial)
                    version=run_local(['adb','-s',serial,'shell','getprop','ro.build.version.release']) or 'unknown'
                    found.append({'id':serial,'name':model.replace('_',' '),'platform':'android','os_version':version,'device_type':'emulator' if serial.startswith('emulator-') else 'physical','provider':'local','status':'available','metadata_json':{}})
        if shutil.which('xcrun'):
            try:
                payload=json.loads(run_local(['xcrun','simctl','list','devices','booted','--json']) or '{}')
                for runtime,items in payload.get('devices',{}).items():
                    for item in items:
                        if item.get('state')=='Booted': found.append({'id':item['udid'],'name':item['name'],'platform':'ios','os_version':runtime.split('.')[-1],'device_type':'simulator','provider':'local','status':'available','metadata_json':{}})
            except (ValueError,TypeError): pass
        api=APIClient(args.api_url); registered=[]
        for device in found:
            try: registered.append(api.register_device(device))
            except Exception as exc: print(f"Could not register {device['id']}: {exc}")
        print(json.dumps({'discovered':len(found),'registered':len(registered),'devices':found},indent=2)); return
    if args.command=='ps5-bridge':
        from autopilotqe_agent.ps5 import serve_bridge
        serve_bridge(args.host,args.port)
        return
    if args.command=='ps5':
        from autopilotqe_agent.ps5 import PS5TargetManager
        manager=PS5TargetManager(executable=args.prospero_ctrl or None,target=args.target or None)
        operations={'discover':manager.discover,'list':manager.list_targets,'connect':manager.connect,
                    'info':manager.info,'health':manager.health,
                    'launch':lambda:manager.launch(args.title_id),
                    'screenshot':lambda:manager.screenshot(args.output,args.mode)}
        if args.operation=='launch' and not args.title_id: raise SystemExit('--title-id is required for launch')
        result=operations[args.operation]()
        print(json.dumps({'platform':'ps5-devkit','operation':args.operation,'result':result},indent=2))
        return
    api=APIClient(args.api_url)
    if args.command=='web-worker':
        from autopilotqe_agent.web_replay import WebReplayEngine
        import os
        provider=args.provider
        remote=args.remote_url or (os.getenv('SAUCE_WEBDRIVER_URL','') if provider=='sauce' else os.getenv('HEADSPIN_WEBDRIVER_URL',''))
        if provider == 'sauce' and not remote:
            username=os.getenv('SAUCE_USERNAME',''); access_key=os.getenv('SAUCE_ACCESS_KEY',''); region=os.getenv('SAUCE_REGION','us-west-1')
            if username and access_key: remote=f'https://{username}:{access_key}@ondemand.{region}.saucelabs.com:443/wd/hub'
        engine=WebReplayEngine(provider=provider,browser=args.browser,remote_url=remote,heal=args.self_heal)
        print(f'Web worker online: {args.device_id} ({provider}/{args.browser})')
        try:
            while True:
                claimed=api.claim_execution(args.device_id).get('execution')
                if not claimed:
                    time.sleep(max(1.0,args.poll_interval)); continue
                result=engine.run(claimed.get('steps',[]),claimed.get('test_data',{}),claimed.get('visual_checkpoints',[]),test_name=claimed.get('title','AutoPilotQE test'))
                api.complete_execution(claimed['id'],'passed' if result['status']=='passed' else 'failed',result)
                print(json.dumps({'execution_id':claimed['id'],**result},indent=2))
        except KeyboardInterrupt:
            print('Web worker stopping...')
        return
    if args.command=='worker':
        driver=make_driver(args)
        try:
            print(f'Worker online for device {args.device_id or args.device_name}')
            while True:
                claimed=api.claim_execution(args.device_id or args.device_name).get('execution')
                if not claimed:
                    time.sleep(max(1.0,args.poll_interval)); continue
                result=ReplayEngine(driver,heal=args.self_heal,test_data=claimed.get('test_data',{}),app_id=claimed.get('app_id','')).run(
                    claimed.get('steps',[]), claimed.get('visual_checkpoints',[]),
                    os.getenv('APPLITOOLS_APP_NAME','AutoPilotQE'), claimed.get('title','AutoPilotQE test'))
                api.complete_execution(claimed['id'], 'passed' if result['status']=='passed' else 'failed', result)
                print(json.dumps({'execution_id':claimed['id'],**result},indent=2))
        except KeyboardInterrupt:
            print('Worker stopping...')
        finally: driver.quit()
        return
    if args.command=='bridge':
        driver=make_driver(args)
        try:
            if args.app_id: driver.activate_app(args.app_id)
            from autopilotqe_agent.bridge import run_bridge
            run_bridge(driver,args.device_id or args.device_name,api,args.session_id,args.api_url,args.interval)
        finally: driver.quit()
        return
    if args.command=='record':
        try: data=json.loads(args.test_data)
        except ValueError as exc: raise SystemExit(f'--test-data must be JSON: {exc}')
        session=api.start_recording({'title':args.title,'device_id':args.device_id or args.device_name,'app_id':args.app_id,
                                     'prerequisites':args.prerequisites,'test_data':data})
        driver=make_driver(args); recorder=Recorder(api,session['id'])
        recorder.capture(driver,'launch',metadata={'app_id':args.app_id})
        print('Recording session: ',session['id'])
        print('Commands: tap, type, swipe, back, wait, assert, screenshot, source, quit')
        try:
            while True:
                raw=input('autopilotqe> ').strip()
                if not raw: continue
                parts=raw.split(' ',2); action=parts[0].lower()
                if action=='quit': break
                if action=='tap':
                    locator=json.loads(parts[1]) if len(parts)>1 else {}
                    element=driver.find_element(*next(( ( {'id':'id','accessibility_id':'accessibility id','xpath':'xpath','text':'accessibility id'}[k],v) for k,v in locator.items() if k in {'id','accessibility_id','xpath','text'} ),('accessibility id','__missing__')))
                    element.click(); recorder.capture(driver,'tap',locator)
                elif action=='type':
                    locator=json.loads(parts[1]); value=parts[2] if len(parts)>2 else ''
                    element=driver.find_element(*next((( {'id':'id','accessibility_id':'accessibility id','xpath':'xpath'}[k],v) for k,v in locator.items() if k in {'id','accessibility_id','xpath'} ),('accessibility id','__missing__')))
                    element.send_keys(value); safe_value='${SECRET:TEST_SECRET}' if locator.get('sensitive') else value; recorder.capture(driver,'input',locator,safe_value,metadata={'redacted':bool(locator.get('sensitive'))},capture_screenshot=not bool(locator.get('sensitive')))
                elif action=='swipe':
                    direction=parts[1] if len(parts)>1 else 'up'; driver.execute_script('mobile: swipe',{'direction':direction}); recorder.capture(driver,'swipe',{'direction':direction})
                elif action=='back': driver.back(); recorder.capture(driver,'back')
                elif action=='wait':
                    import time
                    seconds=float(parts[1]) if len(parts)>1 else 1; time.sleep(min(seconds,30)); recorder.capture(driver,'wait',value=str(seconds))
                elif action=='assert':
                    expected=raw[len('assert'):].strip(); recorder.capture(driver,'assert_text',expected={'text':expected})
                elif action=='screenshot':
                    print('Screenshot:',driver.get_screenshot_as_base64()[:60]+'…')
                elif action=='source': print(driver.page_source[:12000])
                else: print('Unknown command. See command list above.')
        finally:
            api.stop_recording(session['id']); driver.quit()
        saved=api.save_recording(session['id']); print('Saved test:',json.dumps(saved,indent=2)); return
    test=api.get_test(args.test_id)
    driver=make_driver(args)
    try:
        for step in test.get('steps',[]):
            if step.get('action')=='launch' and test.get('app_id'):
                step.setdefault('metadata',{}).setdefault('app_id',test['app_id'])
        result=ReplayEngine(driver,heal=args.heal,test_data=test.get('test_data',{}),app_id=test.get('app_id','')).run(test.get('steps',[]))
        print(json.dumps({'test':test['title'],**result},indent=2))
        if result['status']!='passed': raise SystemExit(1)
    finally: driver.quit()

if __name__=='__main__': main()
