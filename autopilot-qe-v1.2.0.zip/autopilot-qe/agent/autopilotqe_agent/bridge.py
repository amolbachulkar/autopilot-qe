"""Live browser-to-Appium bridge. All UI actions are initiated by an authenticated local user session."""
import json, time
from autopilotqe_agent.recorder import Recorder


def run_bridge(driver, device_id: str, api, session_id: str, backend: str, interval: float = 0.8):
    from selenium.webdriver.common.actions.action_builder import ActionBuilder
    from selenium.webdriver.common.actions.pointer_input import PointerInput
    try:
        import websocket
    except ImportError as exc:
        raise SystemExit("Install agent requirements (includes websocket-client) before using bridge") from exc
    import os, urllib.parse
    url=backend.replace('https://','wss://').replace('http://','ws://').rstrip('/')+f'/api/v1/bridge/agent/{urllib.parse.quote(device_id, safe="")}'
    api_key=os.getenv('AUTOPILOTQE_API_KEY','')
    headers=[f'X-API-Key: {api_key}'] if api_key else []
    ws=websocket.create_connection(url, timeout=1, header=headers)
    recorder=Recorder(api, session_id)
    print(f"Live bridge connected: {url}")
    print("Open Device Lab > Live Bridge in the browser. Ctrl+C to stop.")
    last_frame=0.0
    try:
        while True:
            now=time.monotonic()
            if now-last_frame >= interval:
                try:
                    shot=driver.get_screenshot_as_base64()
                    size=driver.get_window_size()
                    ws.send(json.dumps({"type":"screen","image":"data:image/png;base64,"+shot,"width":size['width'],"height":size['height'],"timestamp":time.time()}))
                except Exception as exc:
                    ws.send(json.dumps({"type":"agent_error","message":f"Screenshot failed: {exc}"}))
                last_frame=now
            try:
                raw=ws.recv()
                if not raw: continue
                msg=json.loads(raw)
                action=msg.get('action')
                dimensions=driver.get_window_size(); w,h=dimensions['width'],dimensions['height']
                target={}
                if action=='tap':
                    x=max(0,min(w-1,int(float(msg.get('x',0))*w))); y=max(0,min(h-1,int(float(msg.get('y',0))*h)))
                    finger=PointerInput('touch','finger'); builder=ActionBuilder(driver, mouse=finger)
                    builder.pointer_action.move_to_location(x,y); builder.pointer_action.pointer_down(); builder.pointer_action.pause(0.08); builder.pointer_action.pointer_up(); builder.perform()
                    target={'strategy':'coordinates','x':x,'y':y,'normalized':True}
                elif action=='type':
                    text=str(msg.get('text',''))
                    # Send keys to the currently focused native field. Sensitive text should be entered via secure test-data references.
                    driver.switch_to.active_element.send_keys(text)
                    target={'strategy':'focused_element'}
                elif action=='back':
                    driver.back()
                elif action=='swipe':
                    direction=msg.get('direction','up')
                    driver.execute_script('mobile: swipe', {'direction':direction})
                    target={'direction':direction}
                elif action=='home':
                    if driver.capabilities.get('platformName','').lower()=='android': driver.press_keycode(3)
                    else: driver.execute_script('mobile: pressButton', {'name':'home'})
                elif action=='capture_hierarchy':
                    source=driver.page_source
                    ws.send(json.dumps({'type':'hierarchy','source':source[:40000]}))
                    continue
                elif action=='ping':
                    ws.send(json.dumps({'type':'pong'})); continue
                else:
                    ws.send(json.dumps({'type':'error','message':f'Unsupported action: {action}'})); continue
                sensitive=bool(msg.get('sensitive'))
                secret_key=str(msg.get('secret_key','PASSWORD')).strip() or 'PASSWORD'
                recorded_value=(f'${{SECRET:{secret_key}}}' if sensitive else msg.get('text')) if action=='type' else None
                step=recorder.capture(driver, action, target, value=recorded_value, metadata={'source':'live_bridge','device_id':device_id,'redacted':sensitive}, capture_screenshot=not sensitive)
                ws.send(json.dumps({'type':'action_ack','action':action,'step':step,'timestamp':time.time()}))
                # Push a fresh frame immediately after an interaction.
                last_frame=0
            except websocket.WebSocketTimeoutException:
                continue
    except KeyboardInterrupt:
        print('Stopping live bridge...')
    finally:
        ws.close()
