import os
import re
import time

class ReplayError(RuntimeError): pass

class ReplayEngine:
    def __init__(self, driver, wait_seconds=10, heal=False, test_data=None, app_id=""):
        self.driver = driver
        self.wait_seconds = max(1, min(int(wait_seconds), 60))
        self.heal = heal
        self.test_data = test_data or {}
        self.app_id = app_id or ""
        self.results = []
        self.healing_events = []
        self.current_step_index = 0

    def _resolve_value(self, value):
        if not isinstance(value, str): return value
        def replace(match):
            secret, key = match.group(1), match.group(2)
            if secret:
                env_key = f"AUTOPILOTQE_SECRET_{key}"
                if env_key not in os.environ:
                    raise ReplayError(f"Missing secret environment variable: {env_key}")
                replacement = os.environ[env_key]
            else:
                if key not in self.test_data:
                    raise ReplayError(f"Missing test-data variable: {key}")
                replacement = self.test_data[key]
            if replacement is None: return ""
            return str(replacement)
        return re.sub(r"\$\{(?:(SECRET):)?([A-Za-z_][A-Za-z0-9_]*)\}", replace, value)

    def _resolve_tree(self, value):
        if isinstance(value, dict): return {k: self._resolve_tree(v) for k, v in value.items()}
        if isinstance(value, list): return [self._resolve_tree(v) for v in value]
        return self._resolve_value(value)

    def _find(self, target):
        from appium.webdriver.common.appiumby import AppiumBy
        locators = {"id": AppiumBy.ID, "accessibility_id": AppiumBy.ACCESSIBILITY_ID, "xpath": AppiumBy.XPATH,
                    "class_name": AppiumBy.CLASS_NAME, "name": AppiumBy.NAME}
        candidates = [(locators[key], value) for key, value in target.items() if key in locators and value]
        deadline = time.monotonic() + self.wait_seconds
        for by, value in candidates:
            remaining = deadline - time.monotonic()
            if remaining <= 0: break
            try:
                from selenium.webdriver.support.ui import WebDriverWait
                from selenium.webdriver.support import expected_conditions as EC
                return WebDriverWait(self.driver, remaining).until(EC.presence_of_element_located((by, value)))
            except Exception: continue
        text = target.get("text")
        if text:
            for by in (AppiumBy.ACCESSIBILITY_ID, AppiumBy.XPATH):
                try:
                    query = text if by == AppiumBy.ACCESSIBILITY_ID else f"//*[normalize-space(@text)='{text}' or normalize-space(@label)='{text}']"
                    return self.driver.find_element(by, query)
                except Exception: pass
        if self.heal:
            try:
                from autopilotqe_agent.self_healing import find_safe_candidate
                candidate = find_safe_candidate(self.driver.page_source, target, threshold=0.93)
                if candidate:
                    locator = candidate["locator"]
                    key, value = next(iter(locator.items()))
                    healed_by = {"id": AppiumBy.ID, "accessibility_id": AppiumBy.ACCESSIBILITY_ID, "xpath": AppiumBy.XPATH}[key]
                    element = self.driver.find_element(healed_by, value)
                    self.healing_events.append({"step_index": self.current_step_index,
                        "original_locator": target, "candidate_locator": locator,
                        "confidence": candidate["confidence"], "evidence": candidate["evidence"]})
                    return element
            except Exception:
                # Healing is best-effort; the original locator failure remains authoritative.
                pass
        raise ReplayError(f"Unable to resolve target: {target}")

    def execute_step(self, step):
        step = self._resolve_tree(step)
        action = step.get("action", "").lower()
        target = step.get("target") or {}
        value = step.get("value") or ""
        started = time.time()
        if action in {"launch", "launch_app"}:
            app_id = step.get("metadata", {}).get("app_id") or self.app_id
            if not app_id: raise ReplayError("App ID/bundle ID is required for launch action")
            self.driver.activate_app(app_id)
        elif action in {"ps5_connect", "ps5_health", "ps5_launch", "ps5_screenshot"}:
            from autopilotqe_agent.ps5 import PS5TargetManager
            target = step.get("target") or {}
            manager = PS5TargetManager(executable=target.get("prospero_ctrl") or None,
                                       target=target.get("target_ip") or None,
                                       timeout=step.get("timeout", 30))
            if action == "ps5_connect": output = manager.connect()
            elif action == "ps5_health": output = manager.health()
            elif action == "ps5_launch":
                title_id = target.get("title_id") or value
                output = manager.launch(title_id)
            else:
                artifact_dir = os.getenv("AUTOPILOTQE_ARTIFACTS_DIR", "./artifacts")
                screenshot_path = target.get("path") or os.path.join(artifact_dir, f"ps5-{int(time.time())}.png")
                output = manager.screenshot(screenshot_path, target.get("mode", "GAME"))
            return {"status": "passed", "action": action, "duration_ms": round((time.time() - started) * 1000),
                    "console_output": str(output)[:2000]}
        elif action in {"tap", "click"}: self._find(target).click()
        elif action in {"input", "type", "send_keys"}:
            element = self._find(target); element.clear(); element.send_keys(value)
        elif action in {"swipe", "scroll"}:
            direction = target.get("direction", "up")
            if direction not in {"up", "down", "left", "right"}: raise ReplayError(f"Invalid swipe direction: {direction}")
            self.driver.execute_script("mobile: swipe", {"direction": direction})
        elif action in {"back", "navigate_back"}: self.driver.back()
        elif action in {"wait", "sleep"}:
            duration = float(value or 1)
            if duration < 0 or duration > 30: raise ReplayError("Wait duration must be between 0 and 30 seconds")
            time.sleep(duration)
        elif action in {"assert_text", "verify_text"}:
            expected = step.get("expected", {}).get("text", value)
            if expected not in self.driver.page_source: raise ReplayError(f"Expected text not found: {expected}")
        elif action == "wait_for_text":
            expected = step.get("expected", {}).get("text", value)
            deadline = time.time() + min(float(step.get("timeout", self.wait_seconds)), 60)
            while time.time() < deadline:
                if expected in self.driver.page_source: break
                time.sleep(0.5)
            else: raise ReplayError(f"Timed out waiting for text: {expected}")
        elif action == "assert_any_text":
            candidates = step.get("expected", {}).get("texts", []) or ([value] if value else [])
            source = self.driver.page_source
            if not any(str(candidate) in source for candidate in candidates):
                raise ReplayError(f"None of the expected text values found: {candidates}")
        else: raise ReplayError(f"Unsupported action: {action}")
        return {"status": "passed", "action": action, "duration_ms": round((time.time() - started) * 1000)}

    def run(self, steps, visual_checkpoints=None, app_name="AutoPilotQE", test_name="AutoPilotQE native test"):
        self.results = []
        self.healing_events = []
        visual_checkpoints = [c for c in (visual_checkpoints or []) if c.get("enabled", True)]
        visual_runner = None
        visual_results = []
        try:
            if visual_checkpoints:
                from autopilotqe_agent.visual import SeleniumEyes
                visual_runner = SeleniumEyes(self.driver, app_name, test_name)
                visual_runner.open()
                for checkpoint in visual_checkpoints:
                    if int(checkpoint.get("after_step", 0)) == 0:
                        visual_runner.check(checkpoint)
                        visual_results.append({"name": checkpoint.get("name"), "status": "submitted", "after_step": 0})
            for index, step in enumerate(steps, 1):
                self.current_step_index = index - 1
                try:
                    self.results.append({"step": index, **self.execute_step(step)})
                    if visual_runner:
                        for checkpoint in visual_checkpoints:
                            if int(checkpoint.get("after_step", 0)) == index:
                                visual_runner.check(checkpoint)
                                visual_results.append({"name": checkpoint.get("name"), "status": "submitted", "after_step": index})
                except Exception as exc:
                    from autopilotqe_agent.failure_analysis import analyze_failure
                    evidence = {}
                    try:
                        import os
                        artifact_dir = os.getenv("AUTOPILOTQE_ARTIFACTS_DIR", "./artifacts")
                        os.makedirs(artifact_dir, exist_ok=True)
                        screenshot_path = os.path.join(artifact_dir, f"failure-{int(time.time())}-step-{index}.png")
                        if self.driver.get_screenshot_as_file(screenshot_path): evidence["screenshot"] = screenshot_path
                    except Exception: pass
                    try: evidence["ui_source_excerpt"] = str(self.driver.page_source)[:12000]
                    except Exception: pass
                    try:
                        logs = self.driver.get_log("logcat")
                        evidence["device_log_excerpt"] = "\n".join(str(x) for x in logs[-30:])[:6000]
                    except Exception: pass
                    self.results.append({"step": index, "status": "failed", "action": step.get("action"), "error": str(exc),
                                         "failure_analysis": analyze_failure(str(exc), step), "evidence": evidence})
                    break
            visual_summary = visual_runner.close() if visual_runner else None
            visual_runner = None
            passed = bool(self.results) and all(x["status"] == "passed" for x in self.results)
            failed = next((x for x in self.results if x.get("status") == "failed"), None)
            return {"status": "passed" if passed else "failed", "steps": self.results, "healing_events": self.healing_events,
                    "failure_analysis": failed.get("failure_analysis") if failed else None,
                    "healing_enabled": self.heal,
                    "visual": {"status": "submitted" if visual_results else "not_configured", "checkpoints": visual_results,
                               "summary": str(visual_summary)[:2000] if visual_summary else None}}
        except Exception as exc:
            if visual_runner:
                try: visual_runner.close()
                except Exception: pass
            from autopilotqe_agent.failure_analysis import analyze_failure
            failed_step = self.results[-1] if self.results else {}
            return {"status": "failed", "steps": self.results, "healing_events": self.healing_events, "healing_enabled": self.heal,
                    "failure_analysis": failed_step.get("failure_analysis") or analyze_failure(str(exc), failed_step),
                    "visual": {"status": "failed", "error": str(exc)[:1000]}}
