"""Conservative, deterministic locator recovery for Appium UI hierarchies.

This module intentionally does not call an LLM or mutate saved tests. It only
returns a high-confidence, runtime candidate plus auditable evidence.
"""
from difflib import SequenceMatcher
import xml.etree.ElementTree as ET


def _xpath_literal(value: str) -> str:
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    parts = value.split("'")
    return "concat(" + ", \"'\", ".join(f"'{part}'" for part in parts) + ")"


def _attrs(element):
    return {str(k).lower(): str(v) for k, v in element.attrib.items() if v is not None}


def rank_locator_candidates(page_source: str, original: dict, limit: int = 5) -> list[dict]:
    """Return candidate locators sorted by confidence, without performing actions."""
    if not page_source or not isinstance(original, dict):
        return []
    try:
        root = ET.fromstring(page_source)
    except (ET.ParseError, ValueError):
        return []

    expected_text = next((str(original[k]).strip() for k in ("text", "label", "content_desc", "description", "semantic_text") if original.get(k)), "")
    expected_id = next((str(original[k]).strip() for k in ("resource_id", "id", "accessibility_id", "name", "test_id") if original.get(k)), "")
    expected_class = str(original.get("class_name") or original.get("class") or "").strip().lower()
    candidates = []

    for element in root.iter():
        attrs = _attrs(element)
        text = (attrs.get("text") or attrs.get("label") or attrs.get("value") or attrs.get("content-desc") or attrs.get("name") or "").strip()
        resource_id = (attrs.get("resource-id") or attrs.get("resource_id") or attrs.get("id") or "").strip()
        content_desc = (attrs.get("content-desc") or attrs.get("accessibilitylabel") or attrs.get("name") or "").strip()
        class_name = (attrs.get("class") or attrs.get("type") or "").strip()
        bounds = attrs.get("bounds", "")
        score = 0.0
        matched_by = []
        if expected_text and text and text.casefold() == expected_text.casefold():
            score = 0.985; matched_by.append("exact_semantic_text")
        elif expected_text and text and SequenceMatcher(None, expected_text.casefold(), text.casefold()).ratio() >= 0.92:
            score = 0.90; matched_by.append("near_semantic_text")
        if expected_id and resource_id:
            ratio = SequenceMatcher(None, expected_id.casefold(), resource_id.casefold()).ratio()
            if ratio >= 0.82:
                score = max(score, min(0.90, 0.78 + ratio * 0.12)); matched_by.append("similar_resource_id")
        if expected_id and content_desc and content_desc.casefold() == expected_id.casefold():
            score = max(score, 0.98); matched_by.append("exact_accessibility_name")
        if expected_class and class_name and expected_class in class_name.casefold():
            score = min(0.995, score + 0.025); matched_by.append("matching_element_type")
        if score <= 0:
            continue

        if content_desc:
            locator = {"accessibility_id": content_desc}
        elif resource_id:
            locator = {"id": resource_id}
        elif text:
            locator = {"xpath": f"//*[@text={_xpath_literal(text)} or @label={_xpath_literal(text)} or @name={_xpath_literal(text)}]"}
        else:
            continue
        candidates.append({"locator": locator, "confidence": round(min(score, 0.995), 3),
                           "evidence": {"matched_by": matched_by, "text": text[:160],
                                        "resource_id": resource_id[:240], "class_name": class_name[:160],
                                        "bounds": bounds[:120]}})

    candidates.sort(key=lambda item: item["confidence"], reverse=True)
    return candidates[:max(1, min(limit, 10))]


def find_safe_candidate(page_source: str, original: dict, threshold: float = 0.93):
    ranked = rank_locator_candidates(page_source, original)
    if not ranked or ranked[0]["confidence"] < threshold:
        return None
    if len(ranked) > 1 and ranked[0]["confidence"] - ranked[1]["confidence"] < 0.04:
        return None
    return ranked[0]


def rank_web_locator_candidates(elements: list[dict], original: dict, limit: int = 5) -> list[dict]:
    """Rank visible web controls from a lightweight DOM inventory."""
    expected_text = next((str(original[k]).strip() for k in ("text", "label", "name", "aria_label", "semantic_text") if original.get(k)), "")
    expected_id = next((str(original[k]).strip() for k in ("test_id", "id", "name") if original.get(k)), "")
    expected_placeholder = str(original.get("placeholder") or "").strip()
    expected_role = str(original.get("role") or "").strip().lower()
    ranked = []
    for item in elements or []:
        if not isinstance(item, dict): continue
        if item.get("visible") is False: continue
        text = str(item.get("text") or item.get("aria_label") or item.get("title") or "").strip()
        test_id = str(item.get("test_id") or "").strip()
        element_id = str(item.get("id") or "").strip()
        aria_label = str(item.get("aria_label") or "").strip()
        placeholder = str(item.get("placeholder") or "").strip()
        role = str(item.get("role") or "").strip().lower()
        score = 0.0; matched = []
        if expected_text and text and expected_text.casefold() == text.casefold():
            score = 0.985; matched.append("exact_accessible_text")
        if expected_id and test_id and expected_id.casefold() == test_id.casefold():
            score = max(score, 0.98); matched.append("exact_test_id")
        if expected_id and element_id:
            ratio = SequenceMatcher(None, expected_id.casefold(), element_id.casefold()).ratio()
            if ratio >= 0.82:
                score = max(score, min(0.90, 0.78 + ratio * 0.12)); matched.append("similar_dom_id")
        if expected_placeholder and placeholder and expected_placeholder.casefold() == placeholder.casefold():
            score = max(score, 0.985); matched.append("exact_placeholder")
        if expected_role and role == expected_role:
            score = min(0.995, score + 0.025); matched.append("matching_role")
        if score <= 0: continue
        if role and text:
            locator = {"role": role, "name": text}
        elif aria_label:
            locator = {"label": aria_label}
        elif placeholder:
            locator = {"placeholder": placeholder}
        elif test_id:
            locator = {"test_id": test_id}
        elif element_id:
            locator = {"css": f"#{element_id}"}
        elif text:
            locator = {"text": text}
        else:
            continue
        ranked.append({"locator": locator, "confidence": round(min(score, 0.995), 3),
                       "evidence": {"matched_by": matched, "text": text[:160], "role": role,
                                    "id": element_id[:160], "test_id": test_id[:160]}})
    ranked.sort(key=lambda item: item["confidence"], reverse=True)
    return ranked[:max(1, min(limit, 10))]


def find_safe_web_candidate(elements: list[dict], original: dict, threshold: float = 0.93):
    ranked = rank_web_locator_candidates(elements, original)
    if not ranked or ranked[0]["confidence"] < threshold:
        return None
    if len(ranked) > 1 and ranked[0]["confidence"] - ranked[1]["confidence"] < 0.04:
        return None
    return ranked[0]
