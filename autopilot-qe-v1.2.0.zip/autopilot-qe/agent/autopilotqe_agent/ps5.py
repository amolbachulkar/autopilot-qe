"""Thin, allow-listed adapter for Sony's installed Prospero Target Manager CLI.

This deliberately invokes the SDK executable supplied by the user's licensed
PlayStation SDK installation; it does not implement Sony's private protocols.
"""
from __future__ import annotations
import os
import subprocess
import json
import urllib.request
import urllib.error
from pathlib import Path

DEFAULT_TMS = r"C:\Program Files (x86)\SCE\Prospero\Tools\Target Manager Server\bin\prospero-ctrl.exe"


class PS5TargetError(RuntimeError):
    pass


class PS5TargetManager:
    def __init__(self, executable: str | None = None, target: str | None = None, timeout: int = 30):
        self.executable = executable or os.getenv("PS5_PROSPERO_CTRL", DEFAULT_TMS)
        self.target = target or os.getenv("PS5_TARGET", "")
        self.timeout = max(2, min(int(timeout), 180))

    def _run(self, *args: str, timeout: int | None = None) -> str:
        bridge_url = os.getenv("PS5_BRIDGE_URL", "").rstrip("/")
        if bridge_url:
            operation = args[0] + " " + args[1] if len(args) > 1 else (args[0] if args else "")
            payload = {"operation": operation, "args": list(args[2:]), "target": self.target}
            request = urllib.request.Request(bridge_url + "/v1/ps5/command", data=json.dumps(payload).encode(),
                headers={"Content-Type": "application/json", "Authorization": "Bearer " + os.getenv("PS5_BRIDGE_TOKEN", "")}, method="POST")
            try:
                with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                    data = json.loads(response.read().decode())
                if not data.get("ok"):
                    raise PS5TargetError(str(data.get("error", "Remote PS5 bridge command failed")))
                return str(data.get("result", ""))
            except (urllib.error.URLError, TimeoutError, ValueError) as exc:
                raise PS5TargetError(f"Remote PS5 bridge unavailable: {exc}") from exc
        exe = Path(self.executable)
        if not exe.is_file():
            raise PS5TargetError(
                f"Target Manager CLI not found at '{self.executable}'. Install the authorised PS5 SDK/Target Manager Server and set PS5_PROSPERO_CTRL."
            )
        command = [str(exe), *[str(x) for x in args]]
        if self.target and "/target:" not in " ".join(args):
            command.append(f"/target:{self.target}")
        try:
            result = subprocess.run(command, capture_output=True, text=True,
                                    timeout=timeout or self.timeout, check=False)
        except subprocess.TimeoutExpired as exc:
            raise PS5TargetError(f"Target Manager command timed out after {exc.timeout}s") from exc
        except OSError as exc:
            raise PS5TargetError(f"Could not start Target Manager: {exc}") from exc
        output = "\n".join(x for x in (result.stdout.strip(), result.stderr.strip()) if x)
        if result.returncode != 0:
            raise PS5TargetError(f"Target Manager exited {result.returncode}: {output[-3000:]}")
        return output

    def discover(self) -> str:
        return self._run("target", "find")

    def list_targets(self) -> str:
        return self._run("target", "list", "/update")

    def connect(self) -> str:
        return self._run("target", "connect")

    def info(self) -> str:
        return self._run("target", "info")

    def health(self) -> str:
        return self._run("diagnostics", "health-check")

    def launch(self, title_id: str) -> str:
        if not title_id or len(title_id) > 64 or any(c.isspace() for c in title_id):
            raise PS5TargetError("A valid PS5 application Title ID is required")
        return self._run("application", "start", title_id, timeout=90)

    def screenshot(self, destination: str, mode: str = "GAME") -> str:
        if mode not in {"GAME", "SYSTEM"}:
            raise PS5TargetError("Screenshot mode must be GAME or SYSTEM")
        if os.getenv("PS5_BRIDGE_URL", "").strip():
            # This path belongs to the Windows bridge host, not the remote Mac worker.
            output = self._run("target", "screenshot", str(destination), f"/mode:{mode}")
            return str(output or destination)
        path = Path(destination).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        output = self._run("target", "screenshot", str(path), f"/mode:{mode}")
        if not path.is_file():
            raise PS5TargetError(f"Target Manager returned without creating screenshot: {path}. {output}")
        return str(path)


class _BridgeHandler(__import__("http.server", fromlist=["BaseHTTPRequestHandler"]).BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/v1/ps5/command":
            self.send_error(404); return
        expected = os.getenv("PS5_BRIDGE_TOKEN", "")
        supplied = self.headers.get("Authorization", "")
        if not expected or supplied != "Bearer " + expected:
            self.send_error(401); return
        try:
            length = min(int(self.headers.get("Content-Length", "0")), 16384)
            body = json.loads(self.rfile.read(length) or b"{}")
            operation = body.get("operation", "")
            target = str(body.get("target", ""))
            manager = PS5TargetManager(target=target)
            allowed = {"target find": manager.discover, "target list": manager.list_targets,
                       "target connect": manager.connect, "target info": manager.info,
                       "diagnostics health-check": manager.health}
            if operation in allowed:
                result = allowed[operation]()
            elif operation == "application start":
                args = body.get("args") or []
                if len(args) != 1: raise PS5TargetError("application start requires exactly one Title ID")
                result = manager.launch(str(args[0]))
            elif operation == "target screenshot":
                args = body.get("args") or []
                if len(args) != 2: raise PS5TargetError("screenshot requires output path and GAME/SYSTEM mode")
                mode = str(args[1]).split(":", 1)[-1].upper()
                result = manager.screenshot(str(args[0]), mode)
            else:
                raise PS5TargetError("Operation is not allowed by the AutoPilotQE PS5 bridge")
            self._reply(200, {"ok": True, "result": result})
        except Exception as exc:
            self._reply(400, {"ok": False, "error": str(exc)[:1500]})

    def _reply(self, status, payload):
        data = json.dumps(payload).encode()
        self.send_response(status); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

    def log_message(self, fmt, *args):
        return


def serve_bridge(host: str = "0.0.0.0", port: int = 8787):
    from http.server import ThreadingHTTPServer
    if len(os.getenv("PS5_BRIDGE_TOKEN", "")) < 24:
        raise PS5TargetError("Set PS5_BRIDGE_TOKEN to a random secret of at least 24 characters before exposing the bridge")
    server = ThreadingHTTPServer((host, port), _BridgeHandler)
    print(f"AutoPilotQE PS5 bridge listening on {host}:{port}; restrict access to your trusted test LAN")
    server.serve_forever()
